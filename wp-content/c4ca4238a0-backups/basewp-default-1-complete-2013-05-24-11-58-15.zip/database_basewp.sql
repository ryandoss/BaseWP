# WordPress : http://basewp MySQL database backup
#
# Generated: Friday 24. May 2013 17:58 UTC
# Hostname: localhost
# Database: `basewp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_commentmeta (0 records)
#

#
# End of data contents of table wp_commentmeta
# --------------------------------------------------------

# WordPress : http://basewp MySQL database backup
#
# Generated: Friday 24. May 2013 17:58 UTC
# Hostname: localhost
# Database: `basewp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------


#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_comments (15 records)
#
 
INSERT INTO `wp_comments` VALUES (1, 1, 'Mr WordPress', '', 'http://wordpress.org/', '', '2013-03-14 16:38:54', '2013-03-14 16:38:54', 'Hi, this is a comment.
To delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.', 0, '1', '', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (2, 7, 'Dan Philibin', 'dan@danphilibin.com', 'http://wpcandy.com', '207.255.235.40', '2008-09-17 17:16:35', '2008-09-17 22:16:35', 'Here is a non-admin comment.

It has multiple lines, some <code>code</code>, and a bit more text.', 0, '1', '', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (3, 34, 'admin', 'hey@wpcoder.com', 'http://', '207.255.235.40', '2008-09-17 17:14:05', '2008-09-17 22:14:05', 'Howdy! This is an admin comment.', 0, '1', '', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (4, 34, 'Dan Philibin', 'dan@danphilibin.com', 'http://wpcandy.com', '207.255.235.40', '2008-09-17 17:16:01', '2008-09-17 22:16:01', 'Here is a non-admin comment.

It has multiple lines, some <code>code</code>, and a bit more text.', 0, '1', '', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (5, 37, 'admin', 'hey@wpcoder.com', 'http://', '207.255.235.40', '2008-09-17 17:14:02', '2008-09-17 22:14:02', 'Howdy! This is an admin comment.', 0, '1', '', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (6, 39, 'Dan Philibin', 'dan@danphilibin.com', 'http://wpcandy.com', '207.255.235.40', '2008-09-17 17:17:42', '2008-09-17 22:17:42', 'Here is a non-admin comment.

It has multiple lines, some <code>code</code>, and a bit more text.', 0, '1', '', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (7, 39, 'Dan Philibin', 'dan@danphilibin.com', 'http://wpcandy.com', '207.255.235.40', '2008-09-17 17:18:11', '2008-09-17 22:18:11', 'Here is a non-admin comment.

It has multiple lines, some <code>code</code>, and a bit more text. Alternating content so I don\'t get caught spamming ;)', 0, '1', '', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (8, 41, 'admin', 'hey@wpcoder.com', 'http://', '207.255.235.40', '2008-09-17 17:13:58', '2008-09-17 22:13:58', 'Howdy! This is an admin comment.', 0, '1', '', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (9, 45, 'Dan Philibin', 'dan@danphilibin.com', 'http://wpcandy.com', '207.255.235.40', '2008-09-17 17:19:27', '2008-09-17 22:19:27', 'Here is a non-admin comment.

It has multiple lines, some <code>code</code>, and a bit more text.', 0, '1', '', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (10, 47, 'admin', 'hey@wpcoder.com', 'http://', '207.255.235.40', '2008-09-17 17:13:55', '2008-09-17 22:13:55', 'Howdy! This is an admin comment.', 0, '1', '', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (11, 47, 'Dan Philibin', 'dan@danphilibin.com', 'http://wpcandy.com', '207.255.235.40', '2008-09-17 17:19:42', '2008-09-17 22:19:42', 'Here is a non-admin comment.

It has multiple lines, some <code>code</code>, and a bit more text.', 0, '1', '', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (12, 53, 'Mr WordPress', '', 'http://wordpress.org/', '', '2008-09-17 16:53:25', '2008-09-17 21:53:25', 'Hi, this is a comment.<br />To delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.', 0, '1', '', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (13, 53, 'admin', 'hey@wpcoder.com', 'http://', '207.255.235.40', '2008-09-17 17:13:50', '2008-09-17 22:13:50', 'Howdy! This is an admin comment.', 0, '1', '', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (14, 59, 'admin', 'hey@wpcoder.com', 'http://', '207.255.235.40', '2008-09-17 17:13:35', '2008-09-17 22:13:35', 'Howdy! This is an admin comment.', 0, '1', '', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (15, 59, 'Dan Philibin', 'dan@danphilibin.com', 'http://wpcandy.com', '207.255.235.40', '2008-09-17 17:20:13', '2008-09-17 22:20:13', 'Here is a non-admin comment.

It has multiple lines, some <code>code</code>, and a bit more text.', 0, '1', '', '', 0, 0) ;
#
# End of data contents of table wp_comments
# --------------------------------------------------------

# WordPress : http://basewp MySQL database backup
#
# Generated: Friday 24. May 2013 17:58 UTC
# Hostname: localhost
# Database: `basewp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------


#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_links (0 records)
#

#
# End of data contents of table wp_links
# --------------------------------------------------------

# WordPress : http://basewp MySQL database backup
#
# Generated: Friday 24. May 2013 17:58 UTC
# Hostname: localhost
# Database: `basewp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------


#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=423 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_options (199 records)
#
 
INSERT INTO `wp_options` VALUES (1, 'siteurl', 'http://basewp', 'yes') ; 
INSERT INTO `wp_options` VALUES (2, 'blogname', 'Base WP', 'yes') ; 
INSERT INTO `wp_options` VALUES (3, 'blogdescription', 'Just another WordPress site', 'yes') ; 
INSERT INTO `wp_options` VALUES (4, 'users_can_register', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (5, 'admin_email', 'rdoss@pilrtech.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (6, 'start_of_week', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (7, 'use_balanceTags', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (8, 'use_smilies', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (9, 'require_name_email', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (10, 'comments_notify', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (11, 'posts_per_rss', '10', 'yes') ; 
INSERT INTO `wp_options` VALUES (12, 'rss_use_excerpt', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (13, 'mailserver_url', 'mail.example.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (14, 'mailserver_login', 'login@example.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (15, 'mailserver_pass', 'password', 'yes') ; 
INSERT INTO `wp_options` VALUES (16, 'mailserver_port', '110', 'yes') ; 
INSERT INTO `wp_options` VALUES (17, 'default_category', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (18, 'default_comment_status', 'open', 'yes') ; 
INSERT INTO `wp_options` VALUES (19, 'default_ping_status', 'open', 'yes') ; 
INSERT INTO `wp_options` VALUES (20, 'default_pingback_flag', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (21, 'posts_per_page', '10', 'yes') ; 
INSERT INTO `wp_options` VALUES (22, 'date_format', 'F j, Y', 'yes') ; 
INSERT INTO `wp_options` VALUES (23, 'time_format', 'g:i a', 'yes') ; 
INSERT INTO `wp_options` VALUES (24, 'links_updated_date_format', 'F j, Y g:i a', 'yes') ; 
INSERT INTO `wp_options` VALUES (25, 'links_recently_updated_prepend', '<em>', 'yes') ; 
INSERT INTO `wp_options` VALUES (26, 'links_recently_updated_append', '</em>', 'yes') ; 
INSERT INTO `wp_options` VALUES (27, 'links_recently_updated_time', '120', 'yes') ; 
INSERT INTO `wp_options` VALUES (28, 'comment_moderation', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (29, 'moderation_notify', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (30, 'permalink_structure', '/%postname%/', 'yes') ; 
INSERT INTO `wp_options` VALUES (31, 'gzipcompression', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (32, 'hack_file', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (33, 'blog_charset', 'UTF-8', 'yes') ; 
INSERT INTO `wp_options` VALUES (34, 'moderation_keys', '', 'no') ; 
INSERT INTO `wp_options` VALUES (35, 'active_plugins', 'a:6:{i:0;s:26:"backupwordpress/plugin.php";i:1;s:35:"gallery-metabox/gallery-metabox.php";i:2;s:29:"gravityforms/gravityforms.php";i:3;s:29:"gravityformspaypal/paypal.php";i:4;s:23:"pilr-tech/pilr-tech.php";i:5;s:45:"unique-page-sidebars/unique-page-sidebars.php";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (36, 'home', 'http://basewp', 'yes') ; 
INSERT INTO `wp_options` VALUES (37, 'category_base', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (38, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes') ; 
INSERT INTO `wp_options` VALUES (39, 'advanced_edit', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (40, 'comment_max_links', '2', 'yes') ; 
INSERT INTO `wp_options` VALUES (41, 'gmt_offset', '-6', 'yes') ; 
INSERT INTO `wp_options` VALUES (42, 'default_email_category', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (43, 'recently_edited', '', 'no') ; 
INSERT INTO `wp_options` VALUES (44, 'template', 'base_wp', 'yes') ; 
INSERT INTO `wp_options` VALUES (45, 'stylesheet', 'base_wp', 'yes') ; 
INSERT INTO `wp_options` VALUES (46, 'comment_whitelist', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (47, 'blacklist_keys', '', 'no') ; 
INSERT INTO `wp_options` VALUES (48, 'comment_registration', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (49, 'html_type', 'text/html', 'yes') ; 
INSERT INTO `wp_options` VALUES (50, 'use_trackback', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (51, 'default_role', 'subscriber', 'yes') ; 
INSERT INTO `wp_options` VALUES (52, 'db_version', '22441', 'yes') ; 
INSERT INTO `wp_options` VALUES (53, 'uploads_use_yearmonth_folders', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (54, 'upload_path', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (55, 'blog_public', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (56, 'default_link_category', '2', 'yes') ; 
INSERT INTO `wp_options` VALUES (57, 'show_on_front', 'posts', 'yes') ; 
INSERT INTO `wp_options` VALUES (58, 'tag_base', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (59, 'show_avatars', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (60, 'avatar_rating', 'G', 'yes') ; 
INSERT INTO `wp_options` VALUES (61, 'upload_url_path', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (62, 'thumbnail_size_w', '150', 'yes') ; 
INSERT INTO `wp_options` VALUES (63, 'thumbnail_size_h', '150', 'yes') ; 
INSERT INTO `wp_options` VALUES (64, 'thumbnail_crop', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (65, 'medium_size_w', '300', 'yes') ; 
INSERT INTO `wp_options` VALUES (66, 'medium_size_h', '300', 'yes') ; 
INSERT INTO `wp_options` VALUES (67, 'avatar_default', 'mystery', 'yes') ; 
INSERT INTO `wp_options` VALUES (68, 'large_size_w', '1024', 'yes') ; 
INSERT INTO `wp_options` VALUES (69, 'large_size_h', '1024', 'yes') ; 
INSERT INTO `wp_options` VALUES (70, 'image_default_link_type', 'file', 'yes') ; 
INSERT INTO `wp_options` VALUES (71, 'image_default_size', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (72, 'image_default_align', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (73, 'close_comments_for_old_posts', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (74, 'close_comments_days_old', '14', 'yes') ; 
INSERT INTO `wp_options` VALUES (75, 'thread_comments', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (76, 'thread_comments_depth', '5', 'yes') ; 
INSERT INTO `wp_options` VALUES (77, 'page_comments', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (78, 'comments_per_page', '50', 'yes') ; 
INSERT INTO `wp_options` VALUES (79, 'default_comments_page', 'newest', 'yes') ; 
INSERT INTO `wp_options` VALUES (80, 'comment_order', 'asc', 'yes') ; 
INSERT INTO `wp_options` VALUES (81, 'sticky_posts', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (82, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (83, 'widget_text', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (84, 'widget_rss', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (85, 'uninstall_plugins', 'a:0:{}', 'no') ; 
INSERT INTO `wp_options` VALUES (86, 'timezone_string', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (87, 'page_for_posts', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (88, 'page_on_front', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (89, 'default_post_format', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (90, 'link_manager_enabled', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (91, 'initial_db_version', '22441', 'yes') ; 
INSERT INTO `wp_options` VALUES (92, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:64:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:19:"gravityforms_paypal";b:1;s:29:"gravityforms_paypal_uninstall";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (93, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (94, 'widget_recent-posts', 'a:3:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}i:3;a:3:{s:5:"title";s:12:"Recent Posts";s:6:"number";i:5;s:9:"show_date";b:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (95, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (96, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (97, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (98, 'sidebars_widgets', 'a:5:{s:19:"wp_inactive_widgets";a:0:{}s:7:"sidebar";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:13:"ups-sidebar-1";a:1:{i:0;s:7:"pages-2";}s:13:"ups-sidebar-2";a:1:{i:0;s:14:"recent-posts-3";}s:13:"array_version";i:3;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (99, 'cron', 'a:6:{i:1369371600;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"61a45f8e0e711228d9f0aa04271d0a05";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:1:{s:2:"id";s:9:"default-2";}s:8:"interval";i:604800;}}}i:1369456760;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1369458000;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"887abd106b36605fbb285d0dec9f47ac";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:1:{s:2:"id";s:9:"default-1";}s:8:"interval";i:86400;}}}i:1369499969;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1369500032;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (101, '_site_transient_update_core', 'O:8:"stdClass":3:{s:7:"updates";a:1:{i:0;O:8:"stdClass":9:{s:8:"response";s:6:"latest";s:8:"download";s:40:"http://wordpress.org/wordpress-3.5.1.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":4:{s:4:"full";s:40:"http://wordpress.org/wordpress-3.5.1.zip";s:10:"no_content";s:51:"http://wordpress.org/wordpress-3.5.1-no-content.zip";s:11:"new_bundled";s:52:"http://wordpress.org/wordpress-3.5.1-new-bundled.zip";s:7:"partial";b:0;}s:7:"current";s:5:"3.5.1";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"3.5";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1369418292;s:15:"version_checked";s:5:"3.5.1";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (105, '_site_transient_update_themes', 'O:8:"stdClass":3:{s:12:"last_checked";i:1369418294;s:7:"checked";a:1:{s:7:"base_wp";s:3:"1.0";}s:8:"response";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (106, '_site_transient_timeout_browser_06df7252d912cc9f4a8f895809c372b8', '1363883976', 'yes') ; 
INSERT INTO `wp_options` VALUES (107, '_site_transient_browser_06df7252d912cc9f4a8f895809c372b8', 'a:9:{s:8:"platform";s:7:"Windows";s:4:"name";s:6:"Chrome";s:7:"version";s:13:"25.0.1364.152";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (108, 'dashboard_widget_options', 'a:4:{s:25:"dashboard_recent_comments";a:1:{s:5:"items";i:5;}s:24:"dashboard_incoming_links";a:5:{s:4:"home";s:13:"http://basewp";s:4:"link";s:89:"http://blogsearch.google.com/blogsearch?scoring=d&partner=wordpress&q=link:http://basewp/";s:3:"url";s:122:"http://blogsearch.google.com/blogsearch_feeds?scoring=d&ie=utf-8&num=10&output=rss&partner=wordpress&q=link:http://basewp/";s:5:"items";i:10;s:9:"show_date";b:0;}s:17:"dashboard_primary";a:7:{s:4:"link";s:26:"http://wordpress.org/news/";s:3:"url";s:31:"http://wordpress.org/news/feed/";s:5:"title";s:14:"WordPress Blog";s:5:"items";i:2;s:12:"show_summary";i:1;s:11:"show_author";i:0;s:9:"show_date";i:1;}s:19:"dashboard_secondary";a:7:{s:4:"link";s:28:"http://planet.wordpress.org/";s:3:"url";s:33:"http://planet.wordpress.org/feed/";s:5:"title";s:20:"Other WordPress News";s:5:"items";i:5;s:12:"show_summary";i:0;s:11:"show_author";i:0;s:9:"show_date";i:0;}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (109, 'can_compress_scripts', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (140, '_site_transient_timeout_wporg_theme_feature_list', '1363289986', 'yes') ; 
INSERT INTO `wp_options` VALUES (141, '_site_transient_wporg_theme_feature_list', 'a:5:{s:6:"Colors";a:15:{i:0;s:5:"black";i:1;s:4:"blue";i:2;s:5:"brown";i:3;s:4:"gray";i:4;s:5:"green";i:5;s:6:"orange";i:6;s:4:"pink";i:7;s:6:"purple";i:8;s:3:"red";i:9;s:6:"silver";i:10;s:3:"tan";i:11;s:5:"white";i:12;s:6:"yellow";i:13;s:4:"dark";i:14;s:5:"light";}s:7:"Columns";a:6:{i:0;s:10:"one-column";i:1;s:11:"two-columns";i:2;s:13:"three-columns";i:3;s:12:"four-columns";i:4;s:12:"left-sidebar";i:5;s:13:"right-sidebar";}s:5:"Width";a:2:{i:0;s:11:"fixed-width";i:1;s:14:"flexible-width";}s:8:"Features";a:19:{i:0;s:8:"blavatar";i:1;s:10:"buddypress";i:2;s:17:"custom-background";i:3;s:13:"custom-colors";i:4;s:13:"custom-header";i:5;s:11:"custom-menu";i:6;s:12:"editor-style";i:7;s:21:"featured-image-header";i:8;s:15:"featured-images";i:9;s:15:"flexible-header";i:10;s:20:"front-page-post-form";i:11;s:19:"full-width-template";i:12;s:12:"microformats";i:13;s:12:"post-formats";i:14;s:20:"rtl-language-support";i:15;s:11:"sticky-post";i:16;s:13:"theme-options";i:17;s:17:"threaded-comments";i:18;s:17:"translation-ready";}s:7:"Subject";a:3:{i:0;s:7:"holiday";i:1;s:13:"photoblogging";i:2;s:8:"seasonal";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (142, 'theme_mods_twentytwelve', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1363279188;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (143, 'current_theme', 'Base WP', 'yes') ; 
INSERT INTO `wp_options` VALUES (144, 'theme_mods_base_wp', 'a:1:{i:0;b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (145, 'theme_switched', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (146, 'recently_activated', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (157, '_transient_random_seed', '7c4a1aed38c802394817897f20f06002', 'yes') ; 
INSERT INTO `wp_options` VALUES (161, '_site_transient_timeout_popular_importers_en_US', '1363452454', 'yes') ; 
INSERT INTO `wp_options` VALUES (162, '_site_transient_popular_importers_en_US', 'a:2:{s:9:"importers";a:8:{s:7:"blogger";a:4:{s:4:"name";s:7:"Blogger";s:11:"description";s:86:"Install the Blogger importer to import posts, comments, and users from a Blogger blog.";s:11:"plugin-slug";s:16:"blogger-importer";s:11:"importer-id";s:7:"blogger";}s:9:"wpcat2tag";a:4:{s:4:"name";s:29:"Categories and Tags Converter";s:11:"description";s:109:"Install the category/tag converter to convert existing categories to tags or tags to categories, selectively.";s:11:"plugin-slug";s:18:"wpcat2tag-importer";s:11:"importer-id";s:9:"wpcat2tag";}s:11:"livejournal";a:4:{s:4:"name";s:11:"LiveJournal";s:11:"description";s:82:"Install the LiveJournal importer to import posts from LiveJournal using their API.";s:11:"plugin-slug";s:20:"livejournal-importer";s:11:"importer-id";s:11:"livejournal";}s:11:"movabletype";a:4:{s:4:"name";s:24:"Movable Type and TypePad";s:11:"description";s:99:"Install the Movable Type importer to import posts and comments from a Movable Type or TypePad blog.";s:11:"plugin-slug";s:20:"movabletype-importer";s:11:"importer-id";s:2:"mt";}s:4:"opml";a:4:{s:4:"name";s:8:"Blogroll";s:11:"description";s:61:"Install the blogroll importer to import links in OPML format.";s:11:"plugin-slug";s:13:"opml-importer";s:11:"importer-id";s:4:"opml";}s:3:"rss";a:4:{s:4:"name";s:3:"RSS";s:11:"description";s:58:"Install the RSS importer to import posts from an RSS feed.";s:11:"plugin-slug";s:12:"rss-importer";s:11:"importer-id";s:3:"rss";}s:6:"tumblr";a:4:{s:4:"name";s:6:"Tumblr";s:11:"description";s:84:"Install the Tumblr importer to import posts &amp; media from Tumblr using their API.";s:11:"plugin-slug";s:15:"tumblr-importer";s:11:"importer-id";s:6:"tumblr";}s:9:"wordpress";a:4:{s:4:"name";s:9:"WordPress";s:11:"description";s:130:"Install the WordPress importer to import posts, pages, comments, custom fields, categories, and tags from a WordPress export file.";s:11:"plugin-slug";s:18:"wordpress-importer";s:11:"importer-id";s:9:"wordpress";}}s:10:"translated";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (166, 'category_children', 'a:3:{i:2;a:2:{i:0;i:6;i:1;i:7;}i:4;a:1:{i:0;i:8;}i:7;a:1:{i:0;i:9;}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (169, 'infinite_scroll', 'a:8:{s:7:"loading";a:3:{s:7:"msgText";s:19:"<em>Loading...</em>";s:11:"finishedMsg";s:29:"<em>No additional posts.</em>";s:3:"img";s:68:"http://basewp/wp-content/plugins/infinite-scroll/img/ajax-loader.gif";}s:12:"nextSelector";s:18:"#nav-below a:first";s:11:"navSelector";s:10:"#nav-below";s:12:"itemSelector";s:5:".post";s:15:"contentSelector";s:8:"#content";s:5:"debug";b:0;s:8:"behavior";s:0:"";s:10:"db_version";s:5:"2.6.1";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (178, 'rg_form_version', '1.6.12', 'yes') ; 
INSERT INTO `wp_options` VALUES (181, 'rg_gforms_key', 'bbbc1f07a632756c7c294446c29a6571', 'yes') ; 
INSERT INTO `wp_options` VALUES (182, 'rg_gforms_disable_css', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (183, 'rg_gforms_enable_html5', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (184, 'gform_enable_noconflict', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (185, 'rg_gforms_enable_akismet', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (186, 'rg_gforms_captcha_public_key', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (187, 'rg_gforms_captcha_private_key', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (188, 'rg_gforms_currency', 'USD', 'yes') ; 
INSERT INTO `wp_options` VALUES (189, 'rg_gforms_message', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (194, 'gf_paypal_version', '1.7', 'yes') ; 
INSERT INTO `wp_options` VALUES (200, '_site_transient_timeout_gforms_paypal_version', '1369366100', 'yes') ; 
INSERT INTO `wp_options` VALUES (201, '_site_transient_gforms_paypal_version', 'a:3:{s:12:"is_valid_key";s:1:"0";s:7:"version";s:3:"1.7";s:3:"url";s:0:"";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (202, '_site_transient_timeout_browser_b4c18ecb06b751fa1bf7aec676f1e2e0', '1364307371', 'yes') ; 
INSERT INTO `wp_options` VALUES (203, '_site_transient_browser_b4c18ecb06b751fa1bf7aec676f1e2e0', 'a:9:{s:8:"platform";s:7:"Windows";s:4:"name";s:6:"Chrome";s:7:"version";s:13:"25.0.1364.172";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (230, '_transient_timeout_plugin_slugs', '1369409301', 'no') ; 
INSERT INTO `wp_options` VALUES (231, '_transient_plugin_slugs', 'a:35:{i:0;s:30:"advanced-custom-fields/acf.php";i:1;s:43:"all-in-one-seo-pack/all_in_one_seo_pack.php";i:2;s:26:"backupwordpress/plugin.php";i:3;s:59:"black-studio-tinymce-widget/black-studio-tinymce-widget.php";i:4;s:43:"broken-link-checker/broken-link-checker.php";i:5;s:41:"business-directory-plugin/wpbusdirman.php";i:6;s:36:"elegantbuilder/et-layout-builder.php";i:7;s:35:"gallery-metabox/gallery-metabox.php";i:8;s:49:"google-calendar-events/google-calendar-events.php";i:9;s:29:"gravityforms/gravityforms.php";i:10;s:41:"gravityformsauthorizenet/authorizenet.php";i:11;s:29:"gravityformsaweber/aweber.php";i:12;s:47:"gravityformscampaignmonitor/campaignmonitor.php";i:13;s:37:"gravityformsfreshbooks/freshbooks.php";i:14;s:35:"gravityformsmailchimp/mailchimp.php";i:15;s:29:"gravityformspaypal/paypal.php";i:16;s:35:"gravityformspaypalpro/paypalpro.php";i:17;s:33:"gravityformspicatcha/picatcha.php";i:18;s:27:"gravityformspolls/polls.php";i:19;s:25:"gravityformsquiz/quiz.php";i:20;s:35:"gravityformssignature/signature.php";i:21;s:29:"gravityformstwilio/twilio.php";i:22;s:49:"gravityformsuserregistration/userregistration.php";i:23;s:35:"infinite-scroll/infinite-scroll.php";i:24;s:27:"LayerSlider/layerslider.php";i:25;s:23:"pilr-tech/pilr-tech.php";i:26;s:33:"post-expirator/post-expirator.php";i:27;s:27:"redirection/redirection.php";i:28;s:49:"responsive-select-menu/responsive-select-menu.php";i:29;s:43:"the-events-calendar/the-events-calendar.php";i:30;s:37:"tinymce-advanced/tinymce-advanced.php";i:31;s:21:"ubermenu/ubermenu.php";i:32;s:45:"unique-page-sidebars/unique-page-sidebars.php";i:33;s:41:"wordpress-importer/wordpress-importer.php";i:34;s:24:"wordpress-seo/wp-seo.php";}', 'no') ; 
INSERT INTO `wp_options` VALUES (241, '_transient_plugins_delete_result_1', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (242, 'expirationdateDefaultDateFormat', 'l F jS, Y', 'yes') ; 
INSERT INTO `wp_options` VALUES (243, 'expirationdateDefaultTimeFormat', 'g:ia', 'yes') ; 
INSERT INTO `wp_options` VALUES (244, 'expirationdateFooterContents', 'Post expires at EXPIRATIONTIME on EXPIRATIONDATE', 'yes') ; 
INSERT INTO `wp_options` VALUES (245, 'expirationdateFooterStyle', 'font-style: italic;', 'yes') ; 
INSERT INTO `wp_options` VALUES (246, 'expirationdateDisplayFooter', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (247, 'expirationdateDebug', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (248, 'expirationdateDefaultDate', 'null', 'yes') ; 
INSERT INTO `wp_options` VALUES (249, 'postexpiratorVersion', '2.0.1', 'yes') ; 
INSERT INTO `wp_options` VALUES (281, 'hmbkp_default_path', 'S:/wamp/www/base_wp/wp-content/c4ca4238a0-backups', 'yes') ; 
INSERT INTO `wp_options` VALUES (282, 'hmbkp_path', 'S:/wamp/www/base_wp/wp-content/c4ca4238a0-backups', 'yes') ; 
INSERT INTO `wp_options` VALUES (283, 'hmbkp_schedule_default-1', 'a:4:{s:4:"type";s:8:"complete";s:12:"reoccurrence";s:5:"daily";s:11:"max_backups";i:14;s:19:"HMBKP_Email_Service";a:1:{s:5:"email";s:0:"";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (284, 'hmbkp_schedule_default-2', 'a:3:{s:4:"type";s:8:"complete";s:12:"reoccurrence";s:6:"weekly";s:11:"max_backups";i:12;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (285, 'hmbkp_plugin_version', '2.2.4', 'yes') ; 
INSERT INTO `wp_options` VALUES (290, '_transient_timeout_hmbkp_schedule_default-2_filesize', '2727681518', 'no') ; 
INSERT INTO `wp_options` VALUES (291, '_transient_hmbkp_schedule_default-2_filesize', '37902143', 'no') ; 
INSERT INTO `wp_options` VALUES (298, '_transient_timeout_hmbkp_schedule_default-1_filesize', '2727681646', 'no') ; 
INSERT INTO `wp_options` VALUES (299, '_transient_hmbkp_schedule_default-1_filesize', '37902565', 'no') ; 
INSERT INTO `wp_options` VALUES (306, '_transient_timeout_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1363921608', 'no') ; 
INSERT INTO `wp_options` VALUES (307, '_transient_timeout_feed_aa75f026b58586b24d81a087c77a9ecf', '1363921608', 'no') ; 
INSERT INTO `wp_options` VALUES (308, '_transient_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:50:"
	
	
	
	
	
	
	
	
	
		
		
		
		
		
		
		
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:3:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"WordPress News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:25:"http://wordpress.org/news";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:14:"WordPress News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 07 Mar 2013 14:21:02 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:39:"http://wordpress.org/?v=3.6-alpha-23754";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:48:"WordPress 3.5.1 Maintenance and Security Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2013/01/wordpress-3-5-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/news/2013/01/wordpress-3-5-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 24 Jan 2013 22:23:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2531";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:359:"WordPress 3.5.1 is now available. Version 3.5.1 is the first maintenance release of 3.5, fixing 37 bugs. It is also a security release for all previous WordPress versions. For a full list of changes, consult the list of tickets and the changelog, which include: Editor: Prevent certain HTML elements from being unexpectedly removed or modified in rare [...]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2499:"<p>WordPress 3.5.1 is now available. Version 3.5.1 is the first maintenance release of 3.5, <a href="http://core.trac.wordpress.org/milestone/3.5.1">fixing 37 bugs</a>. It is also a security release for all previous WordPress versions. For a full list of changes, consult the <a href="http://core.trac.wordpress.org/query?milestone=3.5.1">list of tickets</a> and the <a href="http://core.trac.wordpress.org/log/branches/3.5?rev=23341&amp;stop_rev=23167">changelog</a>, which include:</p>
<ul>
<li>Editor: Prevent certain HTML elements from being unexpectedly removed or modified in rare cases.</li>
<li>Media: Fix a collection of minor workflow and compatibility issues in the new media manager.</li>
<li>Networks: Suggest proper rewrite rules when creating a new network.</li>
<li>Prevent scheduled posts from being stripped of certain HTML, such as video embeds, when they are published.</li>
<li>Work around some misconfigurations that may have caused some JavaScript in the WordPress admin area to fail.</li>
<li>Suppress some warnings that could occur when a plugin misused the database or user APIs.</li>
</ul>
<p>Additionally, a bug affecting Windows servers running IIS can prevent updating from 3.5 to 3.5.1. If you receive the error &#8220;Destination directory for file streaming does not exist or is not writable,&#8221; you will need to <a href="http://codex.wordpress.org/Version_3.5.1">follow the steps outlined on the Codex</a>.</p>
<p>WordPress 3.5.1 also addresses the following security issues:</p>
<ul>
<li>A server-side request forgery vulnerability and remote port scanning using pingbacks. This vulnerability, which could potentially be used to expose information and compromise a site, affects all previous WordPress versions. This was fixed by the WordPress security team. We&#8217;d like to thank security researchers <a href="http://codeseekah.com/">Gennady Kovshenin</a> and <a href="http://www.ethicalhack3r.co.uk/">Ryan Dewhurst</a> for reviewing our work.</li>
<li>Two instances of cross-site scripting via shortcodes and post content. These issues were discovered by Jon Cave of the WordPress security team.</li>
<li>A cross-site scripting vulnerability in the external library Plupload. Thanks to the Moxiecode team for working with us on this, and for releasing Plupload 1.5.5 to address this issue.</li>
</ul>
<p><strong><a href="http://wordpress.org/download/">Download 3.5.1</a> or visit Dashboard → Updates in your site admin to update now.</strong></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2013/01/wordpress-3-5-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:17:"2012: A Look Back";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"http://wordpress.org/news/2013/01/2012-a-look-back/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/news/2013/01/2012-a-look-back/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 01 Jan 2013 02:22:20 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:13:"Uncategorized";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2525";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:340:"Another year is coming to a close, and it&#8217;s time to look back and reflect on what we&#8217;ve accomplished in the past twelve months. The WordPress community is stronger than ever, and some of the accomplishments of the past year are definitely worth remembering. Software Releases We had two major releases of the WordPress web [...]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"Jen Mylo";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:4441:"<p>Another year is coming to a close, and it&#8217;s time to look back and reflect on what we&#8217;ve accomplished in the past twelve months. The WordPress community is stronger than ever, and some of the accomplishments of the past year are definitely worth remembering.</p>
<h4>Software Releases</h4>
<p>We had two major releases of the WordPress web application with versions <a href="http://wordpress.org/news/2012/06/green/">3.4</a> and <a href="http://wordpress.org/news/2012/12/elvin/">3.5</a>, as well as 5 security releases during 2012. 3.4 included the theme customizer, while 3.5 became the long awaited &#8220;media release&#8221; featuring a new uploader and gallery management tool. 3.5 contained code contributions from more people than ever, and we hope to continue growing the contributor ranks in the year ahead. We currently have native apps on 6 mobile platforms &#8212; <a href="http://ios.wordpress.org/">iOS</a>, <a href="http://android.wordpress.org/">Android</a>, <a href="http://blackberry.wordpress.org/">Blackberry</a>, <a href="http://wpwindowsphone.wordpress.com/">Windows Phone</a>, <a href="http://nokia.wordpress.org/">Nokia</a>, and <a href="http://webos.wordpress.org/">WebOS</a> &#8212; and saw several updates there as well.</p>
<h4>Plugin Directory</h4>
<p>A number of improvements were made to the Plugin Directory in 2012. More cosmetic  updates, like the introduction of branded plugin page headers, make it a nicer browsing experience, while functional changes like better-integrated support forums, plugin reviews, and a favorites system made the plugin directory even more useful as a resource.</p>
<h4>The &#8220;Make&#8221; Network and Team Reps</h4>
<p>2012 was the year that saw the creation of <a href="http://make.wordpress.org/">Make.wordpress.org</a>, a network of sites for the teams of contributors responsible for the different areas of the WordPress project. Now anyone can follow along and get involved with the teams that work on <a href="http://make.wordpress.org/core/">core</a>, <a href="http://make.wordpress.org/themes/">theme review</a>, <a href="http://make.wordpress.org/support/">forum support</a>, <a href="http://make.wordpress.org/docs/">documentation</a>, and more. In 2013 we&#8217;ll work to improve these sites to make it easier to become a contributor. Each team also now has elected Team Reps, a new role that has already led to more cross-team communication. Team reps post each week to the <a href="https://make.wordpress.org/updates/">Updates blog</a> so that the other reps can keep up with what&#8217;s going on in other teams.</p>
<h4>WordPress Community Summit</h4>
<p>At the end of October, about 100 of the most influential and respected members of the WordPress community attended an inaugural <a href="https://make.wordpress.org/summit">summit</a> to discuss where we all stand, and to figure out where we go next with WordPress. A &#8220;conference of conversations,&#8221; this unconference made everyone an active participant, and while not every issue brought to the table was solved by the end of the event, the right questions were being asked.</p>
<h4>Meetup.com</h4>
<p>The WordPress Foundation now has a central account with Meetup.com. We&#8217;ve brought in a couple dozen existing meetup groups as a pilot to test the system, and are in the process of working with more existing meetups (as well as new ones) to join us so that local organizers won&#8217;t have to pay organizer dues and can get more support from the WordPress project.</p>
<h4>Internet Blackout Day</h4>
<p>We participated in the protest against SOPA/PIPA, Internet Blackout Day, on January 18. Though we usually stay out of politics, this campaign was important, and we not only participated in the blackout on WordPress.org, we encouraged our users to do so as well, and recommended plugins to provide blackout functionality. It was deemed the <a href="http://sopastrike.com/numbers/">largest online protest in history</a>.</p>
<h4>WordCamps</h4>
<p>And finally, it wouldn&#8217;t be a recap without counting up the <a href="http://wordcamp.org">WordCamps</a>! There were 67 WordCamps around the world in 2012, bringing together WordPress users, developers, and fans. If you didn&#8217;t make it to a WordCamp this year, maybe it can be one of your new year resolutions: <a href="http://central.wordcamp.org/schedule/">check the schedule</a> to find one near you!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:56:"http://wordpress.org/news/2013/01/2012-a-look-back/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:25:"WordPress 3.5 “Elvin”";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:40:"http://wordpress.org/news/2012/12/elvin/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:49:"http://wordpress.org/news/2012/12/elvin/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 11 Dec 2012 16:54:23 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2517";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:363:"It&#8217;s the most wonderful time of the year: a new WordPress release is available and chock-full of goodies to delight bloggers and developers alike. We&#8217;re calling this one &#8220;Elvin&#8221; in honor of drummer Elvin Jones, who played with John Coltrane in addition to many others. If you&#8217;ve been around WordPress a while, the most dramatic [...]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:20083:"<p>It&#8217;s the most wonderful time of the year: a new WordPress release <a href="http://wordpress.org/download/">is available</a> and chock-full of goodies to delight bloggers and developers alike. We&#8217;re calling this one &#8220;Elvin&#8221; in honor of <a href="http://en.wikipedia.org/wiki/Elvin_Jones">drummer Elvin Jones</a>, who played with John Coltrane in addition to many others.</p>
<p>If you&#8217;ve been around WordPress a while, the most dramatic new change you&#8217;ll notice is a completely re-imagined flow for uploading photos and creating galleries. Media has long been a friction point and we&#8217;ve listened hard and given a lot of thought into crafting this new system. 3.5 includes a new default theme, Twenty Twelve, which has a very clean mobile-first responsive design and works fantastic as a base for a CMS site. Finally we&#8217;ve spent a lot of time refreshing the styles of the dashboard, updating everything to be Retina-ready with beautiful high resolution graphics, a new color picker, and streamlining a couple of fewer-used sections of the admin.</p>
<p>Here&#8217;s a quick video overview of everything you can share with your friends:</p>
<div id="v-jQDfEbzZ-1" class="video-player"><embed id="v-jQDfEbzZ-1-video" src="http://s0.videopress.com/player.swf?v=1.03&amp;guid=jQDfEbzZ&amp;isDynamicSeeking=true" type="application/x-shockwave-flash" width="692" height="388" title="Introducing WordPress 3.5" wmode="direct" seamlesstabbing="true" allowfullscreen="true" allowscriptaccess="always" overstretch="true"></embed></div>
<h3>For Developers</h3>
<p>You can now put your (or anyone&#8217;s) WordPress.org username on the plugins page and see your favorite tagged ones, to make it easy to install them again when setting up a new site. There&#8217;s a new Tumblr importer. New installs no longer show the links manager. Finally for multisite developers <code>switch_to_blog()</code> is way faster and you can now install MS in a sub-directory. The <a href="http://underscorejs.org/">Underscore</a> and <a href="http://backbonejs.org/">Backbone</a> JavaScript libraries are now available. <a href="http://codex.wordpress.org/Version_3.5">The Codex has a pretty good summary of the developer features above and beyond this</a>, and you can always <a href="http://core.trac.wordpress.org/milestone/3.5">grab a warm beverage and explore Trac directly</a>.</p>
<h3>Percussion Section</h3>
<p>Behind every great release is great contributors. 3.5 had more people involved than any release before it:</p>
<p><a href="http://profiles.wordpress.org/aaroncampbell">Aaron D. Campbell</a>, <a href="http://profiles.wordpress.org/aaronholbrook">aaronholbrook</a>, <a href="http://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="http://profiles.wordpress.org/kawauso">Adam Harley</a>, <a href="http://profiles.wordpress.org/alyssonweb">akbortoli</a>, <a href="http://profiles.wordpress.org/alecrust">alecrust</a>, <a href="http://profiles.wordpress.org/xknown">Alex Concha</a>, <a href="http://profiles.wordpress.org/alexkingorg">Alex King</a>, <a href="http://profiles.wordpress.org/viper007bond">Alex Mills (Viper007Bond)</a>, <a href="http://profiles.wordpress.org/alexvorn2">alexvorn2</a>, <a href="http://profiles.wordpress.org/ampt">ampt</a>, <a href="http://profiles.wordpress.org/sabreuse">Amy Hendrix (sabreuse)</a>, <a href="http://profiles.wordpress.org/andrear">andrea.r</a>, <a href="http://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="http://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="http://profiles.wordpress.org/andrewryno">Andrew Ryno</a>, <a href="http://profiles.wordpress.org/andrewspittle">Andrew Spittle</a>, <a href="http://profiles.wordpress.org/andy">Andy Skelton</a>, <a href="http://profiles.wordpress.org/apokalyptik">apokalyptik</a>, <a href="http://profiles.wordpress.org/bainternet">Bainternet</a>, <a href="http://profiles.wordpress.org/barrykooij">Barry Kooij</a>, <a href="http://profiles.wordpress.org/bazza">bazza</a>, <a href="http://profiles.wordpress.org/bbrooks">bbrooks</a>, <a href="http://profiles.wordpress.org/casben79">Ben Casey</a>, <a href="http://profiles.wordpress.org/husobj">Ben Huson</a>, <a href="http://profiles.wordpress.org/benkulbertis">Ben Kulbertis</a>, <a href="http://profiles.wordpress.org/bergius">bergius</a>, <a href="http://profiles.wordpress.org/neoxx">Bernhard Riedl</a>, <a href="http://profiles.wordpress.org/betzster">betzster</a>, <a href="http://profiles.wordpress.org/bananastalktome">Billy (bananastalktome)</a>, <a href="http://profiles.wordpress.org/bolo1988">bolo1988</a>, <a href="http://profiles.wordpress.org/bradparbs">bradparbs</a>, <a href="http://profiles.wordpress.org/bradthomas127">bradthomas127</a>, <a href="http://profiles.wordpress.org/bradyvercher">Brady Vercher</a>, <a href="http://profiles.wordpress.org/brandondove">Brandon Dove</a>, <a href="http://profiles.wordpress.org/brianlayman">Brian Layman</a>, <a href="http://profiles.wordpress.org/rzen">Brian Richards</a>, <a href="http://profiles.wordpress.org/sennza">Bronson Quick</a>, <a href="http://profiles.wordpress.org/bpetty">Bryan Petty</a>, <a href="http://profiles.wordpress.org/cannona">cannona</a>, <a href="http://profiles.wordpress.org/sixhours">Caroline Moore</a>, <a href="http://profiles.wordpress.org/caspie">Caspie</a>, <a href="http://profiles.wordpress.org/cdog">cdog</a>, <a href="http://profiles.wordpress.org/thee17">Charles Frees-Melvin</a>, <a href="http://profiles.wordpress.org/chellycat">chellycat</a>, <a href="http://profiles.wordpress.org/chexee">Chelsea Otakan</a>, <a href="http://profiles.wordpress.org/chouby">Chouby</a>, <a href="http://profiles.wordpress.org/c3mdigital">Chris Olbekson</a>, <a href="http://profiles.wordpress.org/cfinke">Christopher Finke</a>, <a href="http://profiles.wordpress.org/chriswallace">Chris Wallace</a>, <a href="http://profiles.wordpress.org/corvannoorloos">Cor van Noorloos</a>, <a href="http://profiles.wordpress.org/scribu">Cristi Burc&#259;</a>, <a href="http://profiles.wordpress.org/mrroundhill">Dan</a>, <a href="http://profiles.wordpress.org/dan-rivera">Dan Rivera</a>, <a href="http://profiles.wordpress.org/koopersmith">Daryl Koopersmith</a>, <a href="http://profiles.wordpress.org/lessbloat">Dave Martin</a>, <a href="http://profiles.wordpress.org/deltafactory">deltafactory</a>, <a href="http://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="http://profiles.wordpress.org/djzone">DjZoNe</a>, <a href="http://profiles.wordpress.org/dllh">dllh</a>, <a href="http://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="http://profiles.wordpress.org/doublesharp">doublesharp</a>, <a href="http://profiles.wordpress.org/drewapicture">Drew Jaynes (DrewAPicture)</a>, <a href="http://profiles.wordpress.org/drewstrojny">Drew Strojny</a>, <a href="http://profiles.wordpress.org/eddiemoya">Eddie Moya</a>, <a href="http://profiles.wordpress.org/elyobo">elyobo</a>, <a href="http://profiles.wordpress.org/emiluzelac">Emil Uzelac</a>, <a href="http://profiles.wordpress.org/empireoflight">Empireoflight</a>, <a href="http://profiles.wordpress.org/ericlewis">Eric Andrew Lewis</a>, <a href="http://profiles.wordpress.org/ethitter">Erick Hitter</a>, <a href="http://profiles.wordpress.org/ericmann">Eric Mann</a>, <a href="http://profiles.wordpress.org/ericwahlforss">ericwahlforss</a>, <a href="http://profiles.wordpress.org/evansolomon">Evan Solomon</a>, <a href="http://profiles.wordpress.org/fadingdust">fadingdust</a>, <a href="http://profiles.wordpress.org/f-j-kaiser">F J Kaiser</a>, <a href="http://profiles.wordpress.org/foxinni">foxinni</a>, <a href="http://profiles.wordpress.org/garyc40">Gary Cao</a>, <a href="http://profiles.wordpress.org/garyj">Gary Jones</a>, <a href="http://profiles.wordpress.org/pento">Gary Pendergast</a>, <a href="http://profiles.wordpress.org/geertdd">GeertDD</a>, <a href="http://profiles.wordpress.org/mamaduka">George Mamadashvili</a>, <a href="http://profiles.wordpress.org/georgestephanis">George Stephanis</a>, <a href="http://profiles.wordpress.org/ghosttoast">GhostToast</a>, <a href="http://profiles.wordpress.org/gnarf">gnarf</a>, <a href="http://profiles.wordpress.org/goldenapples">goldenapples</a>, <a href="http://profiles.wordpress.org/webord">Gustavo Bordoni</a>, <a href="http://profiles.wordpress.org/hakre">hakre</a>, <a href="http://profiles.wordpress.org/hanni">hanni</a>, <a href="http://profiles.wordpress.org/hardy101">hardy101</a>, <a href="http://profiles.wordpress.org/hebbet">hebbet</a>, <a href="http://profiles.wordpress.org/helenyhou">Helen Hou-Sandi</a>, <a href="http://profiles.wordpress.org/hugobaeta">Hugo Baeta</a>, <a href="http://profiles.wordpress.org/iamfriendly">iamfriendly</a>, <a href="http://profiles.wordpress.org/iandstewart">Ian Stewart</a>, <a href="http://profiles.wordpress.org/ikailo">ikailo</a>, <a href="http://profiles.wordpress.org/ipstenu">Ipstenu (Mika Epstein)</a>, <a href="http://profiles.wordpress.org/itworx">itworx</a>, <a href="http://profiles.wordpress.org/j-idris">j-idris</a>, <a href="http://profiles.wordpress.org/jakemgold">Jake Goldman</a>, <a href="http://profiles.wordpress.org/jakubtyrcha">jakub.tyrcha</a>, <a href="http://profiles.wordpress.org/jamescollins">James Collins</a>, <a href="http://profiles.wordpress.org/jammitch">jammitch</a>, <a href="http://profiles.wordpress.org/jane">Jane Wells</a>, <a href="http://profiles.wordpress.org/japh">Japh</a>, <a href="http://profiles.wordpress.org/jarretc">JarretC</a>, <a href="http://profiles.wordpress.org/madtownlems">Jason Lemahieu (MadtownLems)</a>, <a href="http://profiles.wordpress.org/javert03">javert03</a>, <a href="http://profiles.wordpress.org/jbrinley">jbrinley</a>, <a href="http://profiles.wordpress.org/jcakec">jcakec</a>, <a href="http://profiles.wordpress.org/jblz">Jeff Bowen</a>, <a href="http://profiles.wordpress.org/jeffsebring">Jeff Sebring</a>, <a href="http://profiles.wordpress.org/jeremyfelt">Jeremy Felt</a>, <a href="http://profiles.wordpress.org/hd-j">Jeremy Herve</a>, <a href="http://profiles.wordpress.org/jerrysarcastic">Jerry Bates (JerrySarcastic)</a>, <a href="http://profiles.wordpress.org/jayjdk">Jesper Johansen (Jayjdk)</a>, <a href="http://profiles.wordpress.org/jndetlefsen">jndetlefsen</a>, <a href="http://profiles.wordpress.org/joehoyle">Joe Hoyle</a>, <a href="http://profiles.wordpress.org/joelhardi">joelhardi</a>, <a href="http://profiles.wordpress.org/jkudish">Joey Kudish</a>, <a href="http://profiles.wordpress.org/johnbillion">John Blackbourn (johnbillion)</a>, <a href="http://profiles.wordpress.org/johnjamesjacoby">John James Jacoby</a>, <a href="http://profiles.wordpress.org/johnpbloch">John P. Bloch</a>, <a href="http://profiles.wordpress.org/jond3r">Jonas Bolinder</a>, <a href="http://profiles.wordpress.org/jondavidjohn">Jonathan D. Johnson</a>, <a href="http://profiles.wordpress.org/duck_">Jon Cave</a>, <a href="http://profiles.wordpress.org/joostdekeijzer">joostdekeijzer</a>, <a href="http://profiles.wordpress.org/koke">Jorge Bernal</a>, <a href="http://profiles.wordpress.org/josephscott">Joseph Scott</a>, <a href="http://profiles.wordpress.org/pottersys">Juan</a>, <a href="http://profiles.wordpress.org/justinsainton">Justin Sainton</a>, <a href="http://profiles.wordpress.org/jtsternberg">Justin Sternberg</a>, <a href="http://profiles.wordpress.org/greenshady">Justin Tadlock</a>, <a href="http://profiles.wordpress.org/trepmal">Kailey Lampert (trepmal)</a>, <a href="http://profiles.wordpress.org/ryelle">Kelly Dwan</a>, <a href="http://profiles.wordpress.org/keruspe">Keruspe</a>, <a href="http://profiles.wordpress.org/kitchin">kitchin</a>, <a href="http://profiles.wordpress.org/knutsp">Knut Sparhell</a>, <a href="http://profiles.wordpress.org/kovshenin">Konstantin Kovshenin</a>, <a href="http://profiles.wordpress.org/obenland">Konstantin Obenland</a>, <a href="http://profiles.wordpress.org/kopepasah">Kopepasah</a>, <a href="http://profiles.wordpress.org/klagraff">Kristopher Lagraff</a>, <a href="http://profiles.wordpress.org/kurtpayne">Kurt Payne</a>, <a href="http://profiles.wordpress.org/kyrylo">Kyrylo</a>, <a href="http://profiles.wordpress.org/lancewillett">Lance Willett</a>, <a href="http://profiles.wordpress.org/larysa">Larysa Mykhas</a>, <a href="http://profiles.wordpress.org/leogermani">leogermani</a>, <a href="http://profiles.wordpress.org/lesteph">lesteph</a>, <a href="http://profiles.wordpress.org/linuxologos">linuxologos</a>, <a href="http://profiles.wordpress.org/ldebrouwer">Luc De Brouwer</a>, <a href="http://profiles.wordpress.org/lgedeon">Luke Gedeon</a>, <a href="http://profiles.wordpress.org/latz">Lutz Schroer</a>, <a href="http://profiles.wordpress.org/mailnew2ster">mailnew2ster</a>, <a href="http://profiles.wordpress.org/targz-1">Manuel Schmalstieg</a>, <a href="http://profiles.wordpress.org/maor">Maor Chasen</a>, <a href="http://profiles.wordpress.org/mimecine">Marco</a>, <a href="http://profiles.wordpress.org/marcuspope">MarcusPope</a>, <a href="http://profiles.wordpress.org/markjaquith">Mark Jaquith</a>, <a href="http://profiles.wordpress.org/markoheijnen">Marko Heijnen</a>, <a href="http://profiles.wordpress.org/martythornley">MartyThornley</a>, <a href="http://profiles.wordpress.org/mattdanner">mattdanner</a>, <a href="http://profiles.wordpress.org/bigdawggi">Matthew Richmond</a>, <a href="http://profiles.wordpress.org/sivel">Matt Martz</a>, <a href="http://profiles.wordpress.org/iammattthomas">Matt Thomas</a>, <a href="http://profiles.wordpress.org/mattwiebe">Matt Wiebe</a>, <a href="http://profiles.wordpress.org/mattyrob">mattyrob</a>, <a href="http://profiles.wordpress.org/maxcutler">Max Cutler</a>, <a href="http://profiles.wordpress.org/melchoyce">Mel Choyce</a>, <a href="http://profiles.wordpress.org/merty">Mert Yazicioglu</a>, <a href="http://profiles.wordpress.org/mdawaffe">Michael Adams (mdawaffe)</a>, <a href="http://profiles.wordpress.org/mfields">Michael Fields</a>, <a href="http://profiles.wordpress.org/mbijon">Mike Bijon</a>, <a href="http://profiles.wordpress.org/mdgl">Mike Glendinning</a>, <a href="http://profiles.wordpress.org/mikehansenme">Mike Hansen</a>, <a href="http://profiles.wordpress.org/mikelittle">Mike Little</a>, <a href="http://profiles.wordpress.org/mikeschinkel">Mike Schinkel</a>, <a href="http://profiles.wordpress.org/DH-Shredder">Mike Schroder</a>, <a href="http://profiles.wordpress.org/toppa">Mike Toppa</a>, <a href="http://profiles.wordpress.org/dimadin">Milan Dinic</a>, <a href="http://profiles.wordpress.org/mitchoyoshitaka">mitcho (Michael Yoshitaka Erlewine)</a>, <a href="http://profiles.wordpress.org/batmoo">Mohammad Jangda</a>, <a href="http://profiles.wordpress.org/mohanjith">mohanjith</a>, <a href="http://profiles.wordpress.org/mpvanwinkle77">mpvanwinkle77</a>, <a href="http://profiles.wordpress.org/usermrpapa">Mr Papa</a>, <a href="http://profiles.wordpress.org/murky">murky</a>, <a href="http://profiles.wordpress.org/Nao">Naoko Takano</a>, <a href="http://profiles.wordpress.org/alex-ye">Nashwan Doaqan</a>, <a href="http://profiles.wordpress.org/niallkennedy">Niall Kennedy</a>, <a href="http://profiles.wordpress.org/nbachiyski">Nikolay Bachiyski</a>, <a href="http://profiles.wordpress.org/ntm">ntm</a>, <a href="http://profiles.wordpress.org/nvartolomei">nvartolomei</a>, <a href="http://profiles.wordpress.org/pavelevap">pavelevap</a>, <a href="http://profiles.wordpress.org/pdclark">pdclark</a>, <a href="http://profiles.wordpress.org/petemall">Pete Mall</a>, <a href="http://profiles.wordpress.org/westi">Peter Westwood</a>, <a href="http://profiles.wordpress.org/pas5027">Pete Schuster</a>, <a href="http://profiles.wordpress.org/philiparthurmoore">Philip Arthur Moore</a>, <a href="http://profiles.wordpress.org/phill_brown">Phill Brown</a>, <a href="http://profiles.wordpress.org/picklepete">picklepete</a>, <a href="http://profiles.wordpress.org/picklewagon">Picklewagon</a>, <a href="http://profiles.wordpress.org/nprasath002">Prasath Nadarajah</a>, <a href="http://profiles.wordpress.org/r-a-y">r-a-y</a>, <a href="http://profiles.wordpress.org/ramiy">Rami Yushuvaev</a>, <a href="http://profiles.wordpress.org/moraleidame">Ricardo Moraleida</a>, <a href="http://profiles.wordpress.org/miqrogroove">Robert Chapin (miqrogroove)</a>, <a href="http://profiles.wordpress.org/wet">Robert Wetzlmayr</a>, <a href="http://profiles.wordpress.org/wpmuguru">Ron Rennick</a>, <a href="http://profiles.wordpress.org/rstern">rstern</a>, <a href="http://profiles.wordpress.org/ryan">Ryan Boren</a>, <a href="http://profiles.wordpress.org/ryanimel">Ryan Imel</a>, <a href="http://profiles.wordpress.org/ryanjkoehler">Ryan Koehler</a>, <a href="http://profiles.wordpress.org/markel">Ryan Markel</a>, <a href="http://profiles.wordpress.org/rmccue">Ryan McCue</a>, <a href="http://profiles.wordpress.org/zeo">Safirul Alredha</a>, <a href="http://profiles.wordpress.org/solarissmoke">Samir Shah</a>, <a href="http://profiles.wordpress.org/gluten">Sam Margulies</a>, <a href="http://profiles.wordpress.org/otto42">Samuel Wood (Otto)</a>, <a href="http://profiles.wordpress.org/saracannon">sara cannon</a>, <a href="http://profiles.wordpress.org/gandham">Satish Gandham</a>, <a href="http://profiles.wordpress.org/scottgonzalez">scott.gonzalez</a>, <a href="http://profiles.wordpress.org/sc0ttkclark">Scott Kingsley Clark</a>, <a href="http://profiles.wordpress.org/coffee2code">Scott Reilly</a>, <a href="http://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="http://profiles.wordpress.org/greglone">ScreenfeedFr</a>, <a href="http://profiles.wordpress.org/sergeysbetkenovgaroru">sergey.s.betke</a>, <a href="http://profiles.wordpress.org/sergeybiryukov">Sergey Biryukov</a>, <a href="http://profiles.wordpress.org/pross">Simon Prosser</a>, <a href="http://profiles.wordpress.org/simonwheatley">Simon Wheatley</a>, <a href="http://profiles.wordpress.org/sirzooro">sirzooro</a>, <a href="http://profiles.wordpress.org/ssamture">ssamture</a>, <a href="http://profiles.wordpress.org/sterlo">sterlo</a>, <a href="http://profiles.wordpress.org/sumindmitriy">sumindmitriy</a>, <a href="http://profiles.wordpress.org/sushkov">sushkov</a>, <a href="http://profiles.wordpress.org/swekitsune">swekitsune</a>, <a href="http://profiles.wordpress.org/iamtakashi">Takashi Irie</a>, <a href="http://profiles.wordpress.org/taylorde">Taylor Dewey</a>, <a href="http://profiles.wordpress.org/tlovett1">Taylor Lovett</a>, <a href="http://profiles.wordpress.org/saltcod">Terry Sutton</a>, <a href="http://profiles.wordpress.org/griffinjt">Thomas Griffin</a>, <a href="http://profiles.wordpress.org/tott">Thorsten Ott</a>, <a href="http://profiles.wordpress.org/timbeks">timbeks</a>, <a href="http://profiles.wordpress.org/timfs">timfs</a>, <a href="http://profiles.wordpress.org/tmoorewp">Tim Moore</a>, <a href="http://profiles.wordpress.org/tobiasbg">TobiasBg</a>, <a href="http://profiles.wordpress.org/tomasm">TomasM</a>, <a href="http://profiles.wordpress.org/tomauger">Tom Auger</a>, <a href="http://profiles.wordpress.org/tommcfarlin">tommcfarlin</a>, <a href="http://profiles.wordpress.org/willmot">Tom Willmot</a>, <a href="http://profiles.wordpress.org/toscho">toscho</a>, <a href="http://profiles.wordpress.org/wpsmith">Travis Smith</a>, <a href="http://profiles.wordpress.org/vhauri">Vasken Hauri</a>, <a href="http://profiles.wordpress.org/viniciusmassuchetto">Vinicius Massuchetto</a>, <a href="http://profiles.wordpress.org/lightningspirit">Vitor Carvalho</a>, <a href="http://profiles.wordpress.org/waclawjacek">Waclaw</a>, <a href="http://profiles.wordpress.org/waldojaquith">WaldoJaquith</a>, <a href="http://profiles.wordpress.org/wojtekszkutnik">Wojtek Szkutnik</a>, <a href="http://profiles.wordpress.org/xibe">Xavier Borderie</a>, <a href="http://profiles.wordpress.org/yoavf">Yoav Farhi</a>, <a href="http://profiles.wordpress.org/yogi-t">Yogi T</a>, <a href="http://profiles.wordpress.org/tollmanz">Zack Tollman</a>, and <a href="http://profiles.wordpress.org/zamoose">ZaMoose</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:45:"http://wordpress.org/news/2012/12/elvin/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WordPress 3.5 Release Candidate 3";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:68:"http://wordpress.org/news/2012/12/wordpress-3-5-release-candidate-3/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:77:"http://wordpress.org/news/2012/12/wordpress-3-5-release-candidate-3/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 04 Dec 2012 08:37:39 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:7:"Testing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:68:"http://wordpress.org/news/2012/12/wordpress-3-5-release-candidate-3/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:339:"The third release candidate for WordPress 3.5 is now available. We&#8217;ve made a number of changes over the last week since RC2 that we can&#8217;t wait to get into your hands. Hope you&#8217;re ready to do some testing! Final UI improvements for the new media manager, based on lots of great feedback. Show more information about [...]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1950:"<p>The third release candidate for WordPress 3.5 is now available. We&#8217;ve made a number of changes over the last week since <a title="WordPress 3.5 Release Candidate 2" href="http://wordpress.org/news/2012/11/wordpress-3-5-release-candidate-2/">RC2</a> that we can&#8217;t wait to get into your hands. Hope you&#8217;re ready to do some testing!</p>
<ul>
<li><span style="line-height: 13px">Final UI improvements for the new media manager, based on lots of great feedback.</span></li>
<li>Show more information about uploading errors when they occur.</li>
<li>When inserting an image into a post, don&#8217;t forget the alternative text.</li>
<li>Fixes for the new admin button styles.</li>
<li>Improvements for mobile devices, Internet Explorer, and right-to-left languages.</li>
<li>Fix cookies for subdomain installs when multisite is installed in a subdirectory.</li>
<li>Fix ms-files.php rewriting for very old multisite installs.</li>
</ul>
<p>At this point, we only have a <a href="http://core.trac.wordpress.org/report/5">few minor issues</a> left. If all goes well, you will see WordPress 3.5 very soon. If you run into any issues, please post to the <a href="http://wordpress.org/support/forum/alphabeta/">Alpha/Beta area in the support forums</a>.</p>
<p>If you&#8217;d like to know what to test, visit the About page (<strong><img style="vertical-align: middle" alt="" src="http://wordpress.org/wp-content/themes/twentyten/images/wordpress.png" /> → About</strong> in the toolbar) and check out the list of features. This is still development software, so your boss may get mad if you install this on a live site. To test WordPress 3.5, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you&#8217;ll want &#8220;bleeding edge nightlies&#8221;). Or you can <a href="http://wordpress.org/wordpress-3.5-RC3.zip">download the release candidate here (zip)</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:73:"http://wordpress.org/news/2012/12/wordpress-3-5-release-candidate-3/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WordPress 3.5 Release Candidate 2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:68:"http://wordpress.org/news/2012/11/wordpress-3-5-release-candidate-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:77:"http://wordpress.org/news/2012/11/wordpress-3-5-release-candidate-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 29 Nov 2012 19:55:12 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:7:"Testing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2494";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:339:"The second release candidate for WordPress 3.5 is now available for download and testing. We&#8217;re still working on about a dozen remaining issues, but we hope to deliver WordPress 3.5 to your hands as early as next week. If you&#8217;d like to know what to test, visit the About page ( → About in the toolbar) and check out [...]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1509:"<p>The second release candidate for WordPress 3.5 is now available for download and testing.</p>
<p>We&#8217;re still working on about a dozen remaining issues, but we hope to deliver WordPress 3.5 to your hands as early as next week. If you&#8217;d like to know what to test, visit the About page (<strong><img alt="" src="http://wordpress.org/wp-content/themes/twentyten/images/wordpress.png" /> → About</strong> in the toolbar) and check out the list of features! As usual, this is still development software and we suggest you do not install this on a live site unless you are adventurous.</p>
<p><strong>Think you&#8217;ve found a bug?</strong> Please post to the <a href="http://wordpress.org/support/forum/alphabeta/">Alpha/Beta area in the support forums</a>.</p>
<p><strong>Developers,</strong> please continue to test your plugins and themes, so that if there is a compatibility issue, we can figure it out before the final release. You can find our <a href="http://core.trac.wordpress.org/report/6">list of known issues here</a>.</p>
<p>To test WordPress 3.5, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you&#8217;ll want &#8220;bleeding edge nightlies&#8221;). Or you can <a href="http://wordpress.org/wordpress-3.5-RC2.zip">download the release candidate here (zip)</a>.</p>
<p><em>&#8211;<br />
</em><em>We are getting close<br />
</em><em>Should have asked for haiku help<br />
</em><em>Please test RC2</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:73:"http://wordpress.org/news/2012/11/wordpress-3-5-release-candidate-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:31:"WordPress 3.5 Release Candidate";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:66:"http://wordpress.org/news/2012/11/wordpress-3-5-release-candidate/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:75:"http://wordpress.org/news/2012/11/wordpress-3-5-release-candidate/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 22 Nov 2012 13:35:09 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:7:"Testing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2479";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:341:"The first release candidate for WordPress 3.5 is now available. We hope to ship WordPress 3.5 in two weeks. But to do that, we need your help! If you haven&#8217;t tested 3.5 yet, there&#8217;s no time like the present. (The oft-repeated warning: Please, not on a live site, unless you&#8217;re adventurous.) Think you&#8217;ve found a [...]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1545:"<p>The first release candidate for WordPress 3.5 is now available.</p>
<p>We hope to ship WordPress 3.5 in <em>two weeks</em>. But to do that, we need your help! If you haven&#8217;t tested 3.5 yet, there&#8217;s no time like the present. (The oft-repeated warning: Please, not on a live site, unless you&#8217;re adventurous.)</p>
<p><strong>Think you&#8217;ve found a bug?</strong> Please post to the <a href="http://wordpress.org/support/forum/alphabeta/">Alpha/Beta area in the support forums</a>. If any known issues come up, you’ll be able to <a href="http://core.trac.wordpress.org/report/6">find them here</a>. <strong>Developers,</strong> please test your plugins and themes, so that if there is a compatibility issue, we can figure it out before the final release.</p>
<p>To test WordPress 3.5, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you&#8217;ll want &#8220;bleeding edge nightlies&#8221;). Or you can <a href="http://wordpress.org/wordpress-3.5-RC1.zip">download the release candidate here (zip)</a>.</p>
<p>If you&#8217;d like to know what to <del>break</del> test, visit the About page (<strong><img style="vertical-align: text-top" alt="" src="http://wordpress.org/wp-content/themes/twentyten/images/wordpress.png" /> → About</strong> in the toolbar) and check out the list of features! Trust me, you want to try out media.</p>
<p><em>Release candidate</em><br />
<em>Three point five in two weeks time</em><br />
<em>Please test all the things</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:71:"http://wordpress.org/news/2012/11/wordpress-3-5-release-candidate/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:48:"
		
		
		
		
		
				
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 3.5 Beta 3";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2012/11/wordpress-3-5-beta-3/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/news/2012/11/wordpress-3-5-beta-3/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 13 Nov 2012 04:26:23 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:3:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:7:"Testing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2467";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:341:"The third beta release of WordPress 3.5 is now available for download and testing. Hey, developers! We expect to WordPress 3.5 to be ready in just a few short weeks. Please, please test your plugins and themes against beta 3. Media management has been rewritten, and we&#8217;ve taken great pains to ensure most plugins will work the [...]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2677:"<p>The third beta release of WordPress 3.5 is now available for download and testing.</p>
<p><strong>Hey, developers!</strong> We expect to WordPress 3.5 to be ready in just a few short weeks. <em>Please, please</em> test your plugins and themes against beta 3. Media management has been rewritten, and we&#8217;ve taken great pains to ensure most plugins will work the same as before, but we&#8217;re not perfect. We would like to hear about any incompatibilities we&#8217;ve caused so we can work with you to address them <em>before</em> release, rather than after. I think you&#8217;ll agree it&#8217;s much better that way. <img src=\'http://wordpress.org/news/wp-includes/images/smilies/icon_smile.gif\' alt=\':-)\' class=\'wp-smiley\' /> </p>
<p>To test WordPress 3.5, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="http://wordpress.org/wordpress-3.5-beta3.zip">download the beta here</a> (zip). For more on 3.5, <a title="WordPress 3.5 Beta 1" href="http://wordpress.org/news/2012/09/wordpress-3-5-beta-1/">check out the extensive Beta 1 blog post</a>, which covers what’s new in version 3.5 and how you can help. We made <a href="http://core.trac.wordpress.org/log/trunk?action=stop_on_copy&amp;mode=stop_on_copy&amp;rev=22557&amp;stop_rev=22224&amp;limit=400">more than 300 changes</a> since <a href="http://wordpress.org/news/2012/10/wordpress-3-5-beta-2/">beta 2</a>. <span style="line-height: 13px">At this point, the Add Media dialog is complete, and we&#8217;re now just working on fixing up inserting images into the editor. We&#8217;ve also u</span>pdated to jQuery UI 1.9.1, SimplePie 1.3.1, and TinyMCE 3.5.7.</p>
<p>The usual warnings apply: We can see the light at the end of the tunnel, but this is software still in development, so we don’t recommend that you run it on a production site. Set up a test site to play with the new version.</p>
<p>As always, if you think you’ve found a bug, you can post to the <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. Or, if you’re comfortable writing a reproducible bug report, <a href="http://core.trac.wordpress.org/">file one on the WordPress Trac</a>. There, you can also find <a href="http://core.trac.wordpress.org/report/5">a list of known bugs</a> and <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=3.5">everything we’ve fixed</a> so far.</p>
<p><em>Beta three is out</em><br />
<em>Soon, a release candidate</em><br />
<em>Three point five is near</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/news/2012/11/wordpress-3-5-beta-3/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 3.5 Beta 2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2012/10/wordpress-3-5-beta-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/news/2012/10/wordpress-3-5-beta-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 13 Oct 2012 00:02:08 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:7:"Testing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2458";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:342:"Two weeks after the first beta, WordPress 3.5 Beta 2 is now available for download and testing. This is software still in development, so we don’t recommend that you run it on a production site. Set up a test site to play with the new version. To test WordPress 3.5, try the WordPress Beta Tester plugin (you’ll want “bleeding [...]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1856:"<p>Two weeks after the first beta, WordPress 3.5 Beta 2 is now available for download and testing.</p>
<p>This is software still in development, so we don’t recommend that you run it on a production site. Set up a test site to play with the new version. To test WordPress 3.5, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="http://wordpress.org/wordpress-3.5-beta2.zip">download the beta here</a> (zip).</p>
<p>For more, <a title="WordPress 3.5 Beta 1" href="http://wordpress.org/news/2012/09/wordpress-3-5-beta-1/"><strong>check out the extensive Beta 1 blog post</strong></a>, which covers what&#8217;s new in version 3.5 and how you can help. What&#8217;s new since beta 1? I&#8217;m glad you asked:</p>
<ul>
<li>New workflow for working with image galleries, including drag-and-drop reordering and quick caption editing.</li>
<li>New image editing API. (<a title="Ticket 6821" href="http://core.trac.wordpress.org/ticket/6821">#6821</a>)</li>
<li><del>New user interface for setting static front pages for the Reading Settings screen. (<a title="Ticket 16379" href="http://core.trac.wordpress.org/ticket/16379">#16379</a>)</del></li>
</ul>
<p>As always, if you think you’ve found a bug, you can post to the <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. Or, if you’re comfortable writing a reproducible bug report, <a href="http://core.trac.wordpress.org/">file one on the WordPress Trac</a>. There, you can also find <a href="http://core.trac.wordpress.org/report/5">a list of known bugs</a> and <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=3.5">everything we’ve fixed</a> so far. Happy testing!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/news/2012/10/wordpress-3-5-beta-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"WordPress 3.5 Beta 1 (and a bonus!)";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2012/09/wordpress-3-5-beta-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/news/2012/09/wordpress-3-5-beta-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 27 Sep 2012 22:37:49 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:7:"Testing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2443";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:376:"I&#8217;m excited to announce the availability of WordPress 3.5 Beta 1. This is software still in development and we really don’t recommend that you run it on a production site — set up a test site just to play with the new version. To test WordPress 3.5, try the WordPress Beta Tester plugin (you’ll want “bleeding edge nightlies”). Or you can download [...]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:6696:"<p>I&#8217;m excited to announce the availability of WordPress 3.5 Beta 1.</p>
<p>This is software still in development and <strong>we <em>really</em> don’t recommend that you run it on a production site</strong> — set up a test site just to play with the new version. To test WordPress 3.5, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="http://wordpress.org/wordpress-3.5-beta-1.zip">download the beta here</a> (zip).</p>
<p>In just three short months, we&#8217;ve already made a few hundred changes to improve your WordPress experience. The biggest thing we&#8217;ve been working on is overhauling the media experience from the ground up. We&#8217;ve made it all fair game: How you upload photos, arrange galleries, insert images into posts, and more. It&#8217;s still rough around the edges and some pieces are missing — which means now is the <em>perfect</em> time to test it out, report issues, and help shape our headline feature.</p>
<p>As always, if you think you’ve found a bug, you can post to the <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. Or, if you’re comfortable writing a reproducible bug report, <a href="http://core.trac.wordpress.org/">file one on the WordPress Trac</a>. There, you can also find <a href="http://core.trac.wordpress.org/report/5">a list of known bugs</a> and <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=3.5">everything we&#8217;ve fixed</a> so far.</p>
<p>Here&#8217;s some more of what&#8217;s new:</p>
<ul>
<li><strong>Appearance: </strong>A simplified welcome screen. A new color picker. And the all-HiDPI (retina) dashboard.</li>
<li><strong>Accessibility:</strong> Keyboard navigation and screen reader support have both been improved.</li>
<li><strong>Plugins: </strong>You can browse and install plugins you&#8217;ve marked as favorites on WordPress.org, directly from your dashboard.</li>
<li><strong>Mobile: </strong>It&#8217;ll be easier to link up your WordPress install with <a href="http://wordpress.org/extend/mobile/">our mobile apps</a>, as XML-RPC is now enabled by default.</li>
<li><strong>Links: </strong>We&#8217;ve hidden the Link Manager for new installs. (Don&#8217;t worry, <a href="http://wordpress.org/extend/plugins/link-manager/">there&#8217;s a plugin for that</a>.)</li>
</ul>
<p><strong>Developers: </strong>We love you. We do. And one of the things we strive to do with every release is be compatible with all existing plugins and themes. To make sure we don&#8217;t break anything, we need your help. <strong>Please, please test your plugins and themes against 3.5.</strong> If something isn&#8217;t quite right, please let us know. (Chances are, it wasn&#8217;t intentional.) And despite all of the changes to media, we&#8217;re still aiming to be backwards compatible with plugins that make changes to the existing media library. It&#8217;s a tall task, and it means we need your help.</p>
<p>Here&#8217;s some more things we think developers will enjoy (and should test their plugins and themes against):</p>
<ul>
<li><strong>External libraries updated:</strong> TinyMCE  <del>3.5.6</del> 3.5.7. SimplePie <del>1.3</del> 1.3.1. jQuery <del>1.8.2</del> 1.8.3. jQuery UI <del>1.9 (and it&#8217;s not even released yet)</del> 1.9.2. We&#8217;ve also added Backbone 0.9.2 and Underscore <del>1.3.3</del> 1.4.2, and you can use protocol-relative links when enqueueing scripts and styles. (<a href="http://core.trac.wordpress.org/ticket/16560">#16560</a>)</li>
<li><strong>WP Query:</strong> You can now ask to receive posts in the order specified by <code>post__in</code>. (<a href="http://core.trac.wordpress.org/ticket/13729">#13729</a>)</li>
<li><strong>XML-RPC:</strong> New user management, profile editing, and post revision methods. We&#8217;ve also removed AtomPub. (<a href="http://core.trac.wordpress.org/ticket/18428">#18428</a>, <a href="http://core.trac.wordpress.org/ticket/21397">#21397</a>, <a href="http://core.trac.wordpress.org/ticket/21866">#21866</a>)</li>
<li><strong>Multisite: </strong>switch_to_blog() is now used in more places, is faster, and more reliable. Also: You can now use multisite in a subdirectory, and uploaded files no longer go through ms-files (for new installs). (<a href="http://core.trac.wordpress.org/ticket/21434">#21434</a>, <a href="http://core.trac.wordpress.org/ticket/19796">#19796</a>, <a href="http://core.trac.wordpress.org/ticket/19235">#19235</a>)</li>
<li><strong>TinyMCE: </strong>We&#8217;ve added an experimental API for &#8220;views&#8221; which you can use to offer previews and interaction of elements from the visual editor. (<a href="http://core.trac.wordpress.org/ticket/21812">#21812</a>)</li>
<li><strong>Posts API: </strong>Major performance improvements when working with hierarchies of pages and post ancestors. Also, you can now &#8220;turn on&#8221; native custom columns for taxonomies on edit post screens. (<a href="http://core.trac.wordpress.org/ticket/11399">#11399</a>, <a href="http://core.trac.wordpress.org/ticket/21309">#21309</a>, <a href="http://core.trac.wordpress.org/ticket/21240">#21240</a>)</li>
<li><strong>Comments API:</strong> Search for comments of a particular status, or with a meta query (same as with WP_Query). (<a href="http://core.trac.wordpress.org/ticket/21101">#21101</a>, <a href="http://core.trac.wordpress.org/ticket/21003">#21003</a>)</li>
<li><strong>oEmbed: </strong>We&#8217;ve added support for a few oEmbed providers, and we now handle SSL links. (<a href="http://core.trac.wordpress.org/ticket/15734">#15734</a>, <a href="http://core.trac.wordpress.org/ticket/21635">#21635</a>, <a href="http://core.trac.wordpress.org/ticket/16996">#16996</a>, <a href="http://core.trac.wordpress.org/ticket/20102">#20102</a>)</li>
</ul>
<p>We&#8217;re looking forward to your feedback. If you break it (find a bug), please report it, and if you’re a developer, try to help us fix it. We&#8217;ve already had more than 200 contributors to version 3.5 — come join us!</p>
<h3>And as promised, a bonus:</h3>
<p>We&#8217;re planning a December 5 release for WordPress 3.5. But, we have a special offering for you, today. The newest default theme for WordPress, <strong>Twenty</strong><strong> Twelve</strong>, is now <a href="http://wordpress.org/extend/themes/twentytwelve">available for download</a> from the WordPress themes directory. It&#8217;s a gorgeous and fully responsive theme, and it works with WordPress 3.4.2. Take it for a spin!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/news/2012/09/wordpress-3-5-beta-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:48:"WordPress 3.4.2 Maintenance and Security Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2012/09/wordpress-3-4-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/news/2012/09/wordpress-3-4-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 06 Sep 2012 20:07:21 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2426";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:355:"WordPress 3.4.2, now available for download, is a maintenance and security release for all previous versions. After nearly 15 million downloads since 3.4 was released not three months ago, we&#8217;ve identified and fixed a number of nagging bugs, including: Fix some issues with older browsers in the administration area. Fix an issue where a theme [...]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1443:"<p>WordPress 3.4.2, now available for download, is a maintenance and security release for all previous versions.</p>
<p>After nearly 15 million downloads since 3.4 was released not three months ago, we&#8217;ve <a href="http://core.trac.wordpress.org/query?status=closed&amp;resolution=fixed&amp;milestone=3.4.2&amp;group=resolution&amp;order=severity&amp;desc=1">identified and fixed a number of nagging bugs</a>, including:</p>
<ul>
<li>Fix some issues with older browsers in the administration area.</li>
<li>Fix an issue where a theme may not preview correctly, or its screenshot may not be displayed.</li>
<li>Improve plugin compatibility with the visual editor.</li>
<li>Address pagination problems with some category permalink structures.</li>
<li>Avoid errors with both oEmbed providers and trackbacks.</li>
<li>Prevent improperly sized header images from being uploaded.</li>
</ul>
<p>Version 3.4.2 also fixes a few security issues and contains some security hardening. The vulnerabilities included potential privilege escalation and a bug that affects multisite installs with untrusted users. These issues were discovered and fixed by the WordPress security team.</p>
<p><a href="http://wordpress.org/download/"><strong>Download 3.4.2</strong></a><strong> now or visit Dashboard → Updates in your site admin to update now.</strong></p>
<p><em>Fixes for some bugs<br />
Back to work on 3.5<br />
It&#8217;s time to update</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2012/09/wordpress-3-4-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:31:"http://wordpress.org/news/feed/";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:44:"http://purl.org/rss/1.0/modules/syndication/";a:2:{s:12:"updatePeriod";a:1:{i:0;a:5:{s:4:"data";s:6:"hourly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:15:"updateFrequency";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:8:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Thu, 21 Mar 2013 15:06:48 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:4:"vary";s:15:"Accept-Encoding";s:10:"x-pingback";s:36:"http://wordpress.org/news/xmlrpc.php";s:13:"last-modified";s:29:"Thu, 07 Mar 2013 14:21:02 GMT";s:4:"x-nc";s:11:"HIT luv 138";s:10:"connection";s:5:"close";}s:5:"build";s:14:"20121202224312";}', 'no') ; 
INSERT INTO `wp_options` VALUES (309, '_transient_feed_aa75f026b58586b24d81a087c77a9ecf', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:4:"
  
";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:83:"
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
  ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:4:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:40:"link:http://basewp/ - Google Blog Search";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:89:"http://www.google.com/search?ie=utf-8&q=link:http://basewp/&tbm=blg&tbs=sbd:1&safe=strict";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:17:"About 730 results";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:58:"La Città della Ciroma intervista i Vinsent - Radio Ciroma";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:41:"http://www.ciroma.org/site/archives/11936";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:262:"In nome di un disco registrato più di due anni fa e arrivato solo ora alla pubblicazione. Parlando di cortocircuiti sonori, spensieratezza e giorni che, se esistesse una giustizia divina, dovrebbero essere di 48 ore. <em>LINK</em>: FACEBOOK / YOUTUBE <b>...</b>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:3:{s:9:"publisher";a:1:{i:0;a:5:{s:4:"data";s:60:"radio ciroma 105.7FM - cosenza | rumori nell\'etere cittadino";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"marcello";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"date";a:1:{i:0;a:5:{s:4:"data";s:29:"Tue, 12 Mar 2013 21:24:32 GMT";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:65:"#Syria A Report On The Coordination Of Doctors… | YALLA SOURIYA";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:91:"http://yallasouriya.wordpress.com/2013/03/12/syria-a-report-on-the-coordination-of-doctors/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:185:"rien4djri 2:06 am on March 12, 2013 Permalink Log in to leave a Comment. #Syria: A Report On The Coordination Of Doctors In #Homs Coordination of Doctors in Homs shared a <em>link</em>.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:3:{s:9:"publisher";a:1:{i:0;a:5:{s:4:"data";s:13:"YALLA SOURIYA";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"rien4djri";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"date";a:1:{i:0;a:5:{s:4:"data";s:29:"Tue, 12 Mar 2013 02:06:26 GMT";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:53:"15 – 19 marzo: “Fera ara mmersa” - Radio Ciroma";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:41:"http://www.ciroma.org/site/archives/11911";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:292:"<b>...</b> e tutte le associazioni cattoliche e laiche. La partecipazione a questo confronto non rappresenta solo un&#39;opportunità d&#39;incontro per tutti e tutte. Alla luce degli ultimi tragici eventi, diviene un atto di sensibilità umana e senso civico. <em>LINK</em> UTILI: <b>...</b>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:3:{s:9:"publisher";a:1:{i:0;a:5:{s:4:"data";s:60:"radio ciroma 105.7FM - cosenza | rumori nell\'etere cittadino";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:22:"francesco a.k.a. china";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"date";a:1:{i:0;a:5:{s:4:"data";s:29:"Sun, 10 Mar 2013 15:56:17 GMT";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:101:"radio ciroma 105.7FM – cosenza | rumori nell&amp;#39;etere cittadino » Blog &lt;b&gt;...&lt;/b&gt;";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:41:"http://www.ciroma.org/site/archives/11903";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:545:"<b>...</b> basi sulla creatività e sull&#39;unione tra i singoli. Membri Resident: Leinad – Free SB – Tommy Outside. Membri TheFRAG Lab: Divna Ivic – Luca Ferigo – Marco Ferigo. TRACKLIST: (secret). Lo ascolti qui sotto e lo scarichi, in free download, da qui. <em>LINK</em>: FACEBOOK / SITO UFFICIALE TheFRAG <b>...</b> radiociroma on twitter. Radio Ciroma 105.7FM. Dalle 21,00 105.7 fm oppure <em>http</em>://t.co/Tlt9XxtM93! <b>...</b> Switch to our mobile site. sito realizzato da CIROMA su <em>base WP</em> e ARTHEMIA | Collegati |";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:3:{s:9:"publisher";a:1:{i:0;a:5:{s:4:"data";s:60:"radio ciroma 105.7FM - cosenza | rumori nell\'etere cittadino";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"marcello";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"date";a:1:{i:0;a:5:{s:4:"data";s:29:"Sun, 10 Mar 2013 12:38:49 GMT";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:55:"Italian Indiescovery #6 – Femme Fatale - Radio Ciroma";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:41:"http://www.ciroma.org/site/archives/11879";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:278:"<b>...</b> EP “Domestic Peace” (si scarica da qui), della scelta del free download pay-with-a-post, della loro esperienza live oltremanica nel Cavern Pub, e del rapporto con il tedio che li accompagna sporadicamente per le strade d&#39;Alessandria. <em>LINK</em>: <b>...</b>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:3:{s:9:"publisher";a:1:{i:0;a:5:{s:4:"data";s:60:"radio ciroma 105.7FM - cosenza | rumori nell\'etere cittadino";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"mat.argieri";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"date";a:1:{i:0;a:5:{s:4:"data";s:29:"Fri, 08 Mar 2013 15:47:21 GMT";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:73:"Why Galactic Cosmic Radiation Not Hit Astronauts? | Ramani&amp;#39;s blog";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:91:"http://ramanan50.wordpress.com/2013/03/07/why-galactic-cosmic-radiation-not-hit-astronauts/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:288:"I have provided a <em>link</em> at the end of this post. Very interesting, yet it left me totally confused as to what the <b>...</b> people with cataracts lose some of their ability to see. In 2001,. <em>http</em>://boingboing.net/2013/01/04/how-space-radiation-hurts-astr.html <b>...</b>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:3:{s:9:"publisher";a:1:{i:0;a:5:{s:4:"data";s:13:"Ramani\'s blog";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"ramanan50";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"date";a:1:{i:0;a:5:{s:4:"data";s:29:"Thu, 07 Mar 2013 11:40:33 GMT";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:91:"ARRENDETEVI siete circondati? [zeitgeist - dolore di dita fratturate &lt;b&gt;...&lt;/b&gt;";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:137:"http://6viola.wordpress.com/2013/03/07/arrendetevi-siete-circondati-zeitgeist-dolore-di-dita-fratturate-un-frullatore-di-vero-e-di-falso/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:261:"<em>http</em>://www.godlikeproductions.com/forum1/message1951072/pg1. RFID Chip Implant For All Americans? – Rumors and Facts. [<em>link</em> to www.prophecynewswatch.com]This new law requires an RFID chip implanted in all of us. This chip will not <b>...</b>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:3:{s:9:"publisher";a:1:{i:0;a:5:{s:4:"data";s:7:"6 VIOLA";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Lino";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"date";a:1:{i:0;a:5:{s:4:"data";s:29:"Wed, 06 Mar 2013 23:18:59 GMT";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:101:"radio ciroma 105.7FM – cosenza | rumori nell&amp;#39;etere cittadino » Blog &lt;b&gt;...&lt;/b&gt;";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:41:"http://www.ciroma.org/site/archives/11853";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:291:"Per maggiori informazioni e scaricare il bando, visita il sito <em>http</em>://www.premiosabrinasganga.it/. | more. 1 Star 2 Stars 3 Stars 4 <b>...</b> <em>http</em>://www.ciroma.org/site/archives/11853 [...] <b>....</b> sito realizzato da CIROMA su <em>base WP</em> e ARTHEMIA | Collegati |";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:3:{s:9:"publisher";a:1:{i:0;a:5:{s:4:"data";s:60:"radio ciroma 105.7FM - cosenza | rumori nell\'etere cittadino";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:7:"milingo";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"date";a:1:{i:0;a:5:{s:4:"data";s:29:"Tue, 05 Mar 2013 07:20:03 GMT";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:61:"Italian Indiescovery #5 – Kafka On The Shore - Radio Ciroma";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:41:"http://www.ciroma.org/site/archives/11800";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:543:"<b>...</b> letterarie che echeggiano nella loro musica, degli scenari visivi, dell&#39;approccio compositivo al loro album d&#39;esordio, “Beautiful but empty”, ma anche di David Lynch che, inquietantemente, torna sempre nelle nostre disquisizioni. ascolta: <em>LINK</em>: SITO UFFICIALE / FACEBOOK <b>...</b> Un articolo da leggere per saggiare al meglio il... <em>http</em>://t.co/u9YPmq33yY 12:47:16 PM marzo 19, 2013 da Facebook RispondiRetweetPreferiti <b>...</b> sito realizzato da CIROMA su <em>base WP</em> e ARTHEMIA | Collegati |";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:3:{s:9:"publisher";a:1:{i:0;a:5:{s:4:"data";s:60:"radio ciroma 105.7FM - cosenza | rumori nell\'etere cittadino";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"mat.argieri";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"date";a:1:{i:0;a:5:{s:4:"data";s:29:"Thu, 28 Feb 2013 15:43:45 GMT";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:74:"Moder, i sottovalutati e un&amp;#39;installazione anonima a - Radio Ciroma";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:41:"http://www.ciroma.org/site/archives/11794";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:258:"Scritto da Moder con Thomas Pilani (regia e montaggio) e Andrea Fiumana (riprese e fotografia). <em>LINK</em> UTILI: www.facebook.com/MODER.LODC &middot; www.latooscurofoundation.com. | more. 1 Star 2 Stars 3 Stars 4 Stars 5 Stars (No Ratings Yet) <b>...</b>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:3:{s:9:"publisher";a:1:{i:0;a:5:{s:4:"data";s:60:"radio ciroma 105.7FM - cosenza | rumori nell\'etere cittadino";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:22:"francesco a.k.a. china";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"date";a:1:{i:0;a:5:{s:4:"data";s:29:"Wed, 27 Feb 2013 21:37:14 GMT";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:36:"http://a9.com/-/spec/opensearch/1.1/";a:3:{s:12:"totalResults";a:1:{i:0;a:5:{s:4:"data";s:3:"730";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:10:"startIndex";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:12:"itemsPerPage";a:1:{i:0;a:5:{s:4:"data";s:2:"10";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:10:{s:12:"content-type";s:28:"text/xml; charset=ISO-8859-1";s:4:"date";s:29:"Thu, 21 Mar 2013 15:06:48 GMT";s:7:"expires";s:2:"-1";s:13:"cache-control";s:18:"private, max-age=0";s:10:"set-cookie";a:2:{i:0;s:143:"PREF=ID=1bcb4c1f948046c2:FF=0:TM=1363878407:LM=1363878408:S=iMJoqSAHdERQ3lIf; expires=Sat, 21-Mar-2015 15:06:48 GMT; path=/; domain=.google.com";i:1;s:212:"NID=67=W7LNWKuZUOOnoz8B9HOInRyJDXQeo23traTwMPB9GNboxz3Lw-UTmSzEniuwDEh-86oWwPvYQvwpljItHNKHel1TxMfAFovJjO07Pj16uJrKFcQcRBHNKEPvTtrveaut; expires=Fri, 20-Sep-2013 15:06:48 GMT; path=/; domain=.google.com; HttpOnly";}s:3:"p3p";s:122:"CP="This is not a P3P policy! See http://www.google.com/support/accounts/bin/answer.py?hl=en&answer=151657 for more info."";s:6:"server";s:3:"gws";s:16:"x-xss-protection";s:13:"1; mode=block";s:15:"x-frame-options";s:10:"SAMEORIGIN";s:10:"connection";s:5:"close";}s:5:"build";s:14:"20121202224312";}', 'no') ; 
INSERT INTO `wp_options` VALUES (310, '_transient_timeout_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1363921608', 'no') ; 
INSERT INTO `wp_options` VALUES (311, '_transient_timeout_feed_mod_aa75f026b58586b24d81a087c77a9ecf', '1363921608', 'no') ; 
INSERT INTO `wp_options` VALUES (312, '_transient_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1363878408', 'no') ; 
INSERT INTO `wp_options` VALUES (313, '_transient_feed_mod_aa75f026b58586b24d81a087c77a9ecf', '1363878408', 'no') ; 
INSERT INTO `wp_options` VALUES (318, '_transient_timeout_feed_867bd5c64f85878d03a060509cd2f92c', '1363921609', 'no') ; 
INSERT INTO `wp_options` VALUES (319, '_transient_feed_867bd5c64f85878d03a060509cd2f92c', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:61:"
	
	
	
	




















































";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"WordPress Planet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:28:"http://planet.wordpress.org/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:2:"en";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:47:"WordPress Planet - http://planet.wordpress.org/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:50:{i:0;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:59:"Weblog Tools Collection: WordPress Plugin Releases for 3/21";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:41:"http://weblogtoolscollection.com/?p=12802";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:73:"http://feedproxy.google.com/~r/weblogtoolscollection/UXMP/~3/0LUWJ6dWyoE/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1145:"<h3>New plugins</h3>
<p><a href="http://wordpress.org/extend/plugins/google-adsense-dashboard-for-wp/"><strong>Google Adsense Dashboard for WP</strong></a> will display your Google Adsense earnings and related reports inside your Dashboard.</p>
<p><a href="http://wordpress.org/extend/plugins/google-analytics-dashboard-for-wp/"><strong>Google Analytics Dashboard for WP</strong></a> will display Google Analytics data and statistics inside your Dashboard.</p>
<h3>Updated plugins</h3>
<p><a href="http://wordpress.org/extend/plugins/ad-code-manager/"><strong>Ad Code Manager</strong></a> allows you to manage your ad codes through the WordPress admin in a safe and easy way.</p>
<p><a href="http://calendarscripts.info/autoresponder-wordpress.html"><strong>BFT Autoresponder</strong></a> allows scheduling of automated autoresponder messages and managing a mailing list.</p>
<p><a href="http://wordpress.org/extend/plugins/camptix/"><strong>CampTix Event Ticketing</strong></a> is an easy to use and flexible event ticketing plugin.</p>
<img src="http://feeds.feedburner.com/~r/weblogtoolscollection/UXMP/~4/0LUWJ6dWyoE" height="1" width="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 21 Mar 2013 14:00:16 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"James";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:103:"WordPress.tv: Walter Dal Mut: WordPress incontra il Cloud Computing: Scalabilità ed Alta Disponiblità";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=17317";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:117:"http://wordpress.tv/2013/03/20/walter-dal-mut-wordpress-incontra-il-cloud-computing-scalabilita-ed-alta-disponiblita/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:710:"<div id="v-8DjnnEnW-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/17317/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/17317/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=17317&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/03/20/walter-dal-mut-wordpress-incontra-il-cloud-computing-scalabilita-ed-alta-disponiblita/"><img alt="02 Gabriele Mittica & Walter Dal Mut.mp4" src="http://videos.videopress.com/8DjnnEnW/video-5d332310a1_scruberthumbnail_2.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 21 Mar 2013 01:20:48 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:67:"Alex King: WordPress Maturity – An Interview with Me at WP Engine";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://alexking.org/?p=16267";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:88:"http://alexking.org/blog/2013/03/20/wordpress-maturity-an-interview-with-me-at-wp-engine";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:402:"<p>An <a href="http://wpengine.com/2013/03/alex-king-on-the-maturity-of-wordpress/">interview with me about WordPress&#8217;s maturity</a> is up on the WP Engine blog. It&#8217;s a bit of a long read (~4500 words), but <a href="http://www.austingunter.com/">Austin</a> did a great job asking good questions and follow-ups. I quite enjoyed the discussion and I hope you&#8217;ll find it interesting.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 20 Mar 2013 21:26:47 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Alex";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:60:"WordPress.tv: Lisa Sabin-Wilson: Oh, The Themes You’ll Do!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=18284";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:72:"http://wordpress.tv/2013/03/18/lisa-sabin-wilson-oh-the-themes-youll-do/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:637:"<div id="v-vFBS0C7I-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/18284/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/18284/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=18284&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/03/18/lisa-sabin-wilson-oh-the-themes-youll-do/"><img alt="Lisa Sabin-Wilson" src="http://videos.videopress.com/vFBS0C7I/lisa-sabin-wilson_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 19 Mar 2013 21:45:08 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:58:"Weblog Tools Collection: WordPress Theme Releases for 3/19";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:41:"http://weblogtoolscollection.com/?p=12792";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:73:"http://feedproxy.google.com/~r/weblogtoolscollection/UXMP/~3/yiyrwU_8gQQ/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1378:"<p><a href="http://wordpress.org/extend/themes/cazuela"><img class="alignnone size-thumbnail wp-image-12793" alt="screenshot" src="http://i2.wp.com/weblogtoolscollection.com/wp-content/uploads/2013/03/screenshot4.png?resize=150%2C150" /></a></p>
<p><a href="http://wordpress.org/extend/themes/cazuela"><strong>Cazuela</strong></a> is a neutral colored theme.</p>
<p><a href="http://wordpress.org/extend/themes/ilisa"><img class="alignnone size-thumbnail wp-image-12795" alt="screenshot-1" src="http://i2.wp.com/weblogtoolscollection.com/wp-content/uploads/2013/03/screenshot-14.png?resize=150%2C150" /></a></p>
<p><a href="http://wordpress.org/extend/themes/ilisa"><strong>Ilisa</strong></a> is a clean and minimal theme that can be easily used as a personal portfolio or a business website.</p>
<p><a href="http://emptynestthemes.com/2013/03/18/partition-professional-wordpress-theme/"><img class="alignnone size-thumbnail wp-image-12794" alt="DemoBlog" src="http://i0.wp.com/weblogtoolscollection.com/wp-content/uploads/2013/03/DemoBlog3.png?resize=150%2C150" /></a></p>
<p><a href="http://emptynestthemes.com/2013/03/18/partition-professional-wordpress-theme/"><strong>Partition</strong></a> has a light, lively, colorful, yet professional and classic appearance.</p>
<img src="http://feeds.feedburner.com/~r/weblogtoolscollection/UXMP/~4/yiyrwU_8gQQ" height="1" width="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 19 Mar 2013 14:00:17 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"James";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:31:"WordPress.tv: Noah Dyer: Growth";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=18187";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"http://wordpress.tv/2013/03/18/noah-dyer-growth/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:612:"<div id="v-xvr1P7XJ-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/18187/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/18187/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=18187&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/03/18/noah-dyer-growth/"><img alt="Noah Dyer: Growth" src="http://videos.videopress.com/xvr1P7XJ/video-c774cda819_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 18 Mar 2013 20:29:35 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:70:"WordPress.tv: How to Install Jetpack Site Stats on your WordPress site";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=17936";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:88:"http://wordpress.tv/2013/03/18/how-to-install-jetpack-site-stats-on-your-wordpress-site/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:664:"<div id="v-0EUXgeTM-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/17936/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/17936/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=17936&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/03/18/how-to-install-jetpack-site-stats-on-your-wordpress-site/"><img alt="WSC-001-jetpack-analitics.mov" src="http://videos.videopress.com/0EUXgeTM/video-c95e94a6ba_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 18 Mar 2013 15:56:20 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:32:"WordPress.tv Blog: Get Involved!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"http://wptvblog.wordpress.com/?p=291";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:54:"http://wptvblog.wordpress.com/2013/03/18/get-involved/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1594:"<p>WordPress.tv is now open for video submissions from the WordPress community.</p>
<p>Do you record your WordPress meetup? <a href="http://wordpress.tv/submit-video/">Submit it to WordPress.tv!</a> Do you record WordPress screencast tutorials? <a href="http://wordpress.tv/submit-video/">Submit them to WordPress.tv!</a> Do you create some other form of WP video awesomesauce that would benefit the community? WordPress.tv might be just the place for it.</p>
<p>Fair warning: Our intrepid group of WordPress.tv event video moderators already works hard to review and publish WordCamp videos, and if WordPress.tv is suddenly flooded with video submissions, they may take a while to get around to reviewing and publishing your video. Please be patient as we iterate toward success&#8230; and if you&#8217;re interested in donating your time toward becoming a WordPress.tv moderator, please apply <a href="http://wordpress.tv/apply-to-be-a-wordpress-tv-moderator/">here</a>. If this takes off like we think it might, we will definitely need some extra eyes!</p>
<p>Thanks in advance for helping to make WordPress.tv an even more fantastic resource. If you have questions about this, please don&#8217;t hesitate to ask.</p>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptvblog.wordpress.com/291/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptvblog.wordpress.com/291/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wptvblog.wordpress.com&blog=5310177&post=291&subd=wptvblog&ref=&feed=1" width="1" height="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 18 Mar 2013 08:57:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Andrea Middleton";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:29:"Alex King: Announcing Threads";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://alexking.org/?p=16176";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:54:"http://alexking.org/blog/2013/03/17/announcing-threads";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2417:".threads-post-notice {
	background: #e8e8e8;
	padding: 10px;
}
.threads-post-notice a {
	font-weight: bold;
}

<p><img src="http://alexking.org/wp-content/uploads/2013/03/threads-timeline-510x382.jpg" alt="threads-timeline" width="480" height="359" class="aligncenter size-medium-img wp-image-16181" /></p>
<p>I&#8217;ve just released an initial beta of <a href="http://wordpress.org/extend/plugins/threads/">Threads</a>, a WordPress plugin I&#8217;ve been working on for about a year. The idea is simple: show posts that comprise a single overall story/topic in a timeline. Then link to that timeline from the posts so that your readers have a chance to get more historical context about a post without you having to link back to 20 previous posts.</p>
<p>Here are some example threads:</p>
<ul>
<li><a href="http://alexking.org/blog/thread/social">Social</a></li>
<li><a href="http://alexking.org/blog/thread/hard-drive-recovery">My Hard Drive Recovery Saga</a></li>
<li><a href="http://alexking.org/blog/thread/twitter-tools">Twitter Tools</a></li>
<li><a href="http://alexking.org/blog/thread/passwords">Passwords</a></li>
<li><a href="http://alexking.org/blog/thread/weight-loss">Weight Loss</a></li>
</ul>
<p>As you can see on this site, the thread timeline is responsive and retina/HiDPI ready. Also included is a sidebar widget to show recently active threads and a shortcode so that you can embed a thread timeline in a page.</p>
<p>Give it a spin &#8211; I hope it works out well for you!</p>
<p>A quick note about support: As this is a free plugin released under the GPL I am offering only &#8220;Product Support&#8221; for this plugin. That means I will do my best to fix bugs and usabiity issues that are posted on the <a href="http://wordpress.org/support/">WordPress support forums</a>. Contrast this with &#8220;User Support&#8221; which we offer for all of <a href="http://crowdfavorite.com">Crowd Favorite</a>&#8216;s commercial products. With &#8220;User Support&#8221; we do our best to troubleshoot and address each customer&#8217;s issues.</p>
<p>Developers, contributions are welcome on <a href="https://github.com/crowdfavorite/wp-threads">GitHub</a>.</p>
<p class="threads-post-notice">This post is part of the thread: <a href="http://alexking.org/blog/thread/content">Content Presentation</a> &#8211; an ongoing story on this site. View the thread timeline for more context on this post.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 17 Mar 2013 21:35:55 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Alex";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:59:"Weblog Tools Collection: WordPress Plugin Releases for 3/17";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:41:"http://weblogtoolscollection.com/?p=12787";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:73:"http://feedproxy.google.com/~r/weblogtoolscollection/UXMP/~3/iCzrsWmhJSE/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1168:"<h3>New plugins</h3>
<p><a href="http://wordpress.org/extend/plugins/barc-chat/"><strong>Barc Chat</strong></a> provides a simple yet feature rich chat room for your whole community to interact in real-time directly on your site.</p>
<p><a href="http://wordpress.org/extend/plugins/get-directions/"><strong>Get Directions</strong></a> is a flexible and responsive map plugin.</p>
<p><a href="http://namaste-lms.org/"><strong>Namaste! LMS</strong></a> is a learning management system for WordPress.</p>
<p><a href="http://tutskid.com/pinterest-verify-meta-tag/"><strong>Pinterest Verify Meta Tag</strong></a> simply inserts the Pinterest meta tag verification code to the correct section of your site.</p>
<h3>Updated plugins</h3>
<p><a href="http://wordpress.org/extend/plugins/backwpup/"><strong>BackWPup</strong></a> allows you to backup your WordPress database, files, and more.</p>
<p><a href="http://wordpress.org/extend/plugins/ooyala-video-browser/"><strong>Ooyala Video</strong></a> allows you to easily embed videos from the Ooyala Video Platform.</p>
<img src="http://feeds.feedburner.com/~r/weblogtoolscollection/UXMP/~4/iCzrsWmhJSE" height="1" width="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 17 Mar 2013 14:00:24 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"James";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:69:"WordPress.tv: Make Quick Posts to Your WordPress Blog with Press This";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=17934";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:87:"http://wordpress.tv/2013/03/17/make-quick-posts-to-your-wordpress-blog-with-press-this/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:653:"<div id="v-zbaXcN4P-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/17934/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/17934/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=17934&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/03/17/make-quick-posts-to-your-wordpress-blog-with-press-this/"><img alt="PressThis.mov" src="http://videos.videopress.com/zbaXcN4P/video-b1ff756587_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 17 Mar 2013 07:00:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:57:"WordPress.tv: Chris Lema: Success in Distributed Contexts";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=18183";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:74:"http://wordpress.tv/2013/03/17/chris-lema-success-in-distributed-contexts/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:670:"<div id="v-1oRdV9R4-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/18183/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/18183/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=18183&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/03/17/chris-lema-success-in-distributed-contexts/"><img alt="Chris Lema: Success in Distributed Contexts" src="http://videos.videopress.com/1oRdV9R4/video-fd51521a82_scruberthumbnail_1.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 17 Mar 2013 07:00:12 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:59:"WordPress.tv: Melinda Samson: Google Analytics 101 Workshop";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=17624";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:76:"http://wordpress.tv/2013/03/16/melinda-samson-workshop-google-analytics-101/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:666:"<div id="v-Wa1tv4CB-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/17624/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/17624/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=17624&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/03/16/melinda-samson-workshop-google-analytics-101/"><img alt="Workshop: Google Analytics 101" src="http://videos.videopress.com/Wa1tv4CB/workshop_google_analytics_101_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 16 Mar 2013 07:00:28 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:68:"WordPress.tv: Greg Taylor: Fundamentals of a Kick Ass WordPress Site";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=18191";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:85:"http://wordpress.tv/2013/03/16/greg-taylor-fundamentals-of-a-kick-ass-wordpress-site/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:686:"<div id="v-cSUD5DNg-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/18191/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/18191/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=18191&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/03/16/greg-taylor-fundamentals-of-a-kick-ass-wordpress-site/"><img alt="Greg Taylor: Fundamentals of a Kick Ass WordPress Site" src="http://videos.videopress.com/cSUD5DNg/video-6e7f46dc65_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 16 Mar 2013 07:00:10 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:58:"Weblog Tools Collection: WordPress Theme Releases for 3/15";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:41:"http://weblogtoolscollection.com/?p=12779";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:73:"http://feedproxy.google.com/~r/weblogtoolscollection/UXMP/~3/lRqztGNTtv8/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1767:"<p><a href="http://wordpress.org/extend/themes/ease"><img class="alignnone size-thumbnail wp-image-12780" alt="screenshot" src="http://i0.wp.com/weblogtoolscollection.com/wp-content/uploads/2013/03/screenshot3.png?resize=150%2C150" /></a></p>
<p><a href="http://wordpress.org/extend/themes/ease"><strong>Ease</strong></a> is a simple red and white theme.</p>
<p><a href="http://emptynestthemes.com/2013/03/14/nomad-wordpress-blog-theme/"><img class="alignnone size-thumbnail wp-image-12783" alt="DemoBlog" src="http://i2.wp.com/weblogtoolscollection.com/wp-content/uploads/2013/03/DemoBlog2.png?resize=150%2C150" /></a></p>
<p><a href="http://emptynestthemes.com/2013/03/14/nomad-wordpress-blog-theme/"><strong>Nomad</strong></a> is an attractive professional, business or blog theme with an unusual, very narrow orientation and design.</p>
<p><a href="http://wordpress.org/extend/themes/sensitive"><img class="alignnone size-thumbnail wp-image-12782" alt="screenshot-2" src="http://i2.wp.com/weblogtoolscollection.com/wp-content/uploads/2013/03/screenshot-22.png?resize=150%2C150" /></a></p>
<p><a href="http://wordpress.org/extend/themes/sensitive"><strong>Sensitive</strong></a> is fully responsive theme using Twitter Bootstrap and a Metro-styled accent.</p>
<p><a href="http://wordpress.org/extend/themes/visual"><img class="alignnone size-thumbnail wp-image-12781" alt="screenshot-1" src="http://i0.wp.com/weblogtoolscollection.com/wp-content/uploads/2013/03/screenshot-13.png?resize=150%2C150" /></a></p>
<p><a href="http://wordpress.org/extend/themes/visual"><strong>Visual</strong></a> is a dark minimalist theme for displaying photos and images.</p>
<img src="http://feeds.feedburner.com/~r/weblogtoolscollection/UXMP/~4/lRqztGNTtv8" height="1" width="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 15 Mar 2013 19:00:08 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"James";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:15;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:57:"WordPress.tv: Andrew Nacin: WP_Query / WordPress In-depth";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=17990";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:72:"http://wordpress.tv/2013/03/15/andrew-nacin-wp_query-wordpress-in-depth/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:671:"<div id="v-fN7XVxWJ-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/17990/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/17990/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=17990&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/03/15/andrew-nacin-wp_query-wordpress-in-depth/"><img alt="Andrew Nacin: WP_Query / WordPress in Depth" src="http://videos.videopress.com/fN7XVxWJ/andrewnacin-wpquery_scruberthumbnail_1.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 15 Mar 2013 07:00:57 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:16;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:45:"WordPress.tv: Andrew Nacin: WordPress in 2012";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=18004";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:62:"http://wordpress.tv/2013/03/15/andrew-nacin-wordpress-in-2012/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:647:"<div id="v-w1h37UGG-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/18004/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/18004/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=18004&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/03/15/andrew-nacin-wordpress-in-2012/"><img alt="AndrewNacin-WordPressin2012" src="http://videos.videopress.com/w1h37UGG/andrewnacin-wordpressin2012_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 15 Mar 2013 07:00:47 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:17;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:54:"Weblog Tools Collection: WordPress 3.6 Release Delayed";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:41:"http://weblogtoolscollection.com/?p=12772";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:73:"http://feedproxy.google.com/~r/weblogtoolscollection/UXMP/~3/N8oZD4gd_rM/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:820:"<p>The impending release of <a href="http://wordpress.org">WordPress</a> 3.6 has been pushed back one more week to April 29.</p>
<p>At this time, WordPress 3.6 is not yet feature complete (meaning that all intended new features have not been entirely finished), so <a href="http://make.wordpress.org/core/2013/03/13/the-road-to-3-6-beta-1/">the decision was made</a> to push the first beta release back two weeks to March 27 and the final release back one week to April 29. This will allow the team time to focus on finalizing the in-progress new features so that they (and the brave folks who enjoy running beta software) can simply focus on testing and bug fixing rather than polishing up partial features.</p>
<img src="http://feeds.feedburner.com/~r/weblogtoolscollection/UXMP/~4/N8oZD4gd_rM" height="1" width="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 14 Mar 2013 14:00:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"James";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:18;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:45:"WordPress.tv: Karim Osman: over WordPress.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=17975";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:62:"http://wordpress.tv/2013/03/14/karim-osman-over-wordpress-com/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:649:"<div id="v-3Y8BPEXu-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/17975/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/17975/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=17975&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/03/14/karim-osman-over-wordpress-com/"><img alt="Karim Osman: over WordPress-com" src="http://videos.videopress.com/3Y8BPEXu/karim-wordpress-com_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 14 Mar 2013 13:25:26 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:19;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:44:"WordPress.tv: Paul Gibbs: BuddyPress in 2012";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=17997";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:61:"http://wordpress.tv/2013/03/14/paul-gibbs-buddypress-in-2012/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:653:"<div id="v-6oGBfrOG-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/17997/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/17997/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=17997&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/03/14/paul-gibbs-buddypress-in-2012/"><img alt="Paul Gibbs: BuddyPress In 2012" src="http://videos.videopress.com/6oGBfrOG/paulgibs-buddypressin2012_scruberthumbnail_1.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 14 Mar 2013 13:25:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:20;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:57:"WordPress.tv: Elles de Boorder: Case: Mobiel solliciteren";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=17980";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:73:"http://wordpress.tv/2013/03/14/elles-de-boorder-case-mobiel-solliciteren/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:632:"<div id="v-38Fa0w7P-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/17980/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/17980/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=17980&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/03/14/elles-de-boorder-case-mobiel-solliciteren/"><img alt="EllesdeBoorder" src="http://videos.videopress.com/38Fa0w7P/ellesdeboorder_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 14 Mar 2013 13:25:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:21;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:63:"WordPress.tv: Björn Wijers: WordPress als CMS voor je intranet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=18006";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:79:"http://wordpress.tv/2013/03/14/bjorn-wijers-wordpress-als-cms-voor-je-intranet/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:631:"<div id="v-5VOLRNIc-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/18006/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/18006/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=18006&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/03/14/bjorn-wijers-wordpress-als-cms-voor-je-intranet/"><img alt="Björn Wijers" src="http://videos.videopress.com/5VOLRNIc/bjorn-ff_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 14 Mar 2013 13:25:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:22;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:58:"WordPress.tv: Bas van der Lans: WordPress voor ondernemers";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=18002";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:75:"http://wordpress.tv/2013/03/14/bas-van-der-lans-wordpress-voor-ondernemers/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:686:"<div id="v-lwAbDvM7-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/18002/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/18002/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=18002&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/03/14/bas-van-der-lans-wordpress-voor-ondernemers/"><img alt="BasvanderLans-WordPress-voor-ondernemers" src="http://videos.videopress.com/lwAbDvM7/basvanderlans-wordpress-voor-ondernemers_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 14 Mar 2013 13:25:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:23;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:51:"WordPress.tv: Remkus de Vries: 10 WordPress weetjes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=18010";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:68:"http://wordpress.tv/2013/03/14/remkus-de-vries-10-wordpress-weetjes/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:663:"<div id="v-ZPtpJB08-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/18010/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/18010/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=18010&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/03/14/remkus-de-vries-10-wordpress-weetjes/"><img alt="RemkusdeVries-10WordPressweetjes" src="http://videos.videopress.com/ZPtpJB08/remkusdevries-10wordpressweetjes_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 14 Mar 2013 13:25:02 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:24;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:45:"WordPress.tv: Coen Jacobs: Core Contributions";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=17992";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:62:"http://wordpress.tv/2013/03/14/coen-jacobs-core-contributions/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:649:"<div id="v-rT4xpicr-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/17992/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/17992/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=17992&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/03/14/coen-jacobs-core-contributions/"><img alt="CoenJacobs-CoreContributions" src="http://videos.videopress.com/rT4xpicr/coenjacobs-corecontributions_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 14 Mar 2013 13:24:59 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:25;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:62:"WordPress.tv: Noel Tock: Customizing WP-Admin for your Clients";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=17995";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:79:"http://wordpress.tv/2013/03/14/noel-tock-customizing-wp-admin-for-your-clients/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:628:"<div id="v-SG6bzhAh-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/17995/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/17995/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=17995&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/03/14/noel-tock-customizing-wp-admin-for-your-clients/"><img alt="Noel.mp4.ff" src="http://videos.videopress.com/SG6bzhAh/noel-ff_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 14 Mar 2013 07:00:53 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:26;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:101:"WordPress.tv: Maurizio Pelizzone: Strumenti e metodi per lavorare con WordPress in progetti complessi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=17321";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:118:"http://wordpress.tv/2013/03/14/maurizio-pelizzone-strumenti-e-metodi-per-lavorare-con-wordpress-in-progetti-complessi/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:690:"<div id="v-AOGI9WO3-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/17321/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/17321/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=17321&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/03/14/maurizio-pelizzone-strumenti-e-metodi-per-lavorare-con-wordpress-in-progetti-complessi/"><img alt="04 Maurizio Pelizzone.mp4" src="http://videos.videopress.com/AOGI9WO3/video-c5e85ec88e_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 14 Mar 2013 07:00:02 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:27;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:59:"Weblog Tools Collection: WordPress Plugin Releases for 3/13";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:41:"http://weblogtoolscollection.com/?p=12768";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:73:"http://feedproxy.google.com/~r/weblogtoolscollection/UXMP/~3/nc1L0kLDbSc/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1374:"<h3>New plugins</h3>
<p><a href="http://wordpress.org/extend/plugins/easy-media-gallery/"><strong>Easy Media Gallery</strong></a> is designed to display portfolios and various media types including gallery sets, single images, google maps, video, audio, and links with ease and elegance.</p>
<p><a href="http://wordpress.org/extend/plugins/ytlink/"><strong>ytlink</strong></a> provides a preview image for embedded YouTube videos.</p>
<h3>Updated plugins</h3>
<p><a href="http://wordpress.org/extend/plugins/backwpup/"><strong>BackWPup</strong></a> allows you to backup your WordPress database, files, and more.</p>
<p><a href="http://wordpress.org/extend/plugins/genericond/"><strong>Genericon&#8217;d</strong></a> enables easy use of the <a href="http://genericons.com">Genericons</a> icon font set from within WordPress. Icons can be inserted using either HTML or a shortcode.</p>
<p><a href="http://wordpress.org/extend/plugins/keyring/"><strong>Keyring</strong></a> provides a very hookable, completely customizable framework for connecting your WordPress site to an external service.</p>
<p><a href="http://wordpress.org/extend/plugins/wp-all-import/"><strong>WP All Import</strong></a> makes it easy to import any XML or CSV file into your WordPress site.</p>
<img src="http://feeds.feedburner.com/~r/weblogtoolscollection/UXMP/~4/nc1L0kLDbSc" height="1" width="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 14 Mar 2013 05:45:07 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"James";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:28;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:26:"Matt: The Redhat of Drupal";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=42287";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:42:"http://ma.tt/2013/03/the-redhat-of-drupal/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1225:"<p>I got this email today:</p>
<div class="blockquote">
<blockquote>Hi Matt,</p>
<p>I apologize for the cold email. I was researching Automattic , Inc. and wanted to ask you if there was any gaps/pains within your CMS and website.  I work for the &#8220;Redhat of Drupal&#8221;, (Acquia) and we have seen an explosion of Drupal use in the Media, News, and Entertainment Industry.</p>
<p>Some companies using Drupal/Acquia include Warner Music, Maxim, NBC Universal, and NPR.<br />
If you are evaluating your current system or are looking into new web projects, I would love to connect and discuss Drupal as an option. </p>
<p>Would it make sense to connect on this? If there is someone better at Automattic , Inc. to speak with, perhaps you could point me in the right direction?</p>
<p>Cheers,</p>
<p>&#8211;<br />
Dillon J. ********<br />
Enterprise Drupal Solutions<br />
Direct: (781) 238-****</p>
<p>http://www.acquia.com</p>
<p>Acquia, 25 Corporate Drive Fourth Floor<br />
Burlington, MA 01803</p>
<p>Acquia ranked #1 Software Vendor on the 2012 Inc 500</p></blockquote>
</div>
<p>Hmmm, maybe I&#8217;ve been <a href="http://wordpress.org/">doing it wrong</a> all these years&#8230; Dillon, I&#8217;ll be in touch!</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 13 Mar 2013 16:17:54 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Matt";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:29;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Matt: SxSW, Work, and Blogging";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=42282";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:44:"http://ma.tt/2013/03/sxsw-work-and-blogging/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2241:"<p><img class="alignright size-thumbnail wp-image-42284" alt="369ajvpd7nrkwmlf1amk" src="http://i2.wp.com/s.ma.tt/files/2013/03/369ajvpd7nrkwmlf1amk.png?resize=195%2C135" /> I&#8217;ve been at the SxSW festival since Friday, it&#8217;s actually my tenth year attending. Since the first time I used my parent&#8217;s gas card and drove up from Houston this event has had a special place in my heart, even as I&#8217;ve gone in and out of love with it as it&#8217;s grown over the years. (I heard that there were more interactive badges this year than film or music.)</p>
<p>I&#8217;ve spoken here and there the last few days and it has generated some good blog posts, so here&#8217;s a sampling of them you may find interesting:</p>
<p>On the way to our interview session <a href="http://allthingsd.com/20130310/wordpress-matt-mullenweg-talks-about-future-of-blogging-in-a-sxsw-pedicab/">Kara Swisher recorded an interview on a pedi-cab</a>.</p>
<p>Techcrunch TV did a nice short interview, <a href="http://techcrunch.com/2013/03/10/wordpress-matt-mullenweg-on-working-from-home-making-money-without-ads-and-more-tctv/">WordPress’ Matt Mullenweg On Working From Home, Making Money Without Ads, And More [TCTV]</a>.</p>
<div></div>
<p><br /></p>
<p>Paidcontent wrote on <a href="http://paidcontent.org/2013/03/09/where-wordpress-is-headed-longform-content-curation-and-maybe-some-native-advertising/">Where WordPress[.com] is headed: Longform content, curation and maybe even native ads</a>.</p>
<p>Marketing Land wrote two great posts, <a href="http://marketingland.com/wordpress-mullenweg-at-sxsw-blogging-still-booming-35808">WordPress Founder Matt Mullenweg At SXSW: Blogging Still Booming</a> and <a href="http://marketingland.com/why-not-work-from-home-we-have-the-technology-says-wordpress-mullenweg-35814">Why Not Work From Home? “We Have The Technology,” Says WordPress’ Mullenweg</a>.</p>
<p>Finally Access PR asked <a href="http://blog.accesspr.com/2013/03/wordpress-airbnb-sxsw/">SXSW: What do WordPress and Airbnb have in common?</a></p>
<p>The coolest part about this and every year is meeting WordPress users all over &#8212; at restaurants, in the streets, at the booth&#8230; please don&#8217;t hesitate to say hi.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 13 Mar 2013 15:16:09 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Matt";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:30;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:84:"WordPress.tv: Kate Kendall: A Case Study – Using WordPress for Magazine Publishing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=17535";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:97:"http://wordpress.tv/2013/03/13/kate-kendall-a-case-study-using-wordpress-for-magazine-publishing/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:733:"<div id="v-PV4q3LTd-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/17535/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/17535/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=17535&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/03/13/kate-kendall-a-case-study-using-wordpress-for-magazine-publishing/"><img alt="A Case Study: Using WordPress for Magazine Publishing" src="http://videos.videopress.com/PV4q3LTd/case_study_using_wordpress_magazine_publishing_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 13 Mar 2013 07:00:26 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:31;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:84:"WordPress.tv: Emily Doig: Create a Social Media Strategy for Your Blog in 30 Minutes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=17539";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:98:"http://wordpress.tv/2013/03/13/emily-doig-create-a-social-media-strategy-for-your-blog-in-30-mins/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:745:"<div id="v-a44SsMX9-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/17539/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/17539/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=17539&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/03/13/emily-doig-create-a-social-media-strategy-for-your-blog-in-30-mins/"><img alt="Emily Doig: Create a Social Media Strategy for Your Blog in 30 Minutes" src="http://videos.videopress.com/a44SsMX9/create_social_media_strategy_your_blog_30_mins_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 13 Mar 2013 07:00:24 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:32;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:57:"WordPress.tv: How to Create an Image Gallery in WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=17932";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:75:"http://wordpress.tv/2013/03/12/how-to-create-an-image-gallery-in-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:671:"<div id="v-GKoEC54c-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/17932/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/17932/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=17932&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/03/12/how-to-create-an-image-gallery-in-wordpress/"><img alt="How to Create an Image Gallery in WordPress" src="http://videos.videopress.com/GKoEC54c/video-0a7ce34deb_scruberthumbnail_2.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 13 Mar 2013 05:43:52 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:33;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:46:"WordPress.tv: Isaac Keyet: WordPress is Mobile";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=17978";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:63:"http://wordpress.tv/2013/03/12/isaac-keyet-wordpress-is-mobile/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:665:"<div id="v-raZQlGdN-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/17978/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/17978/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=17978&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/03/12/isaac-keyet-wordpress-is-mobile/"><img alt="Isaac Keyet &#8211; WordPress is mobile" src="http://videos.videopress.com/raZQlGdN/isaackeyt-wordpresismobile_scruberthumbnail_1.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 12 Mar 2013 20:15:10 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:34;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"BuddyPress: BuddyPress 1.7 Beta 2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"http://buddypress.org/?p=156137";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:52:"http://buddypress.org/2013/03/buddypress-1-7-beta-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:839:"<p>Tuesday&#8217;s getting even more terrific as we announce the second beta of BuddyPress 1.7!</p>
<p>Building on a solid first beta, beta 2 has a number of bug fixes and improvements, mainly around the theme compatibility and admin screens. For those of you interested in a changelog between beta 1 and 2, <a href="https://buddypress.trac.wordpress.org/log?action=stop_on_copy&mode=stop_on_copy&rev=6848&stop_rev=6798+&limit=100">check out this report in Trac</a>.</p>
<p>Now&#8217;s the time to test your themes and plugins, and let us know if you find anything unexpected happening. If you think you&#8217;ve found a bug, please report it on the <a href="http://buddypress.trac.wordpress.org">BuddyPress Core Trac</a>.</p>
<p><a href="http://downloads.wordpress.org/plugin/buddypress.zip">Download BuddyPress 1.7, Beta 2 ↓</a></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 12 Mar 2013 20:14:49 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"Paul Gibbs";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:35;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:48:"Joseph: I am Speaking at the OpenWest Conference";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"https://josephscott.org/?p=7033";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:81:"http://josephscott.org/archives/2013/03/i-am-speaking-at-the-openwest-conference/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1818:"<p><a href="http://www.openwest.org/"><img class="alignleft" alt="" src="http://i2.wp.com/www.openwest.org/wp-content/uploads/2013/01/speaker_300.jpg?resize=300%2C388" /></a></p>
<p>The <a href="http://www.openwest.org/">OpenWest Conference</a> is happening May 2-4, 2013 (formerly the Utah Open Source Conference) at Utah Valley University in Orem, Utah.</p>
<p>This year the <a href="http://www.openwest.org/keynote/">keynote speakers</a> are Rasmus Lerdorf, creator of PHP, and Mark Callaghan, lead of the MySQL engineering team at Facebook.</p>
<p>For my part I&#8217;ll be giving three different presentations this time around.  First up is &#8220;Simple Filesystems with Python and FUSE&#8221;, where I&#8217;ll cover the basics of getting a simple filesystem up and running written in Python using the FUSE library.  Next up is &#8220;Site Testing with CasperJS&#8221;, which is an intro to using <a href="http://casperjs.org/">CasperJS</a> to run user tests against your site.  Last, but not least, is &#8220;Scaling WordPress&#8221;, where I&#8217;ll talk about some of the methods that WordPress.com (the largest WordPress install in the world) uses to host tens of millions of sites that add up to billions of page views per month.</p>
<p>I tried to keep my session titles direct and to the point.  At times there will up to ten sessions running at once ( <a href="http://www.openwest.org/custom/grid.php">OpenWest session schedule</a> ), so I wanted people to be able to tell at a glance what my sessions are about.</p>
<p><a href="http://www.openwest.org/tickets/">Tickets for OpenWest</a> are available at $80.  Every open source group in the area has been given a discount code though, so you can bring that down significantly.</p>
<p>If you&#8217;ll be at the OpenWest conference be sure to say hi.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 12 Mar 2013 16:13:52 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Joseph Scott";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:36;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:47:"Weblog Tools Collection: Do You Work From Home?";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:41:"http://weblogtoolscollection.com/?p=12760";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:73:"http://feedproxy.google.com/~r/weblogtoolscollection/UXMP/~3/x7WcwEeaJQk/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1933:"<p>There has been <a href="http://scottberkun.com/2013/grand-summary-of-posts-on-remote-work-yahoo/">a lot of talk lately</a> about working from home and maintaining a distributed workforce.</p>
<p>Web-based software, like <a href="http://wordpress.org">WordPress</a>, <a href="http://www.joomla.org">Joomla</a>, and <a href="http://drupal.org">Drupal</a>, are taking over the publishing industry and allow you to work from anywhere with an internet connection. Though, even though they can be managed  from home, working from home and maintaining a distributed workforce is not yet broadly acknowledged in society as a successful and efficient alternative to working in an office. Despite working with software that doesn&#8217;t need to be tied to one specific workstation, you could still find yourself tied to a desk in cubicle.</p>
<p>I work full-time for <a href="http://automattic.com">Automattic</a> and have the pleasure of both working from home and setting my own hours. After all, I only need a browser, an email client, and IRC client, and <a href="http://www.skype.com/">Skype</a> to do my job. A desk is nice, but there&#8217;s no one saying that said desk has to be in the dark corner of some corporate office. As for communication between the 150 of us (130 who work from home, far away from the central &#8220;office&#8221; in San Francisco), we communicate mostly via a variety of blogs running the <a href="http://p2theme.com">P2 theme</a>. It&#8217;s as close as you can get to a water cooler or a meeting room with text, you should try it. For other communication needs, we use primarily IRC followed by Skype for less work-related chats.</p>
<p>Do you work from home? And, if you work from home for a larger company (not just yourself), how is communication and overall efficiency maintained?</p>
<img src="http://feeds.feedburner.com/~r/weblogtoolscollection/UXMP/~4/x7WcwEeaJQk" height="1" width="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 12 Mar 2013 14:00:46 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"James";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:37;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:60:"WordPress.tv: Martin Reed: Essential SEO + Link Building 101";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=17545";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:63:"http://wordpress.tv/2013/03/12/essential-seo-link-building-101/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:658:"<div id="v-r7GBMtVP-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/17545/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/17545/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=17545&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/03/12/essential-seo-link-building-101/"><img alt="Essential SEO + Link Building 101" src="http://videos.videopress.com/r7GBMtVP/essential_seo_link_building_101_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 12 Mar 2013 08:15:11 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:38;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:74:"WordPress.tv: Sara Cannon: Designer vs Developer – Creators in WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=17838";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:87:"http://wordpress.tv/2013/03/12/sara-cannon-designer-vs-developer-creators-in-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:668:"<div id="v-5FeqMDZy-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/17838/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/17838/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=17838&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/03/12/sara-cannon-designer-vs-developer-creators-in-wordpress/"><img alt="Sara Cannon: Designer vs Developer" src="http://videos.videopress.com/5FeqMDZy/video-fc01cc3ef1_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 12 Mar 2013 07:00:01 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:39;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:56:"Lorelle on WP: WordPress Anniversary: WordPress and Evil";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"http://lorelle.wordpress.com/?p=8342";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:81:"http://lorelle.wordpress.com/2013/03/11/wordpress-anniversary-wordpress-and-evil/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:483:"As I look back on the ten years of WordPress, there is a dark side to blogging. While many blamed WordPress for the evil, like guns, WordPress doesn&#8217;t cause evil, people cause evil. In fact, WordPress, Automattic, and the WordPress Community has fought longer and harder against the evil doers in the world than most [...]<img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=lorelle.wordpress.com&blog=72&post=8342&subd=lorelle&ref=&feed=1" width="1" height="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 11 Mar 2013 20:29:09 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:17:"Lorelle VanFossen";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:40;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:67:"Dougal Campbell: The WordPress Community Offers Advice to Beginners";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"http://dougal.gunters.org/?p=72499";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:93:"http://dougal.gunters.org/blog/2013/03/11/the-wordpress-community-offers-advice-to-beginners/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:834:"<p><i>The next time somebody asks me for advice on how to get started with WordPress development or community, I just need to point them to this article (which includes a brief quote from yours truly).</i></p>
<p><a href="http://wp.smashingmagazine.com/2013/02/01/wordpress-community-offers-advice-beginners/">The WordPress Community Offers Advice to Beginners</a></p>
<p>Original Article: <a href="http://dougal.gunters.org/blog/2013/03/11/the-wordpress-community-offers-advice-to-beginners/">The WordPress Community Offers Advice to Beginners</a>
<a href="http://dougal.gunters.org">Dougal Campbell&#039;s geek ramblings - WordPress, web development, and world domination.</a></p><div class="yarpp-related-rss yarpp-related-none">
<h3>Related posts:</h3>
<img src="http://yarpp.org/pixels/5db43ee24c4f1e1d0e45d08cc91b0130" />
</div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 11 Mar 2013 17:29:53 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Dougal Campbell";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:41;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:58:"Weblog Tools Collection: WordPress Theme Releases for 3/11";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:41:"http://weblogtoolscollection.com/?p=12751";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:73:"http://feedproxy.google.com/~r/weblogtoolscollection/UXMP/~3/VEQ7XOUJdgU/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1777:"<p><a href="http://wordpress.org/extend/themes/attitude"><img class="alignnone size-thumbnail wp-image-12752" alt="screenshot" src="http://i0.wp.com/weblogtoolscollection.com/wp-content/uploads/2013/03/screenshot2.png?resize=150%2C150" /></a></p>
<p><a href="http://wordpress.org/extend/themes/attitude"><strong>Attitude</strong></a> is a simple, clean, and responsive retina-ready theme.</p>
<p><a href="http://wordpress.org/extend/themes/catch-everest"><img class="alignnone size-thumbnail wp-image-12753" alt="screenshot-1" src="http://i0.wp.com/weblogtoolscollection.com/wp-content/uploads/2013/03/screenshot-12.png?resize=150%2C150" /></a></p>
<p><a href="http://wordpress.org/extend/themes/catch-everest"><strong>Catch Everest</strong></a> is a simple, clean, and responsive theme.</p>
<p><a href="http://emptynestthemes.com/2013/03/05/liberus-wordpress-business-theme/"><img class="alignnone size-thumbnail wp-image-12755" alt="DemoBlog" src="http://i0.wp.com/weblogtoolscollection.com/wp-content/uploads/2013/03/DemoBlog1.png?resize=150%2C150" /></a></p>
<p><a href="http://emptynestthemes.com/2013/03/05/liberus-wordpress-business-theme/"><strong>Liberus</strong></a> is an ideal business related theme that is relatively simple and would suit any blog or website.</p>
<p><a href="http://wordpress.org/extend/themes/stitch"><img class="alignnone size-thumbnail wp-image-12754" alt="screenshot-2" src="http://i2.wp.com/weblogtoolscollection.com/wp-content/uploads/2013/03/screenshot-21.png?resize=150%2C150" /></a></p>
<p><a href="http://wordpress.org/extend/themes/stitch"><strong>Stitch</strong></a> is an elegant, modern theme with optional fixed header.</p>
<img src="http://feeds.feedburner.com/~r/weblogtoolscollection/UXMP/~4/VEQ7XOUJdgU" height="1" width="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 11 Mar 2013 14:00:16 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"James";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:42;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:69:"WordPress.tv: Japh Thomson: Using WordPress as a Development Platform";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=17568";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:86:"http://wordpress.tv/2013/03/11/japh-thomson-using-wordpress-as-a-development-platform/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:708:"<div id="v-6ATOH0KA-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/17568/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/17568/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=17568&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/03/11/japh-thomson-using-wordpress-as-a-development-platform/"><img alt="Japh Thomson: Using WordPress as a Development Platform" src="http://videos.videopress.com/6ATOH0KA/using_wordpress_development_platform_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 11 Mar 2013 07:00:33 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:43;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:102:"WordPress.tv: Dion Hulse: Workshop: How to become a Surgeon: An intro into WordPress core contributing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=17635";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:117:"http://wordpress.tv/2013/03/11/dion-hulse-workshop-how-to-become-a-surgeon-an-intro-into-wordpress-core-contributing/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:759:"<div id="v-rNX1748d-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/17635/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/17635/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=17635&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/03/11/dion-hulse-workshop-how-to-become-a-surgeon-an-intro-into-wordpress-core-contributing/"><img alt="Dion Hulse: An intro to WordPress core contributing" src="http://videos.videopress.com/rNX1748d/workshop_how_become_surgeon_intro_wordpress_core_contributin_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 11 Mar 2013 07:00:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:44;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:54:"WordPress.tv: Jess Jurick: Writing Tools for WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=17801";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:71:"http://wordpress.tv/2013/03/10/jess-jurick-writing-tools-for-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:664:"<div id="v-sug4kAo0-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/17801/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/17801/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=17801&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/03/10/jess-jurick-writing-tools-for-wordpress/"><img alt="Jess Jurick: Writing Tools for WordPress" src="http://videos.videopress.com/sug4kAo0/video-9f145e6c33_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 11 Mar 2013 06:22:22 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:45;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:50:"WordPress.tv: Alexandra Farrar: The Law of Twitter";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=17551";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:67:"http://wordpress.tv/2013/03/10/alexandra-farrar-the-law-of-twitter/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:627:"<div id="v-3HtgOKgv-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/17551/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/17551/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=17551&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/03/10/alexandra-farrar-the-law-of-twitter/"><img alt="The Law of Twitter" src="http://videos.videopress.com/3HtgOKgv/law_twitter_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 10 Mar 2013 07:00:51 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:46;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:58:"Weblog Tools Collection: WordPress Plugin Releases for 3/9";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:41:"http://weblogtoolscollection.com/?p=12746";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:73:"http://feedproxy.google.com/~r/weblogtoolscollection/UXMP/~3/bO5NxobHs5o/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1269:"<h3>New plugins</h3>
<p><a href="http://wordpress.org/extend/plugins/wp-antispambot/"><strong>WP-AntiSpambot</strong></a> adds a shortcode that can be used to stop spambots from harvesting emails entered into your WordPress editor while creating pages or posts.</p>
<p><a href="http://wordpress.org/extend/plugins/zoninator/"><strong>Zone Manager (Zoninator)</strong></a> is designed to help you curate your content by assigning and ordering stories within zones that you can create, edit, and delete.</p>
<h3>Updated plugins</h3>
<p><a href="http://wordpress.org/extend/plugins/contemplate/"><strong>Contemplate</strong></a> allows you to create unlimited shortcodes containing any text/HTML you like.</p>
<p><a href="http://wordpress.org/extend/plugins/genericond/"><strong>Genericon&#8217;d</strong></a> enables easy use of the <a href="http://genericons.com">Genericons</a> icon font set from within WordPress. Icons can be inserted using either HTML or a shortcode.</p>
<p><a href="http://wordpress.org/extend/plugins/safe-report-comments/"><strong>Safe Report Comments</strong></a> gives your visitors the ability to report a comment as inappropriate.</p>
<img src="http://feeds.feedburner.com/~r/weblogtoolscollection/UXMP/~4/bO5NxobHs5o" height="1" width="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 09 Mar 2013 14:00:08 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"James";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:47;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:46:"WordPress.tv: Shelia Oliver: Selecting a Theme";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=17804";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:63:"http://wordpress.tv/2013/03/09/shelia-oliver-selecting-a-theme/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:642:"<div id="v-wWC1dNmC-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/17804/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/17804/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=17804&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/03/09/shelia-oliver-selecting-a-theme/"><img alt="Shelia Oliver: Selecting a Theme" src="http://videos.videopress.com/wWC1dNmC/video-09a458d26f_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 09 Mar 2013 07:00:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:48;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:60:"WordPress.tv: Troy Dean: A Better WordPress for Your Clients";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=17575";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:86:"http://wordpress.tv/2013/03/09/troy-dean-workshop-a-better-wordpress-for-your-clients/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:701:"<div id="v-u0oYwdlO-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/17575/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/17575/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=17575&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/03/09/troy-dean-workshop-a-better-wordpress-for-your-clients/"><img alt="Troy Dean: A Better WordPress for Your Clients" src="http://videos.videopress.com/u0oYwdlO/workshop_better_wordpress_your_clients_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 09 Mar 2013 07:00:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:49;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:91:"WordPress.tv: Paul Clark: How WordPress Saves Lives – Freedom, Hope and Custom Post Types";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=17826";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:103:"http://wordpress.tv/2013/03/08/paul-clark-how-wordpress-saves-lives-freedom-hope-and-custom-post-types/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:737:"<div id="v-BadwqS0c-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/17826/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/17826/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=17826&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/03/08/paul-clark-how-wordpress-saves-lives-freedom-hope-and-custom-post-types/"><img alt="Paul Clark: How WordPress Saves Lives &#8211; Freedom, Hope and Custom Post Types" src="http://videos.videopress.com/BadwqS0c/video-a47f3d8431_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 08 Mar 2013 07:00:24 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:9:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Thu, 21 Mar 2013 15:06:48 GMT";s:12:"content-type";s:8:"text/xml";s:14:"content-length";s:5:"77043";s:4:"vary";s:15:"Accept-Encoding";s:13:"last-modified";s:29:"Thu, 21 Mar 2013 15:00:18 GMT";s:4:"x-nc";s:11:"HIT luv 139";s:13:"accept-ranges";s:5:"bytes";s:10:"connection";s:5:"close";}s:5:"build";s:14:"20121202224312";}', 'no') ; 
INSERT INTO `wp_options` VALUES (320, '_transient_timeout_feed_mod_867bd5c64f85878d03a060509cd2f92c', '1363921609', 'no') ; 
INSERT INTO `wp_options` VALUES (321, '_transient_timeout_feed_a5420c83891a9c88ad2a4f04584a5efc', '1363921609', 'no') ; 
INSERT INTO `wp_options` VALUES (322, '_transient_feed_mod_867bd5c64f85878d03a060509cd2f92c', '1363878409', 'no') ; 
INSERT INTO `wp_options` VALUES (323, '_transient_feed_a5420c83891a9c88ad2a4f04584a5efc', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"
	
";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:72:"
		
		
		
		
		
		
				

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:39:"WordPress Plugins » View: Most Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"http://wordpress.org/extend/plugins/browse/popular/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:39:"WordPress Plugins » View: Most Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 21 Mar 2013 14:37:09 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:25:"http://bbpress.org/?v=1.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:15:{i:0;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"WordPress SEO by Yoast";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/extend/plugins/wordpress-seo/#post-8321";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 Jan 2009 20:34:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:41:"8321@http://wordpress.org/extend/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:131:"Improve your WordPress SEO: Write better content and have a fully optimized WordPress site using the WordPress SEO plugin by Yoast.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Joost de Valk";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Google Analytics for WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:77:"http://wordpress.org/extend/plugins/google-analytics-for-wordpress/#post-2316";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 14 Sep 2007 12:15:27 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:41:"2316@http://wordpress.org/extend/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:145:"Track your WordPress site easily and with lots of metadata: views per author &#38; category, automatic tracking of outbound clicks and pageviews.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Joost de Valk";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:7:"Akismet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:52:"http://wordpress.org/extend/plugins/akismet/#post-15";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:11:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:39:"15@http://wordpress.org/extend/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:98:"Akismet checks your comments against the Akismet web service to see if they look like spam or not.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"Contact Form 7";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:61:"http://wordpress.org/extend/plugins/contact-form-7/#post-2141";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 02 Aug 2007 12:45:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:41:"2141@http://wordpress.org/extend/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:54:"Just another contact form plugin. Simple but flexible.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Takayuki Miyoshi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"Jetpack by WordPress.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/extend/plugins/jetpack/#post-23862";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 Jan 2011 02:21:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:42:"23862@http://wordpress.org/extend/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:104:"Supercharge your WordPress site with powerful features previously only available to WordPress.com users.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:24:"Michael Adams (mdawaffe)";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"Google XML Sitemaps";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:70:"http://wordpress.org/extend/plugins/google-sitemap-generator/#post-132";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:31:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:40:"132@http://wordpress.org/extend/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:105:"This plugin will generate a special XML sitemap which will help search engines to better index your blog.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Arne";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"WordPress Importer";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:66:"http://wordpress.org/extend/plugins/wordpress-importer/#post-18101";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 May 2010 17:42:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:42:"18101@http://wordpress.org/extend/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:101:"Import posts, pages, comments, custom fields, categories, tags and more from a WordPress export file.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Brian Colinger";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"All in One SEO Pack";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:65:"http://wordpress.org/extend/plugins/all-in-one-seo-pack/#post-753";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 30 Mar 2007 20:08:18 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:40:"753@http://wordpress.org/extend/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:86:"WordPress SEO plugin to automatically optimize your Wordpress blog for Search Engines.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"uberdose";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:15:"NextGEN Gallery";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:62:"http://wordpress.org/extend/plugins/nextgen-gallery/#post-1169";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 23 Apr 2007 20:08:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:41:"1169@http://wordpress.org/extend/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:120:"The most popular WordPress gallery plugin and one of the most popular plugins of all time with over 6 million downloads.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Alex Rabe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"Ultimate TinyMCE";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/extend/plugins/ultimate-tinymce/#post-32088";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 14 Nov 2011 09:06:40 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:42:"32088@http://wordpress.org/extend/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:84:"Description: Beef up your visual tinymce editor with a plethora of advanced options.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Josh";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WooCommerce - excelling eCommerce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/extend/plugins/woocommerce/#post-29860";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 05 Sep 2011 08:13:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:42:"29860@http://wordpress.org/extend/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:97:"WooCommerce is a powerful, extendable eCommerce plugin that helps you sell anything. Beautifully.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"WooThemes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:11:"WP Smush.it";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"http://wordpress.org/extend/plugins/wp-smushit/#post-7936";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 04 Dec 2008 00:00:37 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:41:"7936@http://wordpress.org/extend/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:88:"Reduce image file sizes and improve performance using the Smush.it API within WordPress.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"Alex Dunae";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:8:"BackWPup";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"http://wordpress.org/extend/plugins/backwpup/#post-11392";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 23 Jun 2009 11:31:17 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:42:"11392@http://wordpress.org/extend/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:53:"Flexible, scheduled WordPress backups to any location";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Daniel Huesken";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"W3 Total Cache";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:62:"http://wordpress.org/extend/plugins/w3-total-cache/#post-12073";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 29 Jul 2009 18:46:31 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:42:"12073@http://wordpress.org/extend/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:132:"Easy Web Performance Optimization (WPO) using caching: browser, page, object, database, minify and content delivery network support.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Frederick Townes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:8:"Facebook";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"http://wordpress.org/extend/plugins/facebook/#post-37351";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 02 May 2012 19:36:35 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:42:"37351@http://wordpress.org/extend/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:131:"Add Facebook social plugins and the ability to publish new posts to a Facebook Timeline or Facebook Page. Official Facebook plugin.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:18:"Samuel Wood (Otto)";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:52:"http://wordpress.org/extend/plugins/rss/view/popular";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:10:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Thu, 21 Mar 2013 15:06:49 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:4:"vary";s:15:"Accept-Encoding";s:7:"expires";s:29:"Thu, 21 Mar 2013 15:12:09 GMT";s:13:"cache-control";s:0:"";s:6:"pragma";s:0:"";s:13:"last-modified";s:31:"Thu, 21 Mar 2013 14:37:09 +0000";s:4:"x-nc";s:11:"HIT luv 138";s:10:"connection";s:5:"close";}s:5:"build";s:14:"20121202224312";}', 'no') ; 
INSERT INTO `wp_options` VALUES (324, '_transient_timeout_feed_mod_a5420c83891a9c88ad2a4f04584a5efc', '1363921609', 'no') ; 
INSERT INTO `wp_options` VALUES (326, '_transient_feed_mod_a5420c83891a9c88ad2a4f04584a5efc', '1363878409', 'no') ; 
INSERT INTO `wp_options` VALUES (328, '_transient_timeout_feed_57bc725ad6568758915363af670fd8bc', '1363921610', 'no') ; 
INSERT INTO `wp_options` VALUES (329, '_transient_feed_57bc725ad6568758915363af670fd8bc', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"
	
";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:72:"
		
		
		
		
		
		
				

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WordPress Plugins » View: Newest";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:47:"http://wordpress.org/extend/plugins/browse/new/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:33:"WordPress Plugins » View: Newest";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 21 Mar 2013 14:45:26 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:25:"http://bbpress.org/?v=1.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:15:{i:0;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:21:"Replytocom Controller";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:69:"http://wordpress.org/extend/plugins/replytocom-controller/#post-50974";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 20 Mar 2013 23:31:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:42:"50974@http://wordpress.org/extend/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:123:"Replytocom Controller lets remove &#34;?replytocom&#34; from comment reply urls and redirect bots who try to use it anyway.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"ClaytonL";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:29:"OAuth2 Complete For WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:63:"http://wordpress.org/extend/plugins/oauth2-provider/#post-50976";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 21 Mar 2013 00:17:48 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:42:"50976@http://wordpress.org/extend/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:150:"Allows WordPress to use OAuth 2 and become a SSO - Data provider. Your site will be able provided Single Sign On and also deliver authorized user data";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Justin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:11:"Theme Logic";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/extend/plugins/theme-logic/#post-50966";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 20 Mar 2013 19:10:48 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:42:"50966@http://wordpress.org/extend/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:56:"Enables you to change the active theme based on context.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:7:"shazdeh";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"Simple Video Gallery";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:68:"http://wordpress.org/extend/plugins/simple-video-gallery/#post-50968";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 20 Mar 2013 21:48:34 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:42:"50968@http://wordpress.org/extend/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:42:"Simple video gallery plugin for WordPress!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:7:"mch0lic";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"Smooth Scroll Up";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/extend/plugins/smooth-scroll-up/#post-50957";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 20 Mar 2013 11:31:40 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:42:"50957@http://wordpress.org/extend/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:139:"Scroll Up plugin lightweight plugin that creates a customizable &#34;Scroll to top&#34; feature in any post/page of your WordPress website.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:23:"Konstantinos Kouratoras";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:10:"GaugePress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:58:"http://wordpress.org/extend/plugins/gaugepress/#post-50961";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 20 Mar 2013 15:08:26 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:42:"50961@http://wordpress.org/extend/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:90:"GaugePress is a handy WordPress plugin for generating and animating nice and clean gauges.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:23:"Konstantinos Kouratoras";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"SocialCountdown Plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:63:"http://wordpress.org/extend/plugins/socialcountdown/#post-50977";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 21 Mar 2013 00:56:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:42:"50977@http://wordpress.org/extend/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:100:"Provides a very easy way to integrate a SocialCountdown.com countdown timer into a wordpress website";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:7:"intulon";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"Force Post Content";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:66:"http://wordpress.org/extend/plugins/force-post-content/#post-50943";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 20 Mar 2013 00:07:12 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:42:"50943@http://wordpress.org/extend/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:132:"A simple plugin to force user to write Post content in Add Post page. Based on Jatinder Pal Singh’s ”Force Post Title” plugin.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"ashorlivs";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"WP Exclude From Homepage";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:72:"http://wordpress.org/extend/plugins/wp-exclude-from-homepage/#post-50937";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 19 Mar 2013 19:25:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:42:"50937@http://wordpress.org/extend/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:89:"Exclude categories, tags, posts or pages from your homepage (without breaking pagination)";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"iziwebavenir";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:17:"Link Removal Tool";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:65:"http://wordpress.org/extend/plugins/link-removal-tool/#post-50626";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 12 Mar 2013 13:03:47 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:42:"50626@http://wordpress.org/extend/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:98:"Removes links from content on your website.  Instantly remove any and all links to any defined URL";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:18:"outsourcingexposed";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:17:"Simplest Colorbox";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:65:"http://wordpress.org/extend/plugins/simplest-colorbox/#post-50941";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 19 Mar 2013 23:13:11 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:42:"50941@http://wordpress.org/extend/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:218:"Adds a very simple colorbox to your images. This plugin bases on &#34;Simple Colorbox&#34; by Ryan Hellyer: <a href="http://wordpress.org/extend/plugins/simp" rel="nofollow">http://wordpress.org/extend/plugins/simp</a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"simpson-fan";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"Better @ Reply";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/extend/plugins/better-reply/#post-50935";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 19 Mar 2013 18:20:59 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:42:"50935@http://wordpress.org/extend/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:107:"This plugin allows you to add Twitter-like @reply links to comments. Shows old comment after hover on link.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"simpson-fan";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"Sell Downloads";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:62:"http://wordpress.org/extend/plugins/sell-downloads/#post-50886";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 18 Mar 2013 23:55:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:42:"50886@http://wordpress.org/extend/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:150:"Sell Downloads is an online store for selling downloadable files: audio, video, documents, pictures all that may be published in Internet. Sell Downlo";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"codepeople";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:13:"Scan-to-Login";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:61:"http://wordpress.org/extend/plugins/scan-to-login/#post-50877";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 18 Mar 2013 13:22:23 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:42:"50877@http://wordpress.org/extend/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:97:"A simple plugin enabling you to log into WordPress by scanning a QR Code with your mobile device.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"globalkinetic";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"Image In The Widget";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:67:"http://wordpress.org/extend/plugins/image-in-the-widget/#post-50870";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 18 Mar 2013 03:54:47 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:42:"50870@http://wordpress.org/extend/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:98:"A simple widget that uses the native WordPress media manager to add images to widget of your site.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:19:"Sapian Technologies";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:48:"http://wordpress.org/extend/plugins/rss/view/new";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:10:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Thu, 21 Mar 2013 15:06:50 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:4:"vary";s:15:"Accept-Encoding";s:7:"expires";s:29:"Thu, 21 Mar 2013 15:20:26 GMT";s:13:"cache-control";s:0:"";s:6:"pragma";s:0:"";s:13:"last-modified";s:31:"Thu, 21 Mar 2013 14:45:26 +0000";s:4:"x-nc";s:11:"HIT luv 138";s:10:"connection";s:5:"close";}s:5:"build";s:14:"20121202224312";}', 'no') ; 
INSERT INTO `wp_options` VALUES (330, '_transient_timeout_feed_mod_57bc725ad6568758915363af670fd8bc', '1363921610', 'no') ; 
INSERT INTO `wp_options` VALUES (331, '_transient_feed_mod_57bc725ad6568758915363af670fd8bc', '1363878410', 'no') ; 
INSERT INTO `wp_options` VALUES (353, '_site_transient_timeout_browser_524bc892d6262ff099bceca9e958b2e6', '1366035925', 'yes') ; 
INSERT INTO `wp_options` VALUES (354, '_site_transient_browser_524bc892d6262ff099bceca9e958b2e6', 'a:9:{s:8:"platform";s:7:"Windows";s:4:"name";s:6:"Chrome";s:7:"version";s:12:"26.0.1410.43";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (371, 'wpbdp-field-short-names', 'a:9:{i:1;s:13:"business-name";i:2;s:14:"business-genre";i:3;s:26:"short-business-description";i:4;s:25:"long-business-description";i:5;s:24:"business-website-address";i:6;s:21:"business-phone-number";i:7;s:12:"business-fax";i:8;s:22:"business-contact-email";i:9;s:13:"business-tags";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (372, 'wpbdp-db-version', '3.3', 'yes') ; 
INSERT INTO `wp_options` VALUES (376, 'wpbdp-payments-on', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (377, 'wpbdp-payments-test-mode', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (378, 'wpbdp-currency', 'USD', 'yes') ; 
INSERT INTO `wp_options` VALUES (379, 'wpbdp-currency-symbol', '$', 'yes') ; 
INSERT INTO `wp_options` VALUES (380, 'wpbdp-payment-message', 'Thank you for your payment. Your payment is being verified and your listing reviewed. The verification and review process could take up to 48 hours.', 'yes') ; 
INSERT INTO `wp_options` VALUES (381, 'wpbdp-googlecheckout', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (382, 'wpbdp-googlecheckout-merchant', '718629333018307', 'yes') ; 
INSERT INTO `wp_options` VALUES (383, 'wpbdp-paypal', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (384, 'wpbdp-paypal-business-email', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (385, 'wpbdp-2checkout', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (386, 'wpbdp-2checkout-seller', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (387, '_transient_timeout_settings_errors', '1368734486', 'no') ; 
INSERT INTO `wp_options` VALUES (388, '_transient_settings_errors', 'a:1:{i:0;a:4:{s:7:"setting";s:7:"general";s:4:"code";s:16:"settings_updated";s:7:"message";s:15:"Settings saved.";s:4:"type";s:7:"updated";}}', 'no') ; 
INSERT INTO `wp_options` VALUES (398, 'rewrite_rules', 'a:99:{s:41:"(business-directory)/page/?([0-9]{1,})/?$";s:38:"index.php?page_id=73&paged=$matches[2]";s:41:"(business-directory)/([0-9]{1,})/?(.*)/?$";s:35:"index.php?page_id=73&id=$matches[2]";s:62:"(business-directory)/wpbdm-category/(.+?)/page/?([0-9]{1,})/?$";s:59:"index.php?page_id=73&category=$matches[2]&paged=$matches[3]";s:44:"(business-directory)/wpbdm-category/(.+?)/?$";s:41:"index.php?page_id=73&category=$matches[2]";s:58:"(business-directory)/wpbdm-tags/(.+?)/page/?([0-9]{1,})/?$";s:54:"index.php?page_id=73&tag=$matches[2]&paged=$matches[3]";s:38:"(business-directory)/wpbdm-tags/(.+?)$";s:36:"index.php?page_id=73&tag=$matches[2]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:41:"wpbdp_listing/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:51:"wpbdp_listing/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:71:"wpbdp_listing/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:66:"wpbdp_listing/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:66:"wpbdp_listing/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:34:"wpbdp_listing/([^/]+)/trackback/?$";s:40:"index.php?wpbdp_listing=$matches[1]&tb=1";s:54:"wpbdp_listing/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?wpbdp_listing=$matches[1]&feed=$matches[2]";s:49:"wpbdp_listing/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?wpbdp_listing=$matches[1]&feed=$matches[2]";s:42:"wpbdp_listing/([^/]+)/page/?([0-9]{1,})/?$";s:53:"index.php?wpbdp_listing=$matches[1]&paged=$matches[2]";s:49:"wpbdp_listing/([^/]+)/comment-page-([0-9]{1,})/?$";s:53:"index.php?wpbdp_listing=$matches[1]&cpage=$matches[2]";s:34:"wpbdp_listing/([^/]+)(/[0-9]+)?/?$";s:52:"index.php?wpbdp_listing=$matches[1]&page=$matches[2]";s:30:"wpbdp_listing/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:40:"wpbdp_listing/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:60:"wpbdp_listing/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:55:"wpbdp_listing/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:55:"wpbdp_listing/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:55:"wpbdm-category/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:53:"index.php?wpbdm-category=$matches[1]&feed=$matches[2]";s:50:"wpbdm-category/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:53:"index.php?wpbdm-category=$matches[1]&feed=$matches[2]";s:43:"wpbdm-category/([^/]+)/page/?([0-9]{1,})/?$";s:54:"index.php?wpbdm-category=$matches[1]&paged=$matches[2]";s:25:"wpbdm-category/([^/]+)/?$";s:36:"index.php?wpbdm-category=$matches[1]";s:51:"wpbdm-tags/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?wpbdm-tags=$matches[1]&feed=$matches[2]";s:46:"wpbdm-tags/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?wpbdm-tags=$matches[1]&feed=$matches[2]";s:39:"wpbdm-tags/([^/]+)/page/?([0-9]{1,})/?$";s:50:"index.php?wpbdm-tags=$matches[1]&paged=$matches[2]";s:21:"wpbdm-tags/([^/]+)/?$";s:32:"index.php?wpbdm-tags=$matches[1]";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:29:"comments/page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)(/[0-9]+)?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)(/[0-9]+)?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (404, '_site_transient_timeout_browser_9cd12bc0603f21c5a2851402152b635b', '1369338469', 'yes') ; 
INSERT INTO `wp_options` VALUES (405, '_site_transient_browser_9cd12bc0603f21c5a2851402152b635b', 'a:9:{s:8:"platform";s:7:"Windows";s:4:"name";s:6:"Chrome";s:7:"version";s:12:"26.0.1410.64";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (407, 'ups_sidebars', 'a:2:{s:13:"ups-sidebar-1";a:7:{s:5:"pages";a:1:{i:54;s:5:"About";}s:4:"name";s:8:"About Us";s:11:"description";s:0:"";s:12:"before_title";s:0:"";s:11:"after_title";s:0:"";s:13:"before_widget";s:0:"";s:12:"after_widget";s:0:"";}s:13:"ups-sidebar-2";a:7:{s:5:"pages";a:1:{i:20;s:7:"History";}s:4:"name";s:7:"History";s:11:"description";s:0:"";s:12:"before_title";s:0:"";s:11:"after_title";s:0:"";s:13:"before_widget";s:0:"";s:12:"after_widget";s:0:"";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (408, 'widget_pages', 'a:2:{i:2;a:3:{s:5:"title";s:5:"Pages";s:6:"sortby";s:10:"post_title";s:7:"exclude";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (417, '_site_transient_update_plugins', 'O:8:"stdClass":2:{s:12:"last_checked";i:1369418293;s:8:"response";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (419, 'gf_paypal_configured', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (420, '_transient_doing_cron', '1369418283.1541469097137451171875', 'yes') ; 
INSERT INTO `wp_options` VALUES (421, '_site_transient_timeout_theme_roots', '1369420094', 'yes') ; 
INSERT INTO `wp_options` VALUES (422, '_site_transient_theme_roots', 'a:1:{s:7:"base_wp";s:7:"/themes";}', 'yes') ;
#
# End of data contents of table wp_options
# --------------------------------------------------------

# WordPress : http://basewp MySQL database backup
#
# Generated: Friday 24. May 2013 17:58 UTC
# Hostname: localhost
# Database: `basewp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_postmeta (18 records)
#
 
INSERT INTO `wp_postmeta` VALUES (1, 2, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (2, 4, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (3, 4, '_edit_lock', '1363703266:1') ; 
INSERT INTO `wp_postmeta` VALUES (4, 54, '_edit_lock', '1369324614:1') ; 
INSERT INTO `wp_postmeta` VALUES (5, 54, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (8, 76, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (9, 76, '_edit_lock', '1366905662:1') ; 
INSERT INTO `wp_postmeta` VALUES (10, 76, '_wpbdp[payment_status]', 'paid') ; 
INSERT INTO `wp_postmeta` VALUES (11, 76, '_wpbdp[fields][5]', 'a:2:{i:0;s:31:"218 S Main St  Joplin, MO 64801";i:1;s:8:"Visit Us";}') ; 
INSERT INTO `wp_postmeta` VALUES (12, 76, '_wpbdp[fields][6]', '417-626-8111') ; 
INSERT INTO `wp_postmeta` VALUES (13, 76, '_wpbdp[fields][7]', '417-626-8224') ; 
INSERT INTO `wp_postmeta` VALUES (14, 76, '_wpbdp[fields][8]', 'dbennett@caldones.com') ; 
INSERT INTO `wp_postmeta` VALUES (17, 22, '_edit_lock', '1366905672:1') ; 
INSERT INTO `wp_postmeta` VALUES (18, 2, '_edit_lock', '1366905675:1') ; 
INSERT INTO `wp_postmeta` VALUES (19, 32, '_edit_lock', '1366905679:1') ; 
INSERT INTO `wp_postmeta` VALUES (20, 17, '_edit_lock', '1366905694:1') ; 
INSERT INTO `wp_postmeta` VALUES (31, 28, '_edit_lock', '1366905698:1') ; 
INSERT INTO `wp_postmeta` VALUES (32, 20, '_edit_lock', '1368736042:1') ;
#
# End of data contents of table wp_postmeta
# --------------------------------------------------------

# WordPress : http://basewp MySQL database backup
#
# Generated: Friday 24. May 2013 17:58 UTC
# Hostname: localhost
# Database: `basewp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------


#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_posts (83 records)
#
 
INSERT INTO `wp_posts` VALUES (1, 1, '2013-03-14 16:38:54', '2013-03-14 16:38:54', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2013-03-14 16:38:54', '2013-03-14 16:38:54', '', 0, 'http://basewp/?p=1', 0, 'post', '', 1) ; 
INSERT INTO `wp_posts` VALUES (2, 1, '2013-03-14 16:38:54', '2013-03-14 16:38:54', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:

<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>

...or something like this:

<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>

As a new WordPress user, you should go to <a href="http://basewp/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'publish', 'open', 'open', '', 'sample-page', '', '', '2013-04-25 10:03:36', '2013-04-25 16:03:36', '', 0, 'http://basewp/?page_id=2', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (4, 1, '2013-03-14 16:41:02', '2013-03-14 22:41:02', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Phasellus hendrerit. Pellentesque aliquet nibh nec urna. In nisi neque, aliquet vel, dapibus id, mattis vel, nisi. Sed pretium, ligula sollicitudin laoreet viverra, tortor libero sodales leo, eget blandit nunc tortor eu nibh. Nullam mollis. Ut justo. Suspendisse potenti.

Sed egestas, ante et vulputate volutpat, eros pede semper est, vitae luctus metus libero eu augue. Morbi purus libero, faucibus adipiscing, commodo quis, gravida id, est. Sed lectus. Praesent elementum hendrerit tortor. Sed semper lorem at felis. Vestibulum volutpat, lacus a ultrices sagittis, mi neque euismod dui, eu pulvinar nunc sapien ornare nisl. Phasellus pede arcu, dapibus eu, fermentum et, dapibus sed, urna.', 'Post Title', '', 'publish', 'open', 'open', '', 'post-title', '', '', '2013-03-19 08:18:42', '2013-03-19 14:18:42', '', 0, 'http://basewp/?p=4', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5, 1, '2013-03-14 16:40:56', '2013-03-14 16:40:56', '', 'Post TItle', '', 'inherit', 'open', 'open', '', '4-revision', '', '', '2013-03-14 16:40:56', '2013-03-14 16:40:56', '', 4, 'http://basewp/?p=5', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7, 1, '2008-08-02 19:52:26', '2008-08-03 00:52:26', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Sed eleifend urna eu sapien. Quisque posuere nunc eu massa. Praesent bibendum lorem non leo. Morbi volutpat, urna eu fermentum rutrum, ligula lacus interdum mauris, ac pulvinar libero pede a enim. Etiam commodo malesuada ante. Donec nec ligula. Curabitur mollis semper diam. <!--more-->

Duis viverra nibh a felis condimentum pretium. Nullam tristique lacus non purus. Donec vel felis. Etiam et sapien. Pellentesque nec quam a justo tincidunt laoreet. Aenean id enim. Donec lorem arcu, eleifend venenatis, rhoncus mollis, semper at, dui. Praesent velit tellus, adipiscing et, blandit convallis, dictum at, dui. Integer suscipit tortor in orci. Phasellus consequat. Quisque dictum convallis pede.

Mauris viverra scelerisque mauris. Nulla facilisis, elit malesuada pretium egestas, dolor arcu commodo est, at egestas massa tortor ut ante. Etiam eget libero. Aenean pretium, tellus sed sodales semper, turpis purus aliquet orci, pulvinar ornare odio tortor sit amet dui.

Aenean id orci. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus magna. Mauris tincidunt iaculis enim. Duis a mi vitae sapien dapibus tincidunt. Proin metus.

Proin cursus, libero non auctor faucibus, urna mi vestibulum orci, sit amet fermentum nibh purus eget enim. Aenean aliquet ligula nec nulla. Praesent sit amet lorem vitae massa hendrerit auctor. Sed sit amet urna. Aenean sapien nunc, imperdiet a, pharetra in, consequat eu, neque. Phasellus vel sem gravida augue consequat tempor. Curabitur eget mauris at pede varius facilisis.

Morbi ut sapien. Morbi arcu mauris, suscipit congue, placerat sit amet, suscipit a, ante. Donec aliquet dui ac nunc. Mauris magna quam, aliquet quis, viverra eu, fringilla eget, purus. Donec tristique pretium sem.', 'A Simple Post with Text', '', 'publish', 'open', 'open', '', 'a-simple-post-with-text', '', '', '2008-08-02 19:52:26', '2008-08-03 00:52:26', '', 0, 'http://dev.danphilibin.com/wordpress/?p=22', 0, 'post', '', 1) ; 
INSERT INTO `wp_posts` VALUES (8, 1, '2008-09-02 19:52:17', '2008-09-03 00:52:17', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Sed eleifend urna eu sapien. Quisque posuere nunc eu massa. Praesent bibendum lorem non leo. Morbi volutpat, urna eu fermentum rutrum, ligula lacus interdum mauris, ac pulvinar libero pede a enim. Etiam commodo malesuada ante. Donec nec ligula. Curabitur mollis semper diam. <!--more-->

Duis viverra nibh a felis condimentum pretium. Nullam tristique lacus non purus. Donec vel felis. Etiam et sapien. Pellentesque nec quam a justo tincidunt laoreet. Aenean id enim. Donec lorem arcu, eleifend venenatis, rhoncus mollis, semper at, dui. Praesent velit tellus, adipiscing et, blandit convallis, dictum at, dui. Integer suscipit tortor in orci. Phasellus consequat. Quisque dictum convallis pede.

Mauris viverra scelerisque mauris. Nulla facilisis, elit malesuada pretium egestas, dolor arcu commodo est, at egestas massa tortor ut ante. Etiam eget libero. Aenean pretium, tellus sed sodales semper, turpis purus aliquet orci, pulvinar ornare odio tortor sit amet dui.

Aenean id orci. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus magna. Mauris tincidunt iaculis enim. Duis a mi vitae sapien dapibus tincidunt. Proin metus.

Proin cursus, libero non auctor faucibus, urna mi vestibulum orci, sit amet fermentum nibh purus eget enim. Aenean aliquet ligula nec nulla. Praesent sit amet lorem vitae massa hendrerit auctor. Sed sit amet urna. Aenean sapien nunc, imperdiet a, pharetra in, consequat eu, neque. Phasellus vel sem gravida augue consequat tempor. Curabitur eget mauris at pede varius facilisis.

Morbi ut sapien. Morbi arcu mauris, suscipit congue, placerat sit amet, suscipit a, ante. Donec aliquet dui ac nunc. Mauris magna quam, aliquet quis, viverra eu, fringilla eget, purus. Donec tristique pretium sem.', 'A Simple Post with Text', '', 'inherit', 'open', 'open', '', '22-revision', '', '', '2008-09-02 19:52:17', '2008-09-03 00:52:17', '', 7, 'http://dev.danphilibin.com/wordpress/?p=23', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (9, 1, '2008-09-02 19:52:26', '2008-09-03 00:52:26', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Sed eleifend urna eu sapien. Quisque posuere nunc eu massa. Praesent bibendum lorem non leo. Morbi volutpat, urna eu fermentum rutrum, ligula lacus interdum mauris, ac pulvinar libero pede a enim. Etiam commodo malesuada ante. Donec nec ligula. Curabitur mollis semper diam. <!--more-->

Duis viverra nibh a felis condimentum pretium. Nullam tristique lacus non purus. Donec vel felis. Etiam et sapien. Pellentesque nec quam a justo tincidunt laoreet. Aenean id enim. Donec lorem arcu, eleifend venenatis, rhoncus mollis, semper at, dui. Praesent velit tellus, adipiscing et, blandit convallis, dictum at, dui. Integer suscipit tortor in orci. Phasellus consequat. Quisque dictum convallis pede.

Mauris viverra scelerisque mauris. Nulla facilisis, elit malesuada pretium egestas, dolor arcu commodo est, at egestas massa tortor ut ante. Etiam eget libero. Aenean pretium, tellus sed sodales semper, turpis purus aliquet orci, pulvinar ornare odio tortor sit amet dui.

Aenean id orci. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus magna. Mauris tincidunt iaculis enim. Duis a mi vitae sapien dapibus tincidunt. Proin metus.

Proin cursus, libero non auctor faucibus, urna mi vestibulum orci, sit amet fermentum nibh purus eget enim. Aenean aliquet ligula nec nulla. Praesent sit amet lorem vitae massa hendrerit auctor. Sed sit amet urna. Aenean sapien nunc, imperdiet a, pharetra in, consequat eu, neque. Phasellus vel sem gravida augue consequat tempor. Curabitur eget mauris at pede varius facilisis.

Morbi ut sapien. Morbi arcu mauris, suscipit congue, placerat sit amet, suscipit a, ante. Donec aliquet dui ac nunc. Mauris magna quam, aliquet quis, viverra eu, fringilla eget, purus. Donec tristique pretium sem.', 'A Simple Post with Text', '', 'inherit', 'open', 'open', '', '22-revision-2', '', '', '2008-09-02 19:52:26', '2008-09-03 00:52:26', '', 7, 'http://dev.danphilibin.com/wordpress/?p=52', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (10, 1, '2008-09-11 15:12:39', '2008-09-11 20:12:39', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur quam augue, vehicula quis, tincidunt vel, varius vitae, nulla. Sed convallis orci. Duis libero orci, pretium a, <a href="#">convallis quis</a>, pellentesque a, dolor. Curabitur vitae nisi non dolor vestibulum consequat.

<blockquote>

<h3>An Unordered List</h3>

<ul>
<li>Vestibulum in mauris semper tortor interdum ultrices.</li>
<li>Sed vel lorem et justo laoreet bibendum. Donec dictum.</li>
<li>Etiam massa libero, lacinia at, commodo in, tincidunt a, purus.</li>
<li>Praesent volutpat eros quis enim blandit tincidunt.</li>
<li>Aenean eu libero nec lectus ultricies laoreet. Donec rutrum, nisi vel egestas ultrices, ipsum urna sagittis libero, vitae vestibulum dui dolor vel velit.</li>
</ul>

Nulla sagittis convallis arcu. Sed sed nunc. Curabitur consequat. Quisque metus enim, venenatis fermentum, mollis in, porta et, nibh. Duis vulputate elit in elit. Mauris dictum libero id justo. Fusce in est. Sed nec diam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Quisque semper nibh eget nibh. Sed tempor. Fusce erat.

<h3>An Ordered List</h3>

<ol>
<li>Vestibulum in mauris semper tortor interdum ultrices.</li>
<li>Sed vel lorem et justo laoreet bibendum. Donec dictum.</li>
<li>Etiam massa libero, lacinia at, commodo in, tincidunt a, purus.</li>
<li>Praesent volutpat eros quis enim blandit tincidunt.</li>
<li>Aenean eu libero nec lectus ultricies laoreet. Donec rutrum, nisi vel egestas ultrices, ipsum urna sagittis libero, vitae vestibulum dui dolor vel velit.</li>
</ol>', 'About Us', '', 'inherit', 'open', 'open', '', '25-revision', '', '', '2008-09-11 15:12:39', '2008-09-11 20:12:39', '', 28, 'http://dev.danphilibin.com/wordpress/?p=26', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (11, 1, '2008-09-11 15:13:16', '2008-09-11 20:13:16', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur quam augue, vehicula quis, tincidunt vel, varius vitae, nulla. Sed convallis orci. Duis libero orci, pretium a, <a href="#">convallis quis</a>, pellentesque a, dolor. Curabitur vitae nisi non dolor vestibulum consequat.

<blockquote>Proin vestibulum. Ut ligula. Nullam sed dolor id odio volutpat pulvinar. Integer a leo. In et eros at neque pretium sagittis. Sed sodales lorem a ipsum suscipit gravida. Ut fringilla placerat arcu. Phasellus imperdiet. Mauris ac justo et turpis pharetra vulputate.</blockquote>
<cite><a href="#">Quote Source</a></cite>

<h3>An Unordered List</h3>

<ul>
<li>Vestibulum in mauris semper tortor interdum ultrices.</li>
<li>Sed vel lorem et justo laoreet bibendum. Donec dictum.</li>
<li>Etiam massa libero, lacinia at, commodo in, tincidunt a, purus.</li>
<li>Praesent volutpat eros quis enim blandit tincidunt.</li>
<li>Aenean eu libero nec lectus ultricies laoreet. Donec rutrum, nisi vel egestas ultrices, ipsum urna sagittis libero, vitae vestibulum dui dolor vel velit.</li>
</ul>

Nulla sagittis convallis arcu. Sed sed nunc. Curabitur consequat. Quisque metus enim, venenatis fermentum, mollis in, porta et, nibh. Duis vulputate elit in elit. Mauris dictum libero id justo. Fusce in est. Sed nec diam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Quisque semper nibh eget nibh. Sed tempor. Fusce erat.

<h3>An Ordered List</h3>

<ol>
<li>Vestibulum in mauris semper tortor interdum ultrices.</li>
<li>Sed vel lorem et justo laoreet bibendum. Donec dictum.</li>
<li>Etiam massa libero, lacinia at, commodo in, tincidunt a, purus.</li>
<li>Praesent volutpat eros quis enim blandit tincidunt.</li>
<li>Aenean eu libero nec lectus ultricies laoreet. Donec rutrum, nisi vel egestas ultrices, ipsum urna sagittis libero, vitae vestibulum dui dolor vel velit.</li>
</ol>', 'About Us', '', 'inherit', 'open', 'open', '', '25-revision-2', '', '', '2008-09-11 15:13:16', '2008-09-11 20:13:16', '', 28, 'http://dev.danphilibin.com/wordpress/?p=29', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (12, 1, '2008-09-11 15:17:23', '2008-09-11 20:17:23', '<img src="http://i35.tinypic.com/990wtx.png" alt="WordPress Logo" align="rigLorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur quam augue, vehicula quis, tincidunt vel, varius vitae, nulla. Sed convallis orci. Duis libero orci, pretium a, <a href="#">convallis quis</a>, pellentesque a, dolor. Curabitur vitae nisi non dolor vestibulum consequat.

<blockquote>Proin vestibulum. Ut ligula. Nullam sed dolor id odio volutpat pulvinar. Integer a leo. In et eros at neque pretium sagittis. Sed sodales lorem a ipsum suscipit gravida. Ut fringilla placerat arcu. Phasellus imperdiet. Mauris ac justo et turpis pharetra vulputate.</blockquote>
<cite><a href="#">Quote Source</a></cite>

<h3>An Unordered List</h3>

<ul>
<li>Vestibulum in mauris semper tortor interdum ultrices.</li>
<li>Sed vel lorem et justo laoreet bibendum. Donec dictum.</li>
<li>Etiam massa libero, lacinia at, commodo in, tincidunt a, purus.</li>
<li>Praesent volutpat eros quis enim blandit tincidunt.</li>
<li>Aenean eu libero nec lectus ultricies laoreet. Donec rutrum, nisi vel egestas ultrices, ipsum urna sagittis libero, vitae vestibulum dui dolor vel velit.</li>
</ul>

Nulla sagittis convallis arcu. Sed sed nunc. Curabitur consequat. Quisque metus enim, venenatis fermentum, mollis in, porta et, nibh. Duis vulputate elit in elit. Mauris dictum libero id justo. Fusce in est. Sed nec diam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Quisque semper nibh eget nibh. Sed tempor. Fusce erat.

<h3>An Ordered List</h3>

<ol>
<li>Vestibulum in mauris semper tortor interdum ultrices.</li>
<li>Sed vel lorem et justo laoreet bibendum. Donec dictum.</li>
<li>Etiam massa libero, lacinia at, commodo in, tincidunt a, purus.</li>
<li>Praesent volutpat eros quis enim blandit tincidunt.</li>
<li>Aenean eu libero nec lectus ultricies laoreet. Donec rutrum, nisi vel egestas ultrices, ipsum urna sagittis libero, vitae vestibulum dui dolor vel velit.</li>
</ol>', 'About Us', '', 'inherit', 'open', 'open', '', '25-autosave', '', '', '2008-09-11 15:17:23', '2008-09-11 20:17:23', '', 28, 'http://dev.danphilibin.com/wordpress/?p=28', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (13, 1, '2008-09-11 15:17:32', '2008-09-11 20:17:32', '<img src="http://i35.tinypic.com/990wtx.png" alt="WordPress Logo" align="right" class="alignright" />Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur quam augue, vehicula quis, tincidunt vel, varius vitae, nulla. Sed convallis orci. Duis libero orci, pretium a, <a href="#">convallis quis</a>, pellentesque a, dolor. Curabitur vitae nisi non dolor vestibulum consequat.

<blockquote>Proin vestibulum. Ut ligula. Nullam sed dolor id odio volutpat pulvinar. Integer a leo. In et eros at neque pretium sagittis. Sed sodales lorem a ipsum suscipit gravida. Ut fringilla placerat arcu. Phasellus imperdiet. Mauris ac justo et turpis pharetra vulputate.</blockquote>
<cite><a href="#">Quote Source</a></cite>

<h3>An Unordered List</h3>

<ul>
<li>Vestibulum in mauris semper tortor interdum ultrices.</li>
<li>Sed vel lorem et justo laoreet bibendum. Donec dictum.</li>
<li>Etiam massa libero, lacinia at, commodo in, tincidunt a, purus.</li>
<li>Praesent volutpat eros quis enim blandit tincidunt.</li>
<li>Aenean eu libero nec lectus ultricies laoreet. Donec rutrum, nisi vel egestas ultrices, ipsum urna sagittis libero, vitae vestibulum dui dolor vel velit.</li>
</ul>

Nulla sagittis convallis arcu. Sed sed nunc. Curabitur consequat. Quisque metus enim, venenatis fermentum, mollis in, porta et, nibh. Duis vulputate elit in elit. Mauris dictum libero id justo. Fusce in est. Sed nec diam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Quisque semper nibh eget nibh. Sed tempor. Fusce erat.

<h3>An Ordered List</h3>

<ol>
<li>Vestibulum in mauris semper tortor interdum ultrices.</li>
<li>Sed vel lorem et justo laoreet bibendum. Donec dictum.</li>
<li>Etiam massa libero, lacinia at, commodo in, tincidunt a, purus.</li>
<li>Praesent volutpat eros quis enim blandit tincidunt.</li>
<li>Aenean eu libero nec lectus ultricies laoreet. Donec rutrum, nisi vel egestas ultrices, ipsum urna sagittis libero, vitae vestibulum dui dolor vel velit.</li>
</ol>', 'About Us', '', 'inherit', 'open', 'open', '', '25-revision-3', '', '', '2008-09-11 15:17:32', '2008-09-11 20:17:32', '', 28, 'http://dev.danphilibin.com/wordpress/?p=49', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (14, 1, '2008-09-11 19:19:53', '2008-09-12 00:19:53', '', 'Our Company', '', 'inherit', 'open', 'open', '', '30-revision', '', '', '2008-09-11 19:19:53', '2008-09-12 00:19:53', '', 15, 'http://dev.danphilibin.com/wordpress/?p=31', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (15, 1, '2008-09-11 19:20:11', '2008-09-12 00:20:11', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nam vel turpis. Duis sit amet lectus ac mauris porta viverra. Aliquam erat volutpat. Praesent ipsum pede, pretium sed, congue nec, pretium quis, urna. Suspendisse dignissim, elit in ultrices sollicitudin, nisl est accumsan orci, a venenatis dui mi porta pede. Aenean et pede quis est tincidunt varius.

Cras aliquet. Integer faucibus, eros ac molestie placerat, enim tellus varius lacus, nec dictum nunc tortor id urna. Suspendisse dapibus ullamcorper pede. Vivamus ligula ipsum, faucibus at, tincidunt eget, porttitor non, dolor. Ut dui lectus, ultrices ut, sodales tincidunt, viverra sed, nisl.

Praesent ac quam vulputate felis ultrices scelerisque. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. In in arcu. Vestibulum eget nisi quis tellus elementum dapibus. Cras facilisis venenatis libero. Nunc accumsan viverra augue. Suspendisse potenti. Suspendisse eleifend. Maecenas sit amet justo.

Quisque quam nisi, mollis quis, sodales ut, rhoncus nec, risus. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Proin pede. Aliquam neque tortor, euismod ac, eleifend quis, tincidunt quis, neque.

Phasellus rhoncus. Donec urna nulla, vehicula et, consectetuer vel, condimentum quis, ipsum. Nulla quis neque eu sapien tincidunt faucibus. Donec eleifend, metus sed elementum lobortis, arcu elit luctus enim, sed vestibulum diam leo nec nunc. Suspendisse tempus.

Phasellus quis mauris. Integer eu justo. Fusce tortor enim, elementum ut, auctor non, accumsan quis, enim. Aenean posuere ante id odio. Nulla facilisi. Donec ac eros quis ipsum auctor blandit. Cras eleifend libero fringilla turpis. Integer sem. Curabitur commodo dapibus lacus.

Vivamus semper auctor turpis. Sed ipsum lacus, varius quis, iaculis at, mollis sagittis, arcu.', 'Our Company', '', 'publish', 'open', 'open', '', 'our-company', '', '', '2013-04-25 10:03:36', '2013-04-25 16:03:36', '', 28, 'http://dev.danphilibin.com/wordpress/?page_id=30', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (16, 1, '2008-09-11 19:20:21', '2008-09-12 00:20:21', '', 'Job Opportunities', '', 'inherit', 'open', 'open', '', '32-revision', '', '', '2008-09-11 19:20:21', '2008-09-12 00:20:21', '', 17, 'http://dev.danphilibin.com/wordpress/?p=33', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (17, 1, '2008-09-11 19:20:29', '2008-09-12 00:20:29', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nam vel turpis. Duis sit amet lectus ac mauris porta viverra. Aliquam erat volutpat. Praesent ipsum pede, pretium sed, congue nec, pretium quis, urna. Suspendisse dignissim, elit in ultrices sollicitudin, nisl est accumsan orci, a venenatis dui mi porta pede. Aenean et pede quis est tincidunt varius.

Cras aliquet. Integer faucibus, eros ac molestie placerat, enim tellus varius lacus, nec dictum nunc tortor id urna. Suspendisse dapibus ullamcorper pede. Vivamus ligula ipsum, faucibus at, tincidunt eget, porttitor non, dolor. Ut dui lectus, ultrices ut, sodales tincidunt, viverra sed, nisl.

Praesent ac quam vulputate felis ultrices scelerisque. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. In in arcu. Vestibulum eget nisi quis tellus elementum dapibus. Cras facilisis venenatis libero. Nunc accumsan viverra augue. Suspendisse potenti. Suspendisse eleifend. Maecenas sit amet justo.

Quisque quam nisi, mollis quis, sodales ut, rhoncus nec, risus. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Proin pede. Aliquam neque tortor, euismod ac, eleifend quis, tincidunt quis, neque.

Phasellus rhoncus. Donec urna nulla, vehicula et, consectetuer vel, condimentum quis, ipsum. Nulla quis neque eu sapien tincidunt faucibus. Donec eleifend, metus sed elementum lobortis, arcu elit luctus enim, sed vestibulum diam leo nec nunc. Suspendisse tempus.

Phasellus quis mauris. Integer eu justo. Fusce tortor enim, elementum ut, auctor non, accumsan quis, enim. Aenean posuere ante id odio. Nulla facilisi. Donec ac eros quis ipsum auctor blandit. Cras eleifend libero fringilla turpis. Integer sem. Curabitur commodo dapibus lacus.

Vivamus semper auctor turpis. Sed ipsum lacus, varius quis, iaculis at, mollis sagittis, arcu.', 'Our Staff', '', 'publish', 'open', 'open', '', 'our-staff', '', '', '2008-09-11 19:20:29', '2008-09-12 00:20:29', '', 28, 'http://dev.danphilibin.com/wordpress/?page_id=32', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (18, 1, '2008-09-11 19:20:39', '2008-09-12 00:20:39', '', 'Company History', '', 'inherit', 'open', 'open', '', '34-revision', '', '', '2008-09-11 19:20:39', '2008-09-12 00:20:39', '', 20, 'http://dev.danphilibin.com/wordpress/?p=35', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (19, 1, '2008-09-11 19:20:42', '2008-09-12 00:20:42', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nam vel turpis. Duis sit amet lectus ac mauris porta viverra. Aliquam erat volutpat. Praesent ipsum pede, pretium sed, congue nec, pretium quis, urna. Suspendisse dignissim, elit in ultrices sollicitudin, nisl est accumsan orci, a venenatis dui mi porta pede. Aenean et pede quis est tincidunt varius.

Cras aliquet. Integer faucibus, eros ac molestie placerat, enim tellus varius lacus, nec dictum nunc tortor id urna. Suspendisse dapibus ullamcorper pede. Vivamus ligula ipsum, faucibus at, tincidunt eget, porttitor non, dolor. Ut dui lectus, ultrices ut, sodales tincidunt, viverra sed, nisl.

Praesent ac quam vulputate felis ultrices scelerisque. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. In in arcu. Vestibulum eget nisi quis tellus elementum dapibus. Cras facilisis venenatis libero. Nunc accumsan viverra augue. Suspendisse potenti. Suspendisse eleifend. Maecenas sit amet justo.

Quisque quam nisi, mollis quis, sodales ut, rhoncus nec, risus. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Proin pede. Aliquam neque tortor, euismod ac, eleifend quis, tincidunt quis, neque.

Phasellus rhoncus. Donec urna nulla, vehicula et, consectetuer vel, condimentum quis, ipsum. Nulla quis neque eu sapien tincidunt faucibus. Donec eleifend, metus sed elementum lobortis, arcu elit luctus enim, sed vestibulum diam leo nec nunc. Suspendisse tempus.

Phasellus quis mauris. Integer eu justo. Fusce tortor enim, elementum ut, auctor non, accumsan quis, enim. Aenean posuere ante id odio. Nulla facilisi. Donec ac eros quis ipsum auctor blandit. Cras eleifend libero fringilla turpis. Integer sem. Curabitur commodo dapibus lacus.

Vivamus semper auctor turpis. Sed ipsum lacus, varius quis, iaculis at, mollis sagittis, arcu.', 'Company History', '', 'inherit', 'open', 'open', '', '34-revision-2', '', '', '2008-09-11 19:20:42', '2008-09-12 00:20:42', '', 20, 'http://dev.danphilibin.com/wordpress/?p=38', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (20, 1, '2008-09-11 19:20:42', '2008-09-12 00:20:42', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nam vel turpis. Duis sit amet lectus ac mauris porta viverra. Aliquam erat volutpat. Praesent ipsum pede, pretium sed, congue nec, pretium quis, urna. Suspendisse dignissim, elit in ultrices sollicitudin, nisl est accumsan orci, a venenatis dui mi porta pede. Aenean et pede quis est tincidunt varius.

Cras aliquet. Integer faucibus, eros ac molestie placerat, enim tellus varius lacus, nec dictum nunc tortor id urna. Suspendisse dapibus ullamcorper pede. Vivamus ligula ipsum, faucibus at, tincidunt eget, porttitor non, dolor. Ut dui lectus, ultrices ut, sodales tincidunt, viverra sed, nisl.

Praesent ac quam vulputate felis ultrices scelerisque. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. In in arcu. Vestibulum eget nisi quis tellus elementum dapibus. Cras facilisis venenatis libero. Nunc accumsan viverra augue. Suspendisse potenti. Suspendisse eleifend. Maecenas sit amet justo.

Quisque quam nisi, mollis quis, sodales ut, rhoncus nec, risus. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Proin pede. Aliquam neque tortor, euismod ac, eleifend quis, tincidunt quis, neque.

Phasellus rhoncus. Donec urna nulla, vehicula et, consectetuer vel, condimentum quis, ipsum. Nulla quis neque eu sapien tincidunt faucibus. Donec eleifend, metus sed elementum lobortis, arcu elit luctus enim, sed vestibulum diam leo nec nunc. Suspendisse tempus.

Phasellus quis mauris. Integer eu justo. Fusce tortor enim, elementum ut, auctor non, accumsan quis, enim. Aenean posuere ante id odio. Nulla facilisi. Donec ac eros quis ipsum auctor blandit. Cras eleifend libero fringilla turpis. Integer sem. Curabitur commodo dapibus lacus.

Vivamus semper auctor turpis. Sed ipsum lacus, varius quis, iaculis at, mollis sagittis, arcu.', 'History', '', 'publish', 'open', 'open', '', 'company-history', '', '', '2013-04-25 10:03:36', '2013-04-25 16:03:36', '', 28, 'http://dev.danphilibin.com/wordpress/?page_id=34', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (21, 1, '2008-09-11 19:20:49', '2008-09-12 00:20:49', '', 'Support', '', 'inherit', 'open', 'open', '', '36-revision', '', '', '2008-09-11 19:20:49', '2008-09-12 00:20:49', '', 22, 'http://dev.danphilibin.com/wordpress/?p=37', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (22, 1, '2008-09-11 19:20:52', '2008-09-12 00:20:52', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nam vel turpis. Duis sit amet lectus ac mauris porta viverra. Aliquam erat volutpat. Praesent ipsum pede, pretium sed, congue nec, pretium quis, urna. Suspendisse dignissim, elit in ultrices sollicitudin, nisl est accumsan orci, a venenatis dui mi porta pede. Aenean et pede quis est tincidunt varius.

Cras aliquet. Integer faucibus, eros ac molestie placerat, enim tellus varius lacus, nec dictum nunc tortor id urna. Suspendisse dapibus ullamcorper pede. Vivamus ligula ipsum, faucibus at, tincidunt eget, porttitor non, dolor. Ut dui lectus, ultrices ut, sodales tincidunt, viverra sed, nisl.

Praesent ac quam vulputate felis ultrices scelerisque. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. In in arcu. Vestibulum eget nisi quis tellus elementum dapibus. Cras facilisis venenatis libero. Nunc accumsan viverra augue. Suspendisse potenti. Suspendisse eleifend. Maecenas sit amet justo.

Quisque quam nisi, mollis quis, sodales ut, rhoncus nec, risus. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Proin pede. Aliquam neque tortor, euismod ac, eleifend quis, tincidunt quis, neque.

Phasellus rhoncus. Donec urna nulla, vehicula et, consectetuer vel, condimentum quis, ipsum. Nulla quis neque eu sapien tincidunt faucibus. Donec eleifend, metus sed elementum lobortis, arcu elit luctus enim, sed vestibulum diam leo nec nunc. Suspendisse tempus.

Phasellus quis mauris. Integer eu justo. Fusce tortor enim, elementum ut, auctor non, accumsan quis, enim. Aenean posuere ante id odio. Nulla facilisi. Donec ac eros quis ipsum auctor blandit. Cras eleifend libero fringilla turpis. Integer sem. Curabitur commodo dapibus lacus.

Vivamus semper auctor turpis. Sed ipsum lacus, varius quis, iaculis at, mollis sagittis, arcu.', 'Support', '', 'publish', 'open', 'open', '', 'support', '', '', '2013-04-25 10:03:37', '2013-04-25 16:03:37', '', 0, 'http://dev.danphilibin.com/wordpress/?page_id=36', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (23, 1, '2008-09-11 19:22:00', '2008-09-12 00:22:00', '', 'Links', '', 'inherit', 'open', 'open', '', '39-revision', '', '', '2008-09-11 19:22:00', '2008-09-12 00:22:00', '', 24, 'http://dev.danphilibin.com/wordpress/?p=40', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (24, 1, '2008-09-11 19:22:03', '2008-09-12 00:22:03', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nam vel turpis. Duis sit amet lectus ac mauris porta viverra. Aliquam erat volutpat. Praesent ipsum pede, pretium sed, congue nec, pretium quis, urna. Suspendisse dignissim, elit in ultrices sollicitudin, nisl est accumsan orci, a venenatis dui mi porta pede. Aenean et pede quis est tincidunt varius.

Cras aliquet. Integer faucibus, eros ac molestie placerat, enim tellus varius lacus, nec dictum nunc tortor id urna. Suspendisse dapibus ullamcorper pede. Vivamus ligula ipsum, faucibus at, tincidunt eget, porttitor non, dolor. Ut dui lectus, ultrices ut, sodales tincidunt, viverra sed, nisl.

Praesent ac quam vulputate felis ultrices scelerisque. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. In in arcu. Vestibulum eget nisi quis tellus elementum dapibus. Cras facilisis venenatis libero. Nunc accumsan viverra augue. Suspendisse potenti. Suspendisse eleifend. Maecenas sit amet justo.

Quisque quam nisi, mollis quis, sodales ut, rhoncus nec, risus. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Proin pede. Aliquam neque tortor, euismod ac, eleifend quis, tincidunt quis, neque.

Phasellus rhoncus. Donec urna nulla, vehicula et, consectetuer vel, condimentum quis, ipsum. Nulla quis neque eu sapien tincidunt faucibus. Donec eleifend, metus sed elementum lobortis, arcu elit luctus enim, sed vestibulum diam leo nec nunc. Suspendisse tempus.

Phasellus quis mauris. Integer eu justo. Fusce tortor enim, elementum ut, auctor non, accumsan quis, enim. Aenean posuere ante id odio. Nulla facilisi. Donec ac eros quis ipsum auctor blandit. Cras eleifend libero fringilla turpis. Integer sem. Curabitur commodo dapibus lacus.

Vivamus semper auctor turpis. Sed ipsum lacus, varius quis, iaculis at, mollis sagittis, arcu.', 'Links', '', 'publish', 'open', 'open', '', 'links', '', '', '2008-09-11 19:22:03', '2008-09-12 00:22:03', '', 0, 'http://dev.danphilibin.com/wordpress/?page_id=39', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (25, 1, '2008-09-11 19:22:17', '2008-09-12 00:22:17', '', 'Contact Us', '', 'inherit', 'open', 'open', '', '41-revision', '', '', '2008-09-11 19:22:17', '2008-09-12 00:22:17', '', 26, 'http://dev.danphilibin.com/wordpress/?p=42', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (26, 1, '2008-09-11 19:22:18', '2008-09-12 00:22:18', '', 'Contact Us', '', 'publish', 'open', 'open', '', 'contact-us', '', '', '2008-09-11 19:22:18', '2008-09-12 00:22:18', '', 0, 'http://dev.danphilibin.com/wordpress/?page_id=41', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (27, 1, '2008-09-11 19:23:57', '2008-09-12 00:23:57', '', 'News', '', 'inherit', 'open', 'open', '', '43-revision', '', '', '2008-09-11 19:23:57', '2008-09-12 00:23:57', '', 28, 'http://dev.danphilibin.com/wordpress/?p=44', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (28, 1, '2008-09-11 19:24:01', '2008-09-12 00:24:01', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nam vel turpis. Duis sit amet lectus ac mauris porta viverra. Aliquam erat volutpat. Praesent ipsum pede, pretium sed, congue nec, pretium quis, urna. Suspendisse dignissim, elit in ultrices sollicitudin, nisl est accumsan orci, a venenatis dui mi porta pede. Aenean et pede quis est tincidunt varius.

Cras aliquet. Integer faucibus, eros ac molestie placerat, enim tellus varius lacus, nec dictum nunc tortor id urna. Suspendisse dapibus ullamcorper pede. Vivamus ligula ipsum, faucibus at, tincidunt eget, porttitor non, dolor. Ut dui lectus, ultrices ut, sodales tincidunt, viverra sed, nisl.

Praesent ac quam vulputate felis ultrices scelerisque. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. In in arcu. Vestibulum eget nisi quis tellus elementum dapibus. Cras facilisis venenatis libero. Nunc accumsan viverra augue. Suspendisse potenti. Suspendisse eleifend. Maecenas sit amet justo.

Quisque quam nisi, mollis quis, sodales ut, rhoncus nec, risus. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Proin pede. Aliquam neque tortor, euismod ac, eleifend quis, tincidunt quis, neque.

Phasellus rhoncus. Donec urna nulla, vehicula et, consectetuer vel, condimentum quis, ipsum. Nulla quis neque eu sapien tincidunt faucibus. Donec eleifend, metus sed elementum lobortis, arcu elit luctus enim, sed vestibulum diam leo nec nunc. Suspendisse tempus.

Phasellus quis mauris. Integer eu justo. Fusce tortor enim, elementum ut, auctor non, accumsan quis, enim. Aenean posuere ante id odio. Nulla facilisi. Donec ac eros quis ipsum auctor blandit. Cras eleifend libero fringilla turpis. Integer sem. Curabitur commodo dapibus lacus.

Vivamus semper auctor turpis. Sed ipsum lacus, varius quis, iaculis at, mollis sagittis, arcu.', 'News', '', 'publish', 'open', 'open', '', 'news', '', '', '2008-09-11 19:24:01', '2008-09-12 00:24:01', '', 0, 'http://dev.danphilibin.com/wordpress/?page_id=43', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (29, 1, '2008-09-11 19:24:20', '2008-09-12 00:24:20', '', 'Our Location', '', 'inherit', 'open', 'open', '', '45-revision', '', '', '2008-09-11 19:24:20', '2008-09-12 00:24:20', '', 30, 'http://dev.danphilibin.com/wordpress/?p=46', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (30, 1, '2008-09-11 19:24:31', '2008-09-12 00:24:31', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nam vel turpis. Duis sit amet lectus ac mauris porta viverra. Aliquam erat volutpat. Praesent ipsum pede, pretium sed, congue nec, pretium quis, urna. Suspendisse dignissim, elit in ultrices sollicitudin, nisl est accumsan orci, a venenatis dui mi porta pede. Aenean et pede quis est tincidunt varius.

Cras aliquet. Integer faucibus, eros ac molestie placerat, enim tellus varius lacus, nec dictum nunc tortor id urna. Suspendisse dapibus ullamcorper pede. Vivamus ligula ipsum, faucibus at, tincidunt eget, porttitor non, dolor. Ut dui lectus, ultrices ut, sodales tincidunt, viverra sed, nisl.', 'Our Location', '', 'publish', 'open', 'open', '', 'our-location', '', '', '2008-09-11 19:24:31', '2008-09-12 00:24:31', '', 26, 'http://dev.danphilibin.com/wordpress/?page_id=45', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (31, 1, '2008-09-11 19:24:52', '2008-09-12 00:24:52', '', 'Employment Opportunities', '', 'inherit', 'open', 'open', '', '47-revision', '', '', '2008-09-11 19:24:52', '2008-09-12 00:24:52', '', 32, 'http://dev.danphilibin.com/wordpress/?p=48', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (32, 1, '2008-09-11 19:24:58', '2008-09-12 00:24:58', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nam vel turpis. Duis sit amet lectus ac mauris porta viverra. Aliquam erat volutpat. Praesent ipsum pede, pretium sed, congue nec, pretium quis, urna. Suspendisse dignissim, elit in ultrices sollicitudin, nisl est accumsan orci, a venenatis dui mi porta pede. Aenean et pede quis est tincidunt varius.

Cras aliquet. Integer faucibus, eros ac molestie placerat, enim tellus varius lacus, nec dictum nunc tortor id urna. Suspendisse dapibus ullamcorper pede. Vivamus ligula ipsum, faucibus at, tincidunt eget, porttitor non, dolor. Ut dui lectus, ultrices ut, sodales tincidunt, viverra sed, nisl.

Praesent ac quam vulputate felis ultrices scelerisque. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. In in arcu. Vestibulum eget nisi quis tellus elementum dapibus. Cras facilisis venenatis libero. Nunc accumsan viverra augue. Suspendisse potenti. Suspendisse eleifend. Maecenas sit amet justo.

Quisque quam nisi, mollis quis, sodales ut, rhoncus nec, risus. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Proin pede. Aliquam neque tortor, euismod ac, eleifend quis, tincidunt quis, neque.

Phasellus rhoncus. Donec urna nulla, vehicula et, consectetuer vel, condimentum quis, ipsum. Nulla quis neque eu sapien tincidunt faucibus. Donec eleifend, metus sed elementum lobortis, arcu elit luctus enim, sed vestibulum diam leo nec nunc. Suspendisse tempus.

Phasellus quis mauris. Integer eu justo. Fusce tortor enim, elementum ut, auctor non, accumsan quis, enim. Aenean posuere ante id odio. Nulla facilisi. Donec ac eros quis ipsum auctor blandit. Cras eleifend libero fringilla turpis. Integer sem. Curabitur commodo dapibus lacus.

Vivamus semper auctor turpis. Sed ipsum lacus, varius quis, iaculis at, mollis sagittis, arcu.', 'Employment Opportunities', '', 'publish', 'open', 'open', '', 'employment-opportunities', '', '', '2013-04-25 10:03:36', '2013-04-25 16:03:36', '', 17, 'http://dev.danphilibin.com/wordpress/?page_id=47', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (33, 1, '2008-09-11 22:13:41', '2008-09-12 03:13:41', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur quam augue, vehicula quis, tincidunt vel, varius vitae, nulla. Sed convallis orci. Duis libero orci, pretium a, <a href="#">convallis quis</a>, pellentesque a, dolor. Curabitur vitae nisi non dolor vestibulum consequat.

<ul>
<li>Vestibulum in mauris semper tortor interdum ultrices.</li>
<li>Sed vel lorem et justo laoreet bibendum. Donec dictum.</li>
<li>Etiam massa libero, lacinia at, commodo in, tincidunt a, purus.</li>
<li>Praesent volutpat eros quis enim blandit tincidunt.</li>
<li>Aenean eu libero nec lectus ultricies laoreet. Donec rutrum, nisi vel egestas ultrices, ipsum urna sagittis libero, vitae vestibulum dui dolor vel velit.</li>
</ul>', 'A Post With an Unordered List', '', 'inherit', 'open', 'open', '', '50-revision', '', '', '2008-09-11 22:13:41', '2008-09-12 03:13:41', '', 34, 'http://dev.danphilibin.com/wordpress/?p=51', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (34, 1, '2008-09-11 22:14:00', '2008-09-12 03:14:00', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur quam augue, vehicula quis, tincidunt vel, varius vitae, nulla. Sed convallis orci. Duis libero orci, pretium a, <a href="#">convallis quis</a>, pellentesque a, dolor. Curabitur vitae nisi non dolor vestibulum consequat.

<ul>
<li>Vestibulum in mauris semper tortor interdum ultrices.</li>
<li>Sed vel lorem et justo laoreet bibendum. Donec dictum.</li>
<li>Etiam massa libero, lacinia at, commodo in, tincidunt a, purus.</li>
<li>Praesent volutpat eros quis enim blandit tincidunt.</li>
<li>Aenean eu libero nec lectus ultricies laoreet. Donec rutrum, nisi vel egestas ultrices, ipsum urna sagittis libero, vitae vestibulum dui dolor vel velit.</li>
</ul>', 'A Post With an Unordered List', '', 'publish', 'open', 'open', '', 'a-post-with-an-unordered-list', '', '', '2008-09-11 22:14:00', '2008-09-12 03:14:00', '', 0, 'http://dev.danphilibin.com/wordpress/?p=50', 0, 'post', '', 2) ; 
INSERT INTO `wp_posts` VALUES (35, 1, '2008-09-11 22:14:45', '2008-09-12 03:14:45', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Sed eleifend urna eu sapien. Quisque posuere nunc eu massa. Praesent bibendum lorem non leo. Morbi volutpat, urna eu fermentum rutrum, ligula lacus interdum mauris, ac pulvinar libero pede a enim. Etiam commodo malesuada ante. Donec nec ligula. Curabitur mollis semper diam. <!--more-->

Duis viverra nibh a felis condimentum pretium. Nullam tristique lacus non purus. Donec vel felis. Etiam et sapien. Pellentesque nec quam a justo tincidunt laoreet. Aenean id enim. Donec lorem arcu, eleifend venenatis, rhoncus mollis, semper at, dui. Praesent velit tellus, adipiscing et, blandit convallis, dictum at, dui. Integer suscipit tortor in orci. Phasellus consequat. Quisque dictum convallis pede.

Mauris viverra scelerisque mauris. Nulla facilisis, elit malesuada pretium egestas, dolor arcu commodo est, at egestas massa tortor ut ante. Etiam eget libero. Aenean pretium, tellus sed sodales semper, turpis purus aliquet orci, pulvinar ornare odio tortor sit amet dui.

Aenean id orci. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus magna. Mauris tincidunt iaculis enim. Duis a mi vitae sapien dapibus tincidunt. Proin metus.

Proin cursus, libero non auctor faucibus, urna mi vestibulum orci, sit amet fermentum nibh purus eget enim. Aenean aliquet ligula nec nulla. Praesent sit amet lorem vitae massa hendrerit auctor. Sed sit amet urna. Aenean sapien nunc, imperdiet a, pharetra in, consequat eu, neque. Phasellus vel sem gravida augue consequat tempor. Curabitur eget mauris at pede varius facilisis.

Morbi ut sapien. Morbi arcu mauris, suscipit congue, placerat sit amet, suscipit a, ante. Donec aliquet dui ac nunc. Mauris magna quam, aliquet quis, viverra eu, fringilla eget, purus. Donec tristique pretium sem.', 'A Simple Post with Text', '', 'inherit', 'open', 'open', '', '22-revision-3', '', '', '2008-09-11 22:14:45', '2008-09-12 03:14:45', '', 7, 'http://dev.danphilibin.com/wordpress/?p=65', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (36, 1, '2008-09-11 22:15:57', '2008-09-12 03:15:57', '', 'A Post With a Right-Aligned Image', '', 'inherit', 'open', 'open', '', '53-revision', '', '', '2008-09-11 22:15:57', '2008-09-12 03:15:57', '', 37, 'http://dev.danphilibin.com/wordpress/?p=54', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (37, 1, '2008-09-11 22:19:25', '2008-09-12 03:19:25', '<img src="http://i35.tinypic.com/990wtx.png" alt="WordPress Logo" align="right" class="alignright" />Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur quam augue, vehicula quis, tincidunt vel, varius vitae, nulla. Sed convallis orci. Duis libero orci, pretium a, <a href="#">convallis quis</a>, pellentesque a, dolor. Curabitur vitae nisi non dolor vestibulum consequat.  <!--more-->

Nulla sagittis convallis arcu. Sed sed nunc. Curabitur consequat. Quisque metus enim, venenatis fermentum, mollis in, porta et, nibh. Duis vulputate elit in elit. Mauris dictum libero id justo. Fusce in est. Sed nec diam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Quisque semper nibh eget nibh. Sed tempor. Fusce erat.', 'A Post With a Right-Aligned Image', '', 'publish', 'open', 'open', '', 'a-post-with-a-right-aligned-image', '', '', '2008-09-11 22:19:25', '2008-09-12 03:19:25', '', 0, 'http://dev.danphilibin.com/wordpress/?p=53', 0, 'post', '', 1) ; 
INSERT INTO `wp_posts` VALUES (38, 1, '2008-09-11 22:19:48', '2008-09-12 03:19:48', '', 'A Post With an Ordered List', '', 'inherit', 'open', 'open', '', '55-revision', '', '', '2008-09-11 22:19:48', '2008-09-12 03:19:48', '', 39, 'http://dev.danphilibin.com/wordpress/?p=56', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (39, 1, '2008-09-11 22:20:17', '2008-09-12 03:20:17', 'Nulla sagittis convallis arcu. Sed sed nunc. Curabitur consequat. Quisque metus enim, venenatis fermentum, mollis in, porta et, nibh. Duis vulputate elit in elit. Mauris dictum libero id justo. Fusce in est. Sed nec diam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Quisque semper nibh eget nibh. Sed tempor. Fusce erat.

<h3>An Ordered List</h3>

<ol>
<li>Vestibulum in mauris semper tortor interdum ultrices.</li>
<li>Sed vel lorem et justo laoreet bibendum. Donec dictum.</li>
<li>Etiam massa libero, lacinia at, commodo in, tincidunt a, purus.</li>
<li>Praesent volutpat eros quis enim blandit tincidunt.</li>
<li>Aenean eu libero nec lectus ultricies laoreet. Donec rutrum, nisi vel egestas ultrices, ipsum urna sagittis libero, vitae vestibulum dui dolor vel velit.</li>
</ol>', 'A Post With an Ordered List', '', 'publish', 'open', 'open', '', 'a-post-with-an-ordered-list', '', '', '2008-09-11 22:20:17', '2008-09-12 03:20:17', '', 0, 'http://dev.danphilibin.com/wordpress/?p=55', 0, 'post', '', 2) ; 
INSERT INTO `wp_posts` VALUES (40, 1, '2008-09-11 22:20:32', '2008-09-12 03:20:32', '', 'Another Text-Only Post', '', 'inherit', 'open', 'open', '', '57-revision', '', '', '2008-09-11 22:20:32', '2008-09-12 03:20:32', '', 41, 'http://dev.danphilibin.com/wordpress/?p=58', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (41, 1, '2008-09-11 22:20:39', '2008-09-12 03:20:39', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Sed eleifend urna eu sapien. Quisque posuere nunc eu massa. Praesent bibendum lorem non leo. Morbi volutpat, urna eu fermentum rutrum, ligula lacus interdum mauris, ac pulvinar libero pede a enim. Etiam commodo malesuada ante. Donec nec ligula. Curabitur mollis semper diam. <!--more-->

Duis viverra nibh a felis condimentum pretium. Nullam tristique lacus non purus. Donec vel felis. Etiam et sapien. Pellentesque nec quam a justo tincidunt laoreet. Aenean id enim. Donec lorem arcu, eleifend venenatis, rhoncus mollis, semper at, dui. Praesent velit tellus, adipiscing et, blandit convallis, dictum at, dui. Integer suscipit tortor in orci. Phasellus consequat. Quisque dictum convallis pede.

Mauris viverra scelerisque mauris. Nulla facilisis, elit malesuada pretium egestas, dolor arcu commodo est, at egestas massa tortor ut ante. Etiam eget libero. Aenean pretium, tellus sed sodales semper, turpis purus aliquet orci, pulvinar ornare odio tortor sit amet dui.

Aenean id orci. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus magna. Mauris tincidunt iaculis enim. Duis a mi vitae sapien dapibus tincidunt. Proin metus.

Proin cursus, libero non auctor faucibus, urna mi vestibulum orci, sit amet fermentum nibh purus eget enim. Aenean aliquet ligula nec nulla. Praesent sit amet lorem vitae massa hendrerit auctor. Sed sit amet urna. Aenean sapien nunc, imperdiet a, pharetra in, consequat eu, neque. Phasellus vel sem gravida augue consequat tempor. Curabitur eget mauris at pede varius facilisis.

Morbi ut sapien. Morbi arcu mauris, suscipit congue, placerat sit amet, suscipit a, ante. Donec aliquet dui ac nunc. Mauris magna quam, aliquet quis, viverra eu, fringilla eget, purus. Donec tristique pretium sem.', 'Another Text-Only Post', '', 'publish', 'open', 'open', '', 'another-text-only-post', '', '', '2008-09-11 22:20:39', '2008-09-12 03:20:39', '', 0, 'http://dev.danphilibin.com/wordpress/?p=57', 0, 'post', '', 1) ; 
INSERT INTO `wp_posts` VALUES (42, 1, '2008-09-11 22:22:54', '2008-09-12 03:22:54', '<img src="http://i35.tinypic.com/990wtx.png" alt="WordPress Logo" align="left" class="alignleft" />Nulla sagittis convallis arcu. Sed sed nunc. Curabitur consequat. Quisque metus enim, venenatis fermentum, mollis in, porta et, nibh. Duis vulputate elit in elit. Mauris dictum libero id justo. Fusce in est. Sed nec diam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Quisque semper nibh eget nibh. Sed tempor. Fusce erat.', 'A Post With a Left-Aligned Image', '', 'inherit', 'open', 'open', '', '59-revision', '', '', '2008-09-11 22:22:54', '2008-09-12 03:22:54', '', 43, 'http://dev.danphilibin.com/wordpress/?p=60', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (43, 1, '2008-09-11 22:23:11', '2008-09-12 03:23:11', '<img src="http://i35.tinypic.com/990wtx.png" alt="WordPress Logo" align="left" class="alignleft" />Nulla sagittis convallis arcu. Sed sed nunc. Curabitur consequat. Quisque metus enim, venenatis fermentum, mollis in, porta et, nibh. Duis vulputate elit in elit. Mauris dictum libero id justo. Fusce in est. Sed nec diam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Quisque semper nibh eget nibh. Sed tempor. Fusce erat.', 'A Post With a Left-Aligned Image', '', 'publish', 'open', 'open', '', 'a-post-with-a-left-aligned-image', '', '', '2008-09-11 22:23:11', '2008-09-12 03:23:11', '', 0, 'http://dev.danphilibin.com/wordpress/?p=59', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (44, 1, '2008-09-11 22:23:36', '2008-09-12 03:23:36', '', 'Quotes Time!', '', 'inherit', 'open', 'open', '', '61-revision', '', '', '2008-09-11 22:23:36', '2008-09-12 03:23:36', '', 45, 'http://dev.danphilibin.com/wordpress/?p=62', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (45, 1, '2008-09-11 22:24:01', '2008-09-12 03:24:01', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur quam augue, vehicula quis, tincidunt vel, varius vitae, nulla. Sed convallis orci. Duis libero orci, pretium a, <a href="#">convallis quis</a>, pellentesque a, dolor. Curabitur vitae nisi non dolor vestibulum consequat.

<blockquote>Proin vestibulum. Ut ligula. Nullam sed dolor id odio volutpat pulvinar. Integer a leo. In et eros at neque pretium sagittis. Sed sodales lorem a ipsum suscipit gravida. Ut fringilla placerat arcu. Phasellus imperdiet. Mauris ac justo et turpis pharetra vulputate.</blockquote>
<cite><a href="#">Quote Source</a></cite>

<blockquote>Proin vestibulum. Ut ligula. Nullam sed dolor id odio volutpat pulvinar. Integer a leo. In et eros at neque pretium sagittis. Sed sodales lorem a ipsum suscipit gravida. Ut fringilla placerat arcu. Phasellus imperdiet. Mauris ac justo et turpis pharetra vulputate.</blockquote>
<cite><a href="#">Quote Source</a></cite>', 'Quotes Time!', '', 'publish', 'open', 'open', '', 'quotes-time', '', '', '2008-09-11 22:24:01', '2008-09-12 03:24:01', '', 0, 'http://dev.danphilibin.com/wordpress/?p=61', 0, 'post', '', 1) ; 
INSERT INTO `wp_posts` VALUES (46, 1, '2008-09-11 22:25:19', '2008-09-12 03:25:19', '<img src="http://i35.tinypic.com/990wtx.png" alt="WordPress Logo" align="right" class="alignright" />Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur quam augue, vehicula quis, tincidunt vel, varius vitae, nulla. Sed convallis orci. Duis libero orci, pretium a, <a href="#">convallis quis</a>, pellentesque a, dolor. Curabitur vitae nisi non dolor vestibulum consequat.

<blockquote>Proin vestibulum. Ut ligula. Nullam sed dolor id odio volutpat pulvinar. Integer a leo. In et eros at neque pretium sagittis. Sed sodales lorem a ipsum suscipit gravida. Ut fringilla placerat arcu. Phasellus imperdiet. Mauris ac justo et turpis pharetra vulputate.</blockquote>
<cite><a href="#">Quote Source</a></cite>

<h1>Level 1 Heading</h1>
<h2>Level 2 Heading</h2>
<h3>Level 3 Heading</h3>
<h4>Level 4 Heading</h4>
<h5>Level 5 Heading</h5>
<h6>Level 6 Heading</h6>

<h3>An Unordered List</h3>

<ul>
<li>Vestibulum in mauris semper tortor interdum ultrices.</li>
<li>Sed vel lorem et justo laoreet bibendum. Donec dictum.</li>
<li>Etiam massa libero, lacinia at, commodo in, tincidunt a, purus.</li>
<li>Praesent volutpat eros quis enim blandit tincidunt.</li>
<li>Aenean eu libero nec lectus ultricies laoreet. Donec rutrum, nisi vel egestas ultrices, ipsum urna sagittis libero, vitae vestibulum dui dolor vel velit.</li>
</ul>

<img src="http://i35.tinypic.com/990wtx.png" alt="WordPress Logo" align="left" class="alignleft" />Nulla sagittis convallis arcu. Sed sed nunc. Curabitur consequat. Quisque metus enim, venenatis fermentum, mollis in, porta et, nibh. Duis vulputate elit in elit. Mauris dictum libero id justo. Fusce in est. Sed nec diam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Quisque semper nibh eget nibh. Sed tempor. Fusce erat.

<h3>An Ordered List</h3>

<ol>
<li>Vestibulum in mauris semper tortor interdum ultrices.</li>
<li>Sed vel lorem et justo laoreet bibendum. Donec dictum.</li>
<li>Etiam massa libero, lacinia at, commodo in, tincidunt a, purus.</li>
<li>Praesent volutpat eros quis enim blandit tincidunt.</li>
<li>Aenean eu libero nec lectus ultricies laoreet. Donec rutrum, nisi vel egestas ultrices, ipsum urna sagittis libero, vitae vestibulum dui dolor vel velit.</li>
</ol>', 'A Post With Everything In It', '', 'inherit', 'open', 'open', '', '63-revision', '', '', '2008-09-11 22:25:19', '2008-09-12 03:25:19', '', 47, 'http://dev.danphilibin.com/wordpress/?p=64', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (47, 1, '2008-09-11 22:25:45', '2008-09-12 03:25:45', '<img class="alignright" src="http://i35.tinypic.com/990wtx.png" alt="WordPress Logo" align="right" />Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur quam augue, vehicula quis, tincidunt vel, varius vitae, nulla. Sed convallis orci. Duis libero orci, pretium a, <a href="#">convallis quis</a>, pellentesque a, dolor. Curabitur vitae nisi non dolor vestibulum consequat. <!--more-->

<blockquote>Proin vestibulum. Ut ligula. Nullam sed dolor id odio volutpat pulvinar. Integer a leo. In et eros at neque pretium sagittis. Sed sodales lorem a ipsum suscipit gravida. Ut fringilla placerat arcu. Phasellus imperdiet. Mauris ac justo et turpis pharetra vulputate.</blockquote>
<cite><a href="#">Quote Source</a></cite>
<h1>Level 1 Heading</h1>
<h2>Level 2 Heading</h2>
<h3>Level 3 Heading</h3>
<h4>Level 4 Heading</h4>
<h5>Level 5 Heading</h5>
<h6>Level 6 Heading</h6>
<h3>An Unordered List</h3>
<ul>
	<li>Vestibulum in mauris semper tortor interdum ultrices.</li>
	<li>Sed vel lorem et justo laoreet bibendum. Donec dictum.</li>
	<li>Etiam massa libero, lacinia at, commodo in, tincidunt a, purus.</li>
	<li>Praesent volutpat eros quis enim blandit tincidunt.</li>
	<li>Aenean eu libero nec lectus ultricies laoreet. Donec rutrum, nisi vel egestas ultrices, ipsum urna sagittis libero, vitae vestibulum dui dolor vel velit.</li>
</ul>
<h3>Image with no alignment</h3>
<img src="http://i35.tinypic.com/990wtx.png" alt="WordPress Logo" />

<img class="alignleft" src="http://i35.tinypic.com/990wtx.png" alt="WordPress Logo" align="left" />Nulla sagittis convallis arcu. Sed sed nunc. Curabitur consequat. Quisque metus enim, venenatis fermentum, mollis in, porta et, nibh. Duis vulputate elit in elit. Mauris dictum libero id justo. Fusce in est. Sed nec diam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Quisque semper nibh eget nibh. Sed tempor. Fusce erat.
<h3>An Ordered List</h3>
<ol>
	<li>Vestibulum in mauris semper tortor interdum ultrices.</li>
	<li>Sed vel lorem et justo laoreet bibendum. Donec dictum.</li>
	<li>Etiam massa libero, lacinia at, commodo in, tincidunt a, purus.</li>
	<li>Praesent volutpat eros quis enim blandit tincidunt.</li>
	<li>Aenean eu libero nec lectus ultricies laoreet. Donec rutrum, nisi vel egestas ultrices, ipsum urna sagittis libero, vitae vestibulum dui dolor vel velit.</li>
</ol>', 'A Post With Everything In It', '', 'publish', 'open', 'open', '', 'a-post-with-everything-in-it', '', '', '2008-09-11 22:25:45', '2008-09-12 03:25:45', '', 0, 'http://dev.danphilibin.com/wordpress/?p=63', 0, 'post', '', 2) ; 
INSERT INTO `wp_posts` VALUES (48, 1, '2008-09-17 17:09:14', '2008-09-17 22:09:14', 'Nulla sagittis convallis arcu. Sed sed nunc. Curabitur consequat. Quisque metus enim, venenatis fermentum, mollis in, porta et, nibh. Duis vulputate elit in elit. Mauris dictum libero id justo. Fusce in est. Sed nec diam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Quisque semper nibh eget nibh. Sed tempor. Fusce erat.
<h3>An Ordered List</h3>
<ol>
	<li>Vestibulum in mauris semper tortor interdum ultrices.</li>
	<li>Sed vel lorem et justo laoreet bibendum. Donec dictum.</li>
	<li>Etiam massa libero, lacinia at, commodo in, tincidunt a, purus.</li>
	<li>Praesent volutpat eros quis enim blandit tincidunt.</li>
	<li>Aenean eu libero nec lectus ultricies laoreet. Donec rutrum, nisi vel egestas ultrices, ipsum urna sagittis libero, vitae vestibulum dui dolor vel velit.</li>
</ol>', 'A Post With an Ordered List', '', 'inherit', 'open', 'open', '', '36-autosave', '', '', '2008-09-17 17:09:14', '2008-09-17 22:09:14', '', 39, 'http://dev.wpcoder.com/dan/wordpress/2008/09/36-autosave/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (49, 1, '2008-09-17 17:09:16', '2008-09-17 22:09:16', '<img class="alignright" src="http://i35.tinypic.com/990wtx.png" alt="WordPress Logo" align="right" />Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur quam augue, vehicula quis, tincidunt vel, varius vitae, nulla. Sed convallis orci. Duis libero orci, pretium a, <a href="#">convallis quis</a>, pellentesque a, dolor. Curabitur vitae nisi non dolor vestibulum consequat.
<blockquote>Proin vestibulum. Ut ligula. Nullam sed dolor id odio volutpat pulvinar. Integer a leo. In et eros at neque pretium sagittis. Sed sodales lorem a ipsum suscipit gravida. Ut fringilla placerat arcu. Phasellus imperdiet. Mauris ac justo et turpis pharetra vulputate.</blockquote>
<cite><a href="#">Quote Source</a></cite>
<h1>Level 1 Heading</h1>
<h2>Level 2 Heading</h2>
<h3>Level 3 Heading</h3>
<h4>Level 4 Heading</h4>
<h5>Level 5 Heading</h5>
<h6>Level 6 Heading</h6>
<h3>An Unordered List</h3>
<ul>
	<li>Vestibulum in mauris semper tortor interdum ultrices.</li>
	<li>Sed vel lorem et justo laoreet bibendum. Donec dictum.</li>
	<li>Etiam massa libero, lacinia at, commodo in, tincidunt a, purus.</li>
	<li>Praesent volutpat eros quis enim blandit tincidunt.</li>
	<li>Aenean eu libero nec lectus ultricies laoreet. Donec rutrum, nisi vel egestas ultrices, ipsum urna sagittis libero, vitae vestibulum dui dolor vel velit.</li>
</ul>
<h3>Image with no alignment</h3>
<img src="http://i35.tinypic.com/990wtx.png" alt="WordPress Logo" />

<img class="alignleft" src="http://i35.tinypic.com/990wtx.png" alt="WordPress Logo" align="left" />Nulla sagittis convallis arcu. Sed sed nunc. Curabitur consequat. Quisque metus enim, venenatis fermentum, mollis in, porta et, nibh. Duis vulputate elit in elit. Mauris dictum libero id justo. Fusce in est. Sed nec diam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Quisque semper nibh eget nibh. Sed tempor. Fusce erat.
<h3>An Ordered List</h3>
<ol>
	<li>Vestibulum in mauris semper tortor interdum ultrices.</li>
	<li>Sed vel lorem et justo laoreet bibendum. Donec dictum.</li>
	<li>Etiam massa libero, lacinia at, commodo in, tincidunt a, purus.</li>
	<li>Praesent volutpat eros quis enim blandit tincidunt.</li>
	<li>Aenean eu libero nec lectus ultricies laoreet. Donec rutrum, nisi vel egestas ultrices, ipsum urna sagittis libero, vitae vestibulum dui dolor vel velit.</li>
</ol>', 'A Post With Everything In It', '', 'inherit', 'open', 'open', '', '44-autosave', '', '', '2008-09-17 17:09:16', '2008-09-17 22:09:16', '', 47, 'http://dev.wpcoder.com/dan/wordpress/2008/09/44-autosave/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (50, 1, '2008-09-17 17:09:41', '2008-09-17 22:09:41', 'Nulla sagittis convallis arcu. Sed sed nunc. Curabitur consequat. Quisque metus enim, venenatis fermentum, mollis in, porta et, nibh. Duis vulputate elit in elit. Mauris dictum libero id justo. Fusce in est. Sed nec diam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Quisque semper nibh eget nibh. Sed tempor. Fusce erat.
<h3>An Ordered List</h3>
<ol>
	<li>Vestibulum in mauris semper tortor interdum ultrices.</li>
	<li>Sed vel lorem et justo laoreet bibendum. Donec dictum.</li>
	<li>Etiam massa libero, lacinia at, commodo in, tincidunt a, purus.</li>
	<li>Praesent volutpat eros quis enim blandit tincidunt.</li>
	<li>Aenean eu libero nec lectus ultricies laoreet. Donec rutrum, nisi vel egestas ultrices, ipsum urna sagittis libero, vitae vestibulum dui dolor vel velit.</li>
</ol>', 'An Ordered List Post', '', 'publish', 'open', 'open', '', 'an-ordered-list-post', '', '', '2008-09-17 17:09:41', '2008-09-17 22:09:41', '', 0, 'http://dev.wpcoder.com/dan/wordpress/?p=50', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (51, 1, '2008-09-17 17:09:38', '2008-09-17 22:09:38', '', 'An Ordered List Post', '', 'inherit', 'open', 'open', '', '50-revision-2', '', '', '2008-09-17 17:09:38', '2008-09-17 22:09:38', '', 50, 'http://dev.wpcoder.com/dan/wordpress/2008/09/50-revision/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (52, 1, '2008-09-11 22:25:45', '2008-09-12 03:25:45', '<img src="http://i35.tinypic.com/990wtx.png" alt="WordPress Logo" align="right" class="alignright" />Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur quam augue, vehicula quis, tincidunt vel, varius vitae, nulla. Sed convallis orci. Duis libero orci, pretium a, <a href="#">convallis quis</a>, pellentesque a, dolor. Curabitur vitae nisi non dolor vestibulum consequat.

<blockquote>Proin vestibulum. Ut ligula. Nullam sed dolor id odio volutpat pulvinar. Integer a leo. In et eros at neque pretium sagittis. Sed sodales lorem a ipsum suscipit gravida. Ut fringilla placerat arcu. Phasellus imperdiet. Mauris ac justo et turpis pharetra vulputate.</blockquote>
<cite><a href="#">Quote Source</a></cite>

<h1>Level 1 Heading</h1>
<h2>Level 2 Heading</h2>
<h3>Level 3 Heading</h3>
<h4>Level 4 Heading</h4>
<h5>Level 5 Heading</h5>
<h6>Level 6 Heading</h6>

<h3>An Unordered List</h3>

<ul>
<li>Vestibulum in mauris semper tortor interdum ultrices.</li>
<li>Sed vel lorem et justo laoreet bibendum. Donec dictum.</li>
<li>Etiam massa libero, lacinia at, commodo in, tincidunt a, purus.</li>
<li>Praesent volutpat eros quis enim blandit tincidunt.</li>
<li>Aenean eu libero nec lectus ultricies laoreet. Donec rutrum, nisi vel egestas ultrices, ipsum urna sagittis libero, vitae vestibulum dui dolor vel velit.</li>
</ul>

<h3>Image with no alignment</h3>

<img src="http://i35.tinypic.com/990wtx.png" alt="WordPress Logo"  />

<img src="http://i35.tinypic.com/990wtx.png" alt="WordPress Logo" align="left" class="alignleft" />Nulla sagittis convallis arcu. Sed sed nunc. Curabitur consequat. Quisque metus enim, venenatis fermentum, mollis in, porta et, nibh. Duis vulputate elit in elit. Mauris dictum libero id justo. Fusce in est. Sed nec diam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Quisque semper nibh eget nibh. Sed tempor. Fusce erat.

<h3>An Ordered List</h3>

<ol>
<li>Vestibulum in mauris semper tortor interdum ultrices.</li>
<li>Sed vel lorem et justo laoreet bibendum. Donec dictum.</li>
<li>Etiam massa libero, lacinia at, commodo in, tincidunt a, purus.</li>
<li>Praesent volutpat eros quis enim blandit tincidunt.</li>
<li>Aenean eu libero nec lectus ultricies laoreet. Donec rutrum, nisi vel egestas ultrices, ipsum urna sagittis libero, vitae vestibulum dui dolor vel velit.</li>
</ol>', 'A Post With Everything In It', '', 'inherit', 'open', 'open', '', '44-revision', '', '', '2008-09-11 22:25:45', '2008-09-12 03:25:45', '', 47, 'http://dev.wpcoder.com/dan/wordpress/2008/09/44-revision/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (53, 1, '2008-09-17 16:53:25', '2008-09-17 21:53:25', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world-2', '', '', '2008-09-17 16:53:25', '2008-09-17 21:53:25', '', 0, 'http://dev.wpcoder.com/dan/wordpress/?p=1', 0, 'post', '', 2) ; 
INSERT INTO `wp_posts` VALUES (54, 1, '2008-09-17 16:53:25', '2008-09-17 21:53:25', '[gravityform id="1" name="Shirt order form"]

This is an example of a WordPress page, you could edit this to put information about yourself or your site so readers know where you are coming from. You can create as many pages like this one or sub-pages as you like and manage all of your content inside of WordPress.', 'About', '', 'publish', 'open', 'open', '', 'about', '', '', '2013-05-23 09:57:11', '2013-05-23 15:57:11', '', 0, 'http://dev.wpcoder.com/dan/wordpress/?page_id=2', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (55, 1, '2008-09-17 17:08:29', '2008-09-17 22:08:29', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Sed eleifend urna eu sapien. Quisque posuere nunc eu massa. Praesent bibendum lorem non leo. Morbi volutpat, urna eu fermentum rutrum, ligula lacus interdum mauris, ac pulvinar libero pede a enim. Etiam commodo malesuada ante. Donec nec ligula. Curabitur mollis semper diam. <!--more-->

Duis viverra nibh a felis condimentum pretium. Nullam tristique lacus non purus. Donec vel felis. Etiam et sapien. Pellentesque nec quam a justo tincidunt laoreet. Aenean id enim. Donec lorem arcu, eleifend venenatis, rhoncus mollis, semper at, dui. Praesent velit tellus, adipiscing et, blandit convallis, dictum at, dui. Integer suscipit tortor in orci. Phasellus consequat. Quisque dictum convallis pede.

Mauris viverra scelerisque mauris. Nulla facilisis, elit malesuada pretium egestas, dolor arcu commodo est, at egestas massa tortor ut ante. Etiam eget libero. Aenean pretium, tellus sed sodales semper, turpis purus aliquet orci, pulvinar ornare odio tortor sit amet dui.

Aenean id orci. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus magna. Mauris tincidunt iaculis enim. Duis a mi vitae sapien dapibus tincidunt. Proin metus.

Proin cursus, libero non auctor faucibus, urna mi vestibulum orci, sit amet fermentum nibh purus eget enim. Aenean aliquet ligula nec nulla. Praesent sit amet lorem vitae massa hendrerit auctor. Sed sit amet urna. Aenean sapien nunc, imperdiet a, pharetra in, consequat eu, neque. Phasellus vel sem gravida augue consequat tempor. Curabitur eget mauris at pede varius facilisis.

Morbi ut sapien. Morbi arcu mauris, suscipit congue, placerat sit amet, suscipit a, ante. Donec aliquet dui ac nunc. Mauris magna quam, aliquet quis, viverra eu, fringilla eget, purus. Donec tristique pretium sem.', 'A Simple Text Post', '', 'inherit', 'open', 'open', '', '45-revision-2', '', '', '2008-09-17 17:08:29', '2008-09-17 22:08:29', '', 56, 'http://dev.wpcoder.com/dan/wordpress/2008/09/45-revision/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (56, 1, '2008-09-17 17:08:48', '2008-09-17 22:08:48', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Sed eleifend urna eu sapien. Quisque posuere nunc eu massa. Praesent bibendum lorem non leo. Morbi volutpat, urna eu fermentum rutrum, ligula lacus interdum mauris, ac pulvinar libero pede a enim. Etiam commodo malesuada ante. Donec nec ligula. Curabitur mollis semper diam. <!--more-->

Duis viverra nibh a felis condimentum pretium. Nullam tristique lacus non purus. Donec vel felis. Etiam et sapien. Pellentesque nec quam a justo tincidunt laoreet. Aenean id enim. Donec lorem arcu, eleifend venenatis, rhoncus mollis, semper at, dui. Praesent velit tellus, adipiscing et, blandit convallis, dictum at, dui. Integer suscipit tortor in orci. Phasellus consequat. Quisque dictum convallis pede.

Mauris viverra scelerisque mauris. Nulla facilisis, elit malesuada pretium egestas, dolor arcu commodo est, at egestas massa tortor ut ante. Etiam eget libero. Aenean pretium, tellus sed sodales semper, turpis purus aliquet orci, pulvinar ornare odio tortor sit amet dui.

Aenean id orci. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus magna. Mauris tincidunt iaculis enim. Duis a mi vitae sapien dapibus tincidunt. Proin metus.

Proin cursus, libero non auctor faucibus, urna mi vestibulum orci, sit amet fermentum nibh purus eget enim. Aenean aliquet ligula nec nulla. Praesent sit amet lorem vitae massa hendrerit auctor. Sed sit amet urna. Aenean sapien nunc, imperdiet a, pharetra in, consequat eu, neque. Phasellus vel sem gravida augue consequat tempor. Curabitur eget mauris at pede varius facilisis.

Morbi ut sapien. Morbi arcu mauris, suscipit congue, placerat sit amet, suscipit a, ante. Donec aliquet dui ac nunc. Mauris magna quam, aliquet quis, viverra eu, fringilla eget, purus. Donec tristique pretium sem.', 'A Simple Text Post', '', 'publish', 'open', 'open', '', 'a-simple-text-post', '', '', '2008-09-17 17:08:48', '2008-09-17 22:08:48', '', 0, 'http://dev.wpcoder.com/dan/wordpress/?p=45', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (57, 1, '2008-09-17 17:09:10', '2008-09-17 22:09:10', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Sed eleifend urna eu sapien. Quisque posuere nunc eu massa. Praesent bibendum lorem non leo. Morbi volutpat, urna eu fermentum rutrum, ligula lacus interdum mauris, ac pulvinar libero pede a enim. Etiam commodo malesuada ante. Donec nec ligula. Curabitur mollis semper diam. <!--more-->

Duis viverra nibh a felis condimentum pretium. Nullam tristique lacus non purus. Donec vel felis. Etiam et sapien. Pellentesque nec quam a justo tincidunt laoreet. Aenean id enim. Donec lorem arcu, eleifend venenatis, rhoncus mollis, semper at, dui. Praesent velit tellus, adipiscing et, blandit convallis, dictum at, dui. Integer suscipit tortor in orci. Phasellus consequat. Quisque dictum convallis pede.

Mauris viverra scelerisque mauris. Nulla facilisis, elit malesuada pretium egestas, dolor arcu commodo est, at egestas massa tortor ut ante. Etiam eget libero. Aenean pretium, tellus sed sodales semper, turpis purus aliquet orci, pulvinar ornare odio tortor sit amet dui.

Aenean id orci. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus magna. Mauris tincidunt iaculis enim. Duis a mi vitae sapien dapibus tincidunt. Proin metus.

Proin cursus, libero non auctor faucibus, urna mi vestibulum orci, sit amet fermentum nibh purus eget enim. Aenean aliquet ligula nec nulla. Praesent sit amet lorem vitae massa hendrerit auctor. Sed sit amet urna. Aenean sapien nunc, imperdiet a, pharetra in, consequat eu, neque. Phasellus vel sem gravida augue consequat tempor. Curabitur eget mauris at pede varius facilisis.

Morbi ut sapien. Morbi arcu mauris, suscipit congue, placerat sit amet, suscipit a, ante. Donec aliquet dui ac nunc. Mauris magna quam, aliquet quis, viverra eu, fringilla eget, purus. Donec tristique pretium sem.', 'A Simple Post with Text', '', 'inherit', 'open', 'open', '', '4-autosave', '', '', '2008-09-17 17:09:10', '2008-09-17 22:09:10', '', 7, 'http://dev.wpcoder.com/dan/wordpress/2008/09/4-autosave/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (58, 1, '2008-09-17 17:10:16', '2008-09-17 22:10:16', '', 'Another Post with Everything In It', '', 'inherit', 'open', 'open', '', '53-revision-2', '', '', '2008-09-17 17:10:16', '2008-09-17 22:10:16', '', 59, 'http://dev.wpcoder.com/dan/wordpress/2008/09/53-revision/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (59, 1, '2008-09-17 17:10:52', '2008-09-17 22:10:52', '<img class="alignright" src="http://i35.tinypic.com/990wtx.png" alt="WordPress Logo" align="right" />Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur quam augue, vehicula quis, tincidunt vel, varius vitae, nulla. Sed convallis orci. Duis libero orci, pretium a, <a href="#">convallis quis</a>, pellentesque a, dolor. Curabitur vitae nisi non dolor vestibulum consequat. <!--more-->

<blockquote>Proin vestibulum. Ut ligula. Nullam sed dolor id odio volutpat pulvinar. Integer a leo. In et eros at neque pretium sagittis. Sed sodales lorem a ipsum suscipit gravida. Ut fringilla placerat arcu. Phasellus imperdiet. Mauris ac justo et turpis pharetra vulputate.</blockquote>
<cite><a href="#">Quote Source</a></cite>
<h1>Level 1 Heading</h1>
<h2>Level 2 Heading</h2>
<h3>Level 3 Heading</h3>
<h4>Level 4 Heading</h4>
<h5>Level 5 Heading</h5>
<h6>Level 6 Heading</h6>
<h3>An Unordered List</h3>
<ul>
	<li>Vestibulum in mauris semper tortor interdum ultrices.</li>
	<li>Sed vel lorem et justo laoreet bibendum. Donec dictum.</li>
	<li>Etiam massa libero, lacinia at, commodo in, tincidunt a, purus.</li>
	<li>Praesent volutpat eros quis enim blandit tincidunt.</li>
	<li>Aenean eu libero nec lectus ultricies laoreet. Donec rutrum, nisi vel egestas ultrices, ipsum urna sagittis libero, vitae vestibulum dui dolor vel velit.</li>
</ul>
<h3>Image with no alignment</h3>
<img src="http://i35.tinypic.com/990wtx.png" alt="WordPress Logo" />

<img class="alignleft" src="http://i35.tinypic.com/990wtx.png" alt="WordPress Logo" align="left" />Nulla sagittis convallis arcu. Sed sed nunc. Curabitur consequat. Quisque metus enim, venenatis fermentum, mollis in, porta et, nibh. Duis vulputate elit in elit. Mauris dictum libero id justo. Fusce in est. Sed nec diam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Quisque semper nibh eget nibh. Sed tempor. Fusce erat.
<h3>An Ordered List</h3>
<ol>
	<li>Vestibulum in mauris semper tortor interdum ultrices.</li>
	<li>Sed vel lorem et justo laoreet bibendum. Donec dictum.</li>
	<li>Etiam massa libero, lacinia at, commodo in, tincidunt a, purus.</li>
	<li>Praesent volutpat eros quis enim blandit tincidunt.</li>
	<li>Aenean eu libero nec lectus ultricies laoreet. Donec rutrum, nisi vel egestas ultrices, ipsum urna sagittis libero, vitae vestibulum dui dolor vel velit.</li>
</ol>', 'Another Post with Everything In It', '', 'publish', 'open', 'open', '', 'another-post-with-everything-in-it', '', '', '2008-09-17 17:10:52', '2008-09-17 22:10:52', '', 0, 'http://dev.wpcoder.com/dan/wordpress/?p=53', 0, 'post', '', 2) ; 
INSERT INTO `wp_posts` VALUES (60, 1, '2008-09-17 17:10:52', '2008-09-17 22:10:52', '<img class="alignright" src="http://i35.tinypic.com/990wtx.png" alt="WordPress Logo" align="right" />Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur quam augue, vehicula quis, tincidunt vel, varius vitae, nulla. Sed convallis orci. Duis libero orci, pretium a, convallis quis, pellentesque a, dolor. Curabitur vitae nisi non dolor vestibulum consequat.

 Proin vestibulum. Ut ligula. Nullam sed dolor id odio volutpat pulvinar. Integer a leo. In et eros at neque pretium sagittis. Sed sodales lorem a ipsum suscipit gravida. Ut fringilla placerat arcu. Phasellus imperdiet. Mauris ac justo et turpis pharetra vulputate.

Quote Source
Level 1 Heading
Level 2 Heading
Level 3 Heading
Level 4 Heading
Level 5 Heading
Level 6 Heading
An Unordered List

    * Vestibulum in mauris semper tortor interdum ultrices.
    * Sed vel lorem et justo laoreet bibendum. Donec dictum.
    * Etiam massa libero, lacinia at, commodo in, tincidunt a, purus.
    * Praesent volutpat eros quis enim blandit tincidunt.
    * Aenean eu libero nec lectus ultricies laoreet. Donec rutrum, nisi vel egestas ultrices, ipsum urna sagittis libero, vitae vestibulum dui dolor vel velit.

Image with no alignment

WordPress Logo

<img class="alignright" src="http://i35.tinypic.com/990wtx.png" alt="WordPress Logo" align="left" />Nulla sagittis convallis arcu. Sed sed nunc. Curabitur consequat. Quisque metus enim, venenatis fermentum, mollis in, porta et, nibh. Duis vulputate elit in elit. Mauris dictum libero id justo. Fusce in est. Sed nec diam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Quisque semper nibh eget nibh. Sed tempor. Fusce erat.
An Ordered List

   1. Vestibulum in mauris semper tortor interdum ultrices.
   2. Sed vel lorem et justo laoreet bibendum. Donec dictum.
   3. Etiam massa libero, lacinia at, commodo in, tincidunt a, purus.
   4. Praesent volutpat eros quis enim blandit tincidunt.
   5. Aenean eu libero nec lectus ultricies laoreet. Donec rutrum, nisi vel egestas ultrices, ipsum urna sagittis libero, vitae vestibulum dui dolor vel velit.
', 'Another Post with Everything In It', '', 'inherit', 'open', 'open', '', '53-revision-2-2', '', '', '2008-09-17 17:10:52', '2008-09-17 22:10:52', '', 59, 'http://dev.wpcoder.com/dan/wordpress/2008/09/53-revision-2/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (61, 1, '2013-03-14 16:41:02', '2013-03-14 16:41:02', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Phasellus hendrerit. Pellentesque aliquet nibh nec urna. In nisi neque, aliquet vel, dapibus id, mattis vel, nisi. Sed pretium, ligula sollicitudin laoreet viverra, tortor libero sodales leo, eget blandit nunc tortor eu nibh. Nullam mollis. Ut justo. Suspendisse potenti.

Sed egestas, ante et vulputate volutpat, eros pede semper est, vitae luctus metus libero eu augue. Morbi purus libero, faucibus adipiscing, commodo quis, gravida id, est. Sed lectus. Praesent elementum hendrerit tortor. Sed semper lorem at felis. Vestibulum volutpat, lacus a ultrices sagittis, mi neque euismod dui, eu pulvinar nunc sapien ornare nisl. Phasellus pede arcu, dapibus eu, fermentum et, dapibus sed, urna.', 'Post Title', '', 'inherit', 'open', 'open', '', '4-revision-2', '', '', '2013-03-14 16:41:02', '2013-03-14 16:41:02', '', 4, 'http://basewp/4-revision-2/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (62, 1, '2013-03-19 08:17:04', '2013-03-19 14:17:04', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Phasellus hendrerit. Pellentesque aliquet nibh nec urna. In nisi neque, aliquet vel, dapibus id, mattis vel, nisi. Sed pretium, ligula sollicitudin laoreet viverra, tortor libero sodales leo, eget blandit nunc tortor eu nibh. Nullam mollis. Ut justo. Suspendisse potenti.

Sed egestas, ante et vulputate volutpat, eros pede semper est, vitae luctus metus libero eu augue. Morbi purus libero, faucibus adipiscing, commodo quis, gravida id, est. Sed lectus. Praesent elementum hendrerit tortor. Sed semper lorem at felis. Vestibulum volutpat, lacus a ultrices sagittis, mi neque euismod dui, eu pulvinar nunc sapien ornare nisl. Phasellus pede arcu, dapibus eu, fermentum et, dapibus sed, urna.', 'Post Title', '', 'inherit', 'open', 'open', '', '4-revision-3', '', '', '2013-03-19 08:17:04', '2013-03-19 14:17:04', '', 4, 'http://basewp/4-revision-3/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (63, 1, '2013-03-19 08:18:21', '2013-03-19 14:18:21', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Phasellus hendrerit. Pellentesque aliquet nibh nec urna. In nisi neque, aliquet vel, dapibus id, mattis vel, nisi. Sed pretium, ligula sollicitudin laoreet viverra, tortor libero sodales leo, eget blandit nunc tortor eu nibh. Nullam mollis. Ut justo. Suspendisse potenti.

Sed egestas, ante et vulputate volutpat, eros pede semper est, vitae luctus metus libero eu augue. Morbi purus libero, faucibus adipiscing, commodo quis, gravida id, est. Sed lectus. Praesent elementum hendrerit tortor. Sed semper lorem at felis. Vestibulum volutpat, lacus a ultrices sagittis, mi neque euismod dui, eu pulvinar nunc sapien ornare nisl. Phasellus pede arcu, dapibus eu, fermentum et, dapibus sed, urna.', 'Post Title', '', 'inherit', 'open', 'open', '', '4-autosave-2', '', '', '2013-03-19 08:18:21', '2013-03-19 14:18:21', '', 4, 'http://basewp/4-autosave-2/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (64, 1, '2013-03-19 08:17:20', '2013-03-19 14:17:20', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Phasellus hendrerit. Pellentesque aliquet nibh nec urna. In nisi neque, aliquet vel, dapibus id, mattis vel, nisi. Sed pretium, ligula sollicitudin laoreet viverra, tortor libero sodales leo, eget blandit nunc tortor eu nibh. Nullam mollis. Ut justo. Suspendisse potenti.

Sed egestas, ante et vulputate volutpat, eros pede semper est, vitae luctus metus libero eu augue. Morbi purus libero, faucibus adipiscing, commodo quis, gravida id, est. Sed lectus. Praesent elementum hendrerit tortor. Sed semper lorem at felis. Vestibulum volutpat, lacus a ultrices sagittis, mi neque euismod dui, eu pulvinar nunc sapien ornare nisl. Phasellus pede arcu, dapibus eu, fermentum et, dapibus sed, urna.', 'Post Title', '', 'inherit', 'open', 'open', '', '4-revision-4', '', '', '2013-03-19 08:17:20', '2013-03-19 14:17:20', '', 4, 'http://basewp/4-revision-4/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (65, 1, '2013-03-19 08:18:36', '2013-03-19 14:18:36', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Phasellus hendrerit. Pellentesque aliquet nibh nec urna. In nisi neque, aliquet vel, dapibus id, mattis vel, nisi. Sed pretium, ligula sollicitudin laoreet viverra, tortor libero sodales leo, eget blandit nunc tortor eu nibh. Nullam mollis. Ut justo. Suspendisse potenti.

Sed egestas, ante et vulputate volutpat, eros pede semper est, vitae luctus metus libero eu augue. Morbi purus libero, faucibus adipiscing, commodo quis, gravida id, est. Sed lectus. Praesent elementum hendrerit tortor. Sed semper lorem at felis. Vestibulum volutpat, lacus a ultrices sagittis, mi neque euismod dui, eu pulvinar nunc sapien ornare nisl. Phasellus pede arcu, dapibus eu, fermentum et, dapibus sed, urna.', 'Post Title', '', 'inherit', 'open', 'open', '', '4-revision-5', '', '', '2013-03-19 08:18:36', '2013-03-19 14:18:36', '', 4, 'http://basewp/4-revision-5/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (66, 1, '2013-03-19 08:19:43', '2013-03-19 14:19:43', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Phasellus hendrerit. Pellentesque aliquet nibh nec urna. In nisi neque, aliquet vel, dapibus id, mattis vel, nisi. Sed pretium, ligula sollicitudin laoreet viverra, tortor libero sodales leo, eget blandit nunc tortor eu nibh. Nullam mollis. Ut justo. Suspendisse potenti.

Sed egestas, ante et vulputate volutpat, eros pede semper est, vitae luctus metus libero eu augue. Morbi purus libero, faucibus adipiscing, commodo quis, gravida id, est. Sed lectus. Praesent elementum hendrerit tortor. Sed semper lorem at felis. Vestibulum volutpat, lacus a ultrices sagittis, mi neque euismod dui, eu pulvinar nunc sapien ornare nisl. Phasellus pede arcu, dapibus eu, fermentum et, dapibus sed, urna.', 'Post Title', '', 'inherit', 'open', 'open', '', '4-autosave-3', '', '', '2013-03-19 08:19:43', '2013-03-19 14:19:43', '', 4, 'http://basewp/4-autosave-3/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (67, 1, '2013-03-19 08:22:21', '2013-03-19 14:22:21', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Phasellus hendrerit. Pellentesque aliquet nibh nec urna. In nisi neque, aliquet vel, dapibus id, mattis vel, nisi. Sed pretium, ligula sollicitudin laoreet viverra, tortor libero sodales leo, eget blandit nunc tortor eu nibh. Nullam mollis. Ut justo. Suspendisse potenti.

Sed egestas, ante et vulputate volutpat, eros pede semper est, vitae luctus metus libero eu augue. Morbi purus libero, faucibus adipiscing, commodo quis, gravida id, est. Sed lectus. Praesent elementum hendrerit tortor. Sed semper lorem at felis. Vestibulum volutpat, lacus a ultrices sagittis, mi neque euismod dui, eu pulvinar nunc sapien ornare nisl. Phasellus pede arcu, dapibus eu, fermentum et, dapibus sed, urna.', 'Post Title', '', 'inherit', 'open', 'open', '', '4-autosave-4', '', '', '2013-03-19 08:22:21', '2013-03-19 14:22:21', '', 4, 'http://basewp/4-autosave-4/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (68, 1, '2008-09-17 16:53:25', '2008-09-17 21:53:25', 'This is an example of a WordPress page, you could edit this to put information about yourself or your site so readers know where you are coming from. You can create as many pages like this one or sub-pages as you like and manage all of your content inside of WordPress.', 'About', '', 'inherit', 'open', 'open', '', '54-revision', '', '', '2008-09-17 16:53:25', '2008-09-17 21:53:25', '', 54, 'http://basewp/54-revision/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (69, 1, '2013-03-20 11:17:28', '2013-03-20 17:17:28', 'This is an example of a WordPress page, you could edit this to put information about yourself or your site so readers know where you are coming from. You can create as many pages like this one or sub-pages as you like and manage all of your content inside of WordPress.[googlemaps]', 'About', '', 'inherit', 'open', 'open', '', '54-revision-2', '', '', '2013-03-20 11:17:28', '2013-03-20 17:17:28', '', 54, 'http://basewp/54-revision-2/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (70, 1, '2013-05-23 09:58:36', '2013-05-23 15:58:36', '[gravityform id="1" name="Shirt order form"]

This is an example of a WordPress page, you could edit this to put information about yourself or your site so readers know where you are coming from. You can create as many pages like this one or sub-pages as you like and manage all of your content inside of WordPress.', 'About', '', 'inherit', 'open', 'open', '', '54-autosave', '', '', '2013-05-23 09:58:36', '2013-05-23 15:58:36', '', 54, 'http://basewp/54-autosave/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (76, 1, '2013-04-25 09:52:23', '2013-04-25 15:52:23', 'Information about caldones', 'Caldones', '', 'publish', 'open', 'open', '', 'caldones', '', '', '2013-04-25 10:02:45', '2013-04-25 16:02:45', '', 0, 'http://basewp/?post_type=wpbdp_listing&#038;p=76', 0, 'wpbdp_listing', '', 0) ; 
INSERT INTO `wp_posts` VALUES (77, 1, '2013-04-25 09:54:30', '2013-04-25 15:54:30', 'Information about caldones', 'Caldones', '', 'inherit', 'open', 'open', '', '76-autosave', '', '', '2013-04-25 09:54:30', '2013-04-25 15:54:30', '', 76, 'http://basewp/76-autosave/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (78, 1, '2008-09-11 19:20:42', '2008-09-12 00:20:42', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nam vel turpis. Duis sit amet lectus ac mauris porta viverra. Aliquam erat volutpat. Praesent ipsum pede, pretium sed, congue nec, pretium quis, urna. Suspendisse dignissim, elit in ultrices sollicitudin, nisl est accumsan orci, a venenatis dui mi porta pede. Aenean et pede quis est tincidunt varius.

Cras aliquet. Integer faucibus, eros ac molestie placerat, enim tellus varius lacus, nec dictum nunc tortor id urna. Suspendisse dapibus ullamcorper pede. Vivamus ligula ipsum, faucibus at, tincidunt eget, porttitor non, dolor. Ut dui lectus, ultrices ut, sodales tincidunt, viverra sed, nisl.

Praesent ac quam vulputate felis ultrices scelerisque. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. In in arcu. Vestibulum eget nisi quis tellus elementum dapibus. Cras facilisis venenatis libero. Nunc accumsan viverra augue. Suspendisse potenti. Suspendisse eleifend. Maecenas sit amet justo.

Quisque quam nisi, mollis quis, sodales ut, rhoncus nec, risus. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Proin pede. Aliquam neque tortor, euismod ac, eleifend quis, tincidunt quis, neque.

Phasellus rhoncus. Donec urna nulla, vehicula et, consectetuer vel, condimentum quis, ipsum. Nulla quis neque eu sapien tincidunt faucibus. Donec eleifend, metus sed elementum lobortis, arcu elit luctus enim, sed vestibulum diam leo nec nunc. Suspendisse tempus.

Phasellus quis mauris. Integer eu justo. Fusce tortor enim, elementum ut, auctor non, accumsan quis, enim. Aenean posuere ante id odio. Nulla facilisi. Donec ac eros quis ipsum auctor blandit. Cras eleifend libero fringilla turpis. Integer sem. Curabitur commodo dapibus lacus.

Vivamus semper auctor turpis. Sed ipsum lacus, varius quis, iaculis at, mollis sagittis, arcu.', 'History', '', 'inherit', 'open', 'open', '', '20-revision', '', '', '2008-09-11 19:20:42', '2008-09-12 00:20:42', '', 20, 'http://basewp/20-revision/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (79, 1, '2008-09-11 19:20:11', '2008-09-12 00:20:11', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nam vel turpis. Duis sit amet lectus ac mauris porta viverra. Aliquam erat volutpat. Praesent ipsum pede, pretium sed, congue nec, pretium quis, urna. Suspendisse dignissim, elit in ultrices sollicitudin, nisl est accumsan orci, a venenatis dui mi porta pede. Aenean et pede quis est tincidunt varius.

Cras aliquet. Integer faucibus, eros ac molestie placerat, enim tellus varius lacus, nec dictum nunc tortor id urna. Suspendisse dapibus ullamcorper pede. Vivamus ligula ipsum, faucibus at, tincidunt eget, porttitor non, dolor. Ut dui lectus, ultrices ut, sodales tincidunt, viverra sed, nisl.

Praesent ac quam vulputate felis ultrices scelerisque. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. In in arcu. Vestibulum eget nisi quis tellus elementum dapibus. Cras facilisis venenatis libero. Nunc accumsan viverra augue. Suspendisse potenti. Suspendisse eleifend. Maecenas sit amet justo.

Quisque quam nisi, mollis quis, sodales ut, rhoncus nec, risus. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Proin pede. Aliquam neque tortor, euismod ac, eleifend quis, tincidunt quis, neque.

Phasellus rhoncus. Donec urna nulla, vehicula et, consectetuer vel, condimentum quis, ipsum. Nulla quis neque eu sapien tincidunt faucibus. Donec eleifend, metus sed elementum lobortis, arcu elit luctus enim, sed vestibulum diam leo nec nunc. Suspendisse tempus.

Phasellus quis mauris. Integer eu justo. Fusce tortor enim, elementum ut, auctor non, accumsan quis, enim. Aenean posuere ante id odio. Nulla facilisi. Donec ac eros quis ipsum auctor blandit. Cras eleifend libero fringilla turpis. Integer sem. Curabitur commodo dapibus lacus.

Vivamus semper auctor turpis. Sed ipsum lacus, varius quis, iaculis at, mollis sagittis, arcu.', 'Our Company', '', 'inherit', 'open', 'open', '', '15-revision', '', '', '2008-09-11 19:20:11', '2008-09-12 00:20:11', '', 15, 'http://basewp/15-revision/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (80, 1, '2008-09-11 19:24:58', '2008-09-12 00:24:58', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nam vel turpis. Duis sit amet lectus ac mauris porta viverra. Aliquam erat volutpat. Praesent ipsum pede, pretium sed, congue nec, pretium quis, urna. Suspendisse dignissim, elit in ultrices sollicitudin, nisl est accumsan orci, a venenatis dui mi porta pede. Aenean et pede quis est tincidunt varius.

Cras aliquet. Integer faucibus, eros ac molestie placerat, enim tellus varius lacus, nec dictum nunc tortor id urna. Suspendisse dapibus ullamcorper pede. Vivamus ligula ipsum, faucibus at, tincidunt eget, porttitor non, dolor. Ut dui lectus, ultrices ut, sodales tincidunt, viverra sed, nisl.

Praesent ac quam vulputate felis ultrices scelerisque. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. In in arcu. Vestibulum eget nisi quis tellus elementum dapibus. Cras facilisis venenatis libero. Nunc accumsan viverra augue. Suspendisse potenti. Suspendisse eleifend. Maecenas sit amet justo.

Quisque quam nisi, mollis quis, sodales ut, rhoncus nec, risus. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Proin pede. Aliquam neque tortor, euismod ac, eleifend quis, tincidunt quis, neque.

Phasellus rhoncus. Donec urna nulla, vehicula et, consectetuer vel, condimentum quis, ipsum. Nulla quis neque eu sapien tincidunt faucibus. Donec eleifend, metus sed elementum lobortis, arcu elit luctus enim, sed vestibulum diam leo nec nunc. Suspendisse tempus.

Phasellus quis mauris. Integer eu justo. Fusce tortor enim, elementum ut, auctor non, accumsan quis, enim. Aenean posuere ante id odio. Nulla facilisi. Donec ac eros quis ipsum auctor blandit. Cras eleifend libero fringilla turpis. Integer sem. Curabitur commodo dapibus lacus.

Vivamus semper auctor turpis. Sed ipsum lacus, varius quis, iaculis at, mollis sagittis, arcu.', 'Employment Opportunities', '', 'inherit', 'open', 'open', '', '32-revision-2', '', '', '2008-09-11 19:24:58', '2008-09-12 00:24:58', '', 32, 'http://basewp/32-revision-2/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (81, 1, '2013-03-14 16:38:54', '2013-03-14 16:38:54', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:

<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>

...or something like this:

<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>

As a new WordPress user, you should go to <a href="http://basewp/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'inherit', 'open', 'open', '', '2-revision', '', '', '2013-03-14 16:38:54', '2013-03-14 16:38:54', '', 2, 'http://basewp/2-revision/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (82, 1, '2008-09-11 19:20:52', '2008-09-12 00:20:52', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nam vel turpis. Duis sit amet lectus ac mauris porta viverra. Aliquam erat volutpat. Praesent ipsum pede, pretium sed, congue nec, pretium quis, urna. Suspendisse dignissim, elit in ultrices sollicitudin, nisl est accumsan orci, a venenatis dui mi porta pede. Aenean et pede quis est tincidunt varius.

Cras aliquet. Integer faucibus, eros ac molestie placerat, enim tellus varius lacus, nec dictum nunc tortor id urna. Suspendisse dapibus ullamcorper pede. Vivamus ligula ipsum, faucibus at, tincidunt eget, porttitor non, dolor. Ut dui lectus, ultrices ut, sodales tincidunt, viverra sed, nisl.

Praesent ac quam vulputate felis ultrices scelerisque. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. In in arcu. Vestibulum eget nisi quis tellus elementum dapibus. Cras facilisis venenatis libero. Nunc accumsan viverra augue. Suspendisse potenti. Suspendisse eleifend. Maecenas sit amet justo.

Quisque quam nisi, mollis quis, sodales ut, rhoncus nec, risus. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Proin pede. Aliquam neque tortor, euismod ac, eleifend quis, tincidunt quis, neque.

Phasellus rhoncus. Donec urna nulla, vehicula et, consectetuer vel, condimentum quis, ipsum. Nulla quis neque eu sapien tincidunt faucibus. Donec eleifend, metus sed elementum lobortis, arcu elit luctus enim, sed vestibulum diam leo nec nunc. Suspendisse tempus.

Phasellus quis mauris. Integer eu justo. Fusce tortor enim, elementum ut, auctor non, accumsan quis, enim. Aenean posuere ante id odio. Nulla facilisi. Donec ac eros quis ipsum auctor blandit. Cras eleifend libero fringilla turpis. Integer sem. Curabitur commodo dapibus lacus.

Vivamus semper auctor turpis. Sed ipsum lacus, varius quis, iaculis at, mollis sagittis, arcu.', 'Support', '', 'inherit', 'open', 'open', '', '22-revision-4', '', '', '2008-09-11 19:20:52', '2008-09-12 00:20:52', '', 22, 'http://basewp/22-revision-4/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (83, 1, '2013-04-25 10:03:24', '2013-04-25 16:03:24', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nam vel turpis. Duis sit amet lectus ac mauris porta viverra. Aliquam erat volutpat. Praesent ipsum pede, pretium sed, congue nec, pretium quis, urna. Suspendisse dignissim, elit in ultrices sollicitudin, nisl est accumsan orci, a venenatis dui mi porta pede. Aenean et pede quis est tincidunt varius.

Cras aliquet. Integer faucibus, eros ac molestie placerat, enim tellus varius lacus, nec dictum nunc tortor id urna. Suspendisse dapibus ullamcorper pede. Vivamus ligula ipsum, faucibus at, tincidunt eget, porttitor non, dolor. Ut dui lectus, ultrices ut, sodales tincidunt, viverra sed, nisl.

Praesent ac quam vulputate felis ultrices scelerisque. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. In in arcu. Vestibulum eget nisi quis tellus elementum dapibus. Cras facilisis venenatis libero. Nunc accumsan viverra augue. Suspendisse potenti. Suspendisse eleifend. Maecenas sit amet justo.

Quisque quam nisi, mollis quis, sodales ut, rhoncus nec, risus. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Proin pede. Aliquam neque tortor, euismod ac, eleifend quis, tincidunt quis, neque.

Phasellus rhoncus. Donec urna nulla, vehicula et, consectetuer vel, condimentum quis, ipsum. Nulla quis neque eu sapien tincidunt faucibus. Donec eleifend, metus sed elementum lobortis, arcu elit luctus enim, sed vestibulum diam leo nec nunc. Suspendisse tempus.

Phasellus quis mauris. Integer eu justo. Fusce tortor enim, elementum ut, auctor non, accumsan quis, enim. Aenean posuere ante id odio. Nulla facilisi. Donec ac eros quis ipsum auctor blandit. Cras eleifend libero fringilla turpis. Integer sem. Curabitur commodo dapibus lacus.

Vivamus semper auctor turpis. Sed ipsum lacus, varius quis, iaculis at, mollis sagittis, arcu.', 'History', '', 'inherit', 'open', 'open', '', '20-revision-2', '', '', '2013-04-25 10:03:24', '2013-04-25 16:03:24', '', 20, 'http://basewp/20-revision-2/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (84, 1, '2013-04-25 10:03:24', '2013-04-25 16:03:24', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nam vel turpis. Duis sit amet lectus ac mauris porta viverra. Aliquam erat volutpat. Praesent ipsum pede, pretium sed, congue nec, pretium quis, urna. Suspendisse dignissim, elit in ultrices sollicitudin, nisl est accumsan orci, a venenatis dui mi porta pede. Aenean et pede quis est tincidunt varius.

Cras aliquet. Integer faucibus, eros ac molestie placerat, enim tellus varius lacus, nec dictum nunc tortor id urna. Suspendisse dapibus ullamcorper pede. Vivamus ligula ipsum, faucibus at, tincidunt eget, porttitor non, dolor. Ut dui lectus, ultrices ut, sodales tincidunt, viverra sed, nisl.

Praesent ac quam vulputate felis ultrices scelerisque. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. In in arcu. Vestibulum eget nisi quis tellus elementum dapibus. Cras facilisis venenatis libero. Nunc accumsan viverra augue. Suspendisse potenti. Suspendisse eleifend. Maecenas sit amet justo.

Quisque quam nisi, mollis quis, sodales ut, rhoncus nec, risus. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Proin pede. Aliquam neque tortor, euismod ac, eleifend quis, tincidunt quis, neque.

Phasellus rhoncus. Donec urna nulla, vehicula et, consectetuer vel, condimentum quis, ipsum. Nulla quis neque eu sapien tincidunt faucibus. Donec eleifend, metus sed elementum lobortis, arcu elit luctus enim, sed vestibulum diam leo nec nunc. Suspendisse tempus.

Phasellus quis mauris. Integer eu justo. Fusce tortor enim, elementum ut, auctor non, accumsan quis, enim. Aenean posuere ante id odio. Nulla facilisi. Donec ac eros quis ipsum auctor blandit. Cras eleifend libero fringilla turpis. Integer sem. Curabitur commodo dapibus lacus.

Vivamus semper auctor turpis. Sed ipsum lacus, varius quis, iaculis at, mollis sagittis, arcu.', 'Our Company', '', 'inherit', 'open', 'open', '', '15-revision-2', '', '', '2013-04-25 10:03:24', '2013-04-25 16:03:24', '', 15, 'http://basewp/15-revision-2/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (85, 1, '2013-04-25 10:03:25', '2013-04-25 16:03:25', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nam vel turpis. Duis sit amet lectus ac mauris porta viverra. Aliquam erat volutpat. Praesent ipsum pede, pretium sed, congue nec, pretium quis, urna. Suspendisse dignissim, elit in ultrices sollicitudin, nisl est accumsan orci, a venenatis dui mi porta pede. Aenean et pede quis est tincidunt varius.

Cras aliquet. Integer faucibus, eros ac molestie placerat, enim tellus varius lacus, nec dictum nunc tortor id urna. Suspendisse dapibus ullamcorper pede. Vivamus ligula ipsum, faucibus at, tincidunt eget, porttitor non, dolor. Ut dui lectus, ultrices ut, sodales tincidunt, viverra sed, nisl.

Praesent ac quam vulputate felis ultrices scelerisque. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. In in arcu. Vestibulum eget nisi quis tellus elementum dapibus. Cras facilisis venenatis libero. Nunc accumsan viverra augue. Suspendisse potenti. Suspendisse eleifend. Maecenas sit amet justo.

Quisque quam nisi, mollis quis, sodales ut, rhoncus nec, risus. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Proin pede. Aliquam neque tortor, euismod ac, eleifend quis, tincidunt quis, neque.

Phasellus rhoncus. Donec urna nulla, vehicula et, consectetuer vel, condimentum quis, ipsum. Nulla quis neque eu sapien tincidunt faucibus. Donec eleifend, metus sed elementum lobortis, arcu elit luctus enim, sed vestibulum diam leo nec nunc. Suspendisse tempus.

Phasellus quis mauris. Integer eu justo. Fusce tortor enim, elementum ut, auctor non, accumsan quis, enim. Aenean posuere ante id odio. Nulla facilisi. Donec ac eros quis ipsum auctor blandit. Cras eleifend libero fringilla turpis. Integer sem. Curabitur commodo dapibus lacus.

Vivamus semper auctor turpis. Sed ipsum lacus, varius quis, iaculis at, mollis sagittis, arcu.', 'Employment Opportunities', '', 'inherit', 'open', 'open', '', '32-revision-3', '', '', '2013-04-25 10:03:25', '2013-04-25 16:03:25', '', 32, 'http://basewp/32-revision-3/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (86, 1, '2013-04-25 10:03:25', '2013-04-25 16:03:25', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:

<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>

...or something like this:

<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>

As a new WordPress user, you should go to <a href="http://basewp/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'inherit', 'open', 'open', '', '2-revision-2', '', '', '2013-04-25 10:03:25', '2013-04-25 16:03:25', '', 2, 'http://basewp/2-revision-2/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (87, 1, '2013-04-25 10:03:25', '2013-04-25 16:03:25', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nam vel turpis. Duis sit amet lectus ac mauris porta viverra. Aliquam erat volutpat. Praesent ipsum pede, pretium sed, congue nec, pretium quis, urna. Suspendisse dignissim, elit in ultrices sollicitudin, nisl est accumsan orci, a venenatis dui mi porta pede. Aenean et pede quis est tincidunt varius.

Cras aliquet. Integer faucibus, eros ac molestie placerat, enim tellus varius lacus, nec dictum nunc tortor id urna. Suspendisse dapibus ullamcorper pede. Vivamus ligula ipsum, faucibus at, tincidunt eget, porttitor non, dolor. Ut dui lectus, ultrices ut, sodales tincidunt, viverra sed, nisl.

Praesent ac quam vulputate felis ultrices scelerisque. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. In in arcu. Vestibulum eget nisi quis tellus elementum dapibus. Cras facilisis venenatis libero. Nunc accumsan viverra augue. Suspendisse potenti. Suspendisse eleifend. Maecenas sit amet justo.

Quisque quam nisi, mollis quis, sodales ut, rhoncus nec, risus. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Proin pede. Aliquam neque tortor, euismod ac, eleifend quis, tincidunt quis, neque.

Phasellus rhoncus. Donec urna nulla, vehicula et, consectetuer vel, condimentum quis, ipsum. Nulla quis neque eu sapien tincidunt faucibus. Donec eleifend, metus sed elementum lobortis, arcu elit luctus enim, sed vestibulum diam leo nec nunc. Suspendisse tempus.

Phasellus quis mauris. Integer eu justo. Fusce tortor enim, elementum ut, auctor non, accumsan quis, enim. Aenean posuere ante id odio. Nulla facilisi. Donec ac eros quis ipsum auctor blandit. Cras eleifend libero fringilla turpis. Integer sem. Curabitur commodo dapibus lacus.

Vivamus semper auctor turpis. Sed ipsum lacus, varius quis, iaculis at, mollis sagittis, arcu.', 'Support', '', 'inherit', 'open', 'open', '', '22-revision-5', '', '', '2013-04-25 10:03:25', '2013-04-25 16:03:25', '', 22, 'http://basewp/22-revision-5/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (89, 1, '2013-05-16 14:02:49', '2013-05-16 20:02:49', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nam vel turpis. Duis sit amet lectus ac mauris porta viverra. Aliquam erat volutpat. Praesent ipsum pede, pretium sed, congue nec, pretium quis, urna. Suspendisse dignissim, elit in ultrices sollicitudin, nisl est accumsan orci, a venenatis dui mi porta pede. Aenean et pede quis est tincidunt varius.

Cras aliquet. Integer faucibus, eros ac molestie placerat, enim tellus varius lacus, nec dictum nunc tortor id urna. Suspendisse dapibus ullamcorper pede. Vivamus ligula ipsum, faucibus at, tincidunt eget, porttitor non, dolor. Ut dui lectus, ultrices ut, sodales tincidunt, viverra sed, nisl.

Praesent ac quam vulputate felis ultrices scelerisque. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. In in arcu. Vestibulum eget nisi quis tellus elementum dapibus. Cras facilisis venenatis libero. Nunc accumsan viverra augue. Suspendisse potenti. Suspendisse eleifend. Maecenas sit amet justo.

Quisque quam nisi, mollis quis, sodales ut, rhoncus nec, risus. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Proin pede. Aliquam neque tortor, euismod ac, eleifend quis, tincidunt quis, neque.

Phasellus rhoncus. Donec urna nulla, vehicula et, consectetuer vel, condimentum quis, ipsum. Nulla quis neque eu sapien tincidunt faucibus. Donec eleifend, metus sed elementum lobortis, arcu elit luctus enim, sed vestibulum diam leo nec nunc. Suspendisse tempus.

Phasellus quis mauris. Integer eu justo. Fusce tortor enim, elementum ut, auctor non, accumsan quis, enim. Aenean posuere ante id odio. Nulla facilisi. Donec ac eros quis ipsum auctor blandit. Cras eleifend libero fringilla turpis. Integer sem. Curabitur commodo dapibus lacus.

Vivamus semper auctor turpis. Sed ipsum lacus, varius quis, iaculis at, mollis sagittis, arcu.', 'History', '', 'inherit', 'open', 'open', '', '20-autosave', '', '', '2013-05-16 14:02:49', '2013-05-16 20:02:49', '', 20, 'http://basewp/20-autosave/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (90, 1, '2013-03-20 11:17:35', '2013-03-20 17:17:35', 'This is an example of a WordPress page, you could edit this to put information about yourself or your site so readers know where you are coming from. You can create as many pages like this one or sub-pages as you like and manage all of your content inside of WordPress.', 'About', '', 'inherit', 'open', 'open', '', '54-revision-3', '', '', '2013-03-20 11:17:35', '2013-03-20 17:17:35', '', 54, 'http://basewp/54-revision-3/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (91, 1, '2013-05-23 09:44:32', '2013-05-23 15:44:32', '[gravityform id="1" name="Shirt order form"]

This is an example of a WordPress page, you could edit this to put information about yourself or your site so readers know where you are coming from. You can create as many pages like this one or sub-pages as you like and manage all of your content inside of WordPress.', 'About', '', 'inherit', 'open', 'open', '', '54-revision-4', '', '', '2013-05-23 09:44:32', '2013-05-23 15:44:32', '', 54, 'http://basewp/54-revision-4/', 0, 'revision', '', 0) ;
#
# End of data contents of table wp_posts
# --------------------------------------------------------

# WordPress : http://basewp MySQL database backup
#
# Generated: Friday 24. May 2013 17:58 UTC
# Hostname: localhost
# Database: `basewp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form`
# --------------------------------------------------------


#
# Delete any existing table `wp_rg_form`
#

DROP TABLE IF EXISTS `wp_rg_form`;


#
# Table structure of table `wp_rg_form`
#

CREATE TABLE `wp_rg_form` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(150) NOT NULL,
  `date_created` datetime NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_rg_form (1 records)
#
 
INSERT INTO `wp_rg_form` VALUES (1, 'Shirt order form', '2013-05-23 15:38:59', 1) ;
#
# End of data contents of table wp_rg_form
# --------------------------------------------------------

# WordPress : http://basewp MySQL database backup
#
# Generated: Friday 24. May 2013 17:58 UTC
# Hostname: localhost
# Database: `basewp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_meta`
# --------------------------------------------------------


#
# Delete any existing table `wp_rg_form_meta`
#

DROP TABLE IF EXISTS `wp_rg_form_meta`;


#
# Table structure of table `wp_rg_form_meta`
#

CREATE TABLE `wp_rg_form_meta` (
  `form_id` mediumint(8) unsigned NOT NULL,
  `display_meta` longtext,
  `entries_grid_meta` longtext,
  PRIMARY KEY (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_rg_form_meta (1 records)
#
 
INSERT INTO `wp_rg_form_meta` VALUES (1, 'a:37:{s:2:"id";i:1;s:5:"title";s:16:"Shirt order form";s:11:"description";s:100:"We would love to hear from you! Please fill out this form and we will get in touch with you shortly.";s:14:"labelPlacement";s:9:"top_label";s:17:"maxEntriesMessage";s:0:"";s:12:"confirmation";a:6:{s:4:"type";s:7:"message";s:7:"message";s:64:"Thanks for contacting us! We will get in touch with you shortly.";s:3:"url";s:0:"";s:6:"pageId";s:0:"";s:11:"queryString";s:0:"";s:17:"disableAutoformat";b:0;}s:6:"button";a:3:{s:4:"type";s:4:"text";s:4:"text";s:6:"Submit";s:8:"imageUrl";s:0:"";}s:6:"fields";a:4:{i:0;a:58:{s:10:"adminLabel";s:0:"";s:9:"adminOnly";s:0:"";s:17:"allowsPrepopulate";b:0;s:12:"defaultValue";s:0:"";s:11:"description";s:0:"";s:7:"content";s:0:"";s:8:"cssClass";s:0:"";s:12:"errorMessage";s:0:"";s:2:"id";i:5;s:9:"inputName";s:0:"";s:10:"isRequired";b:1;s:5:"label";s:12:"Product Name";s:12:"noDuplicates";s:0:"";s:4:"size";s:6:"medium";s:4:"type";s:7:"product";s:19:"postCustomFieldName";s:0:"";s:20:"displayAllCategories";b:0;s:14:"displayCaption";s:0:"";s:18:"displayDescription";s:0:"";s:12:"displayTitle";s:0:"";s:9:"inputType";s:13:"singleproduct";s:8:"rangeMin";s:0:"";s:8:"rangeMax";s:0:"";s:16:"calendarIconType";s:0:"";s:15:"calendarIconUrl";s:0:"";s:8:"dateType";s:0:"";s:10:"dateFormat";s:0:"";s:11:"phoneFormat";s:0:"";s:11:"addressType";s:0:"";s:14:"defaultCountry";s:0:"";s:15:"defaultProvince";s:0:"";s:12:"defaultState";s:0:"";s:12:"hideAddress2";s:0:"";s:11:"hideCountry";s:0:"";s:9:"hideState";s:0:"";s:6:"inputs";a:3:{i:0;a:3:{s:2:"id";d:5.0999999999999996447286321199499070644378662109375;s:5:"label";s:4:"Name";s:4:"name";s:0:"";}i:1;a:3:{s:2:"id";d:5.20000000000000017763568394002504646778106689453125;s:5:"label";s:5:"Price";s:4:"name";s:0:"";}i:2;a:3:{s:2:"id";d:5.29999999999999982236431605997495353221893310546875;s:5:"label";s:8:"Quantity";s:4:"name";s:0:"";}}s:10:"nameFormat";s:0:"";s:17:"allowedExtensions";s:0:"";s:11:"captchaType";s:0:"";s:10:"pageNumber";i:1;s:12:"captchaTheme";s:0:"";s:17:"simpleCaptchaSize";s:0:"";s:22:"simpleCaptchaFontColor";s:0:"";s:28:"simpleCaptchaBackgroundColor";s:0:"";s:17:"failed_validation";s:0:"";s:12:"productField";s:0:"";s:19:"enablePasswordInput";s:0:"";s:9:"maxLength";s:0:"";s:11:"enablePrice";N;s:9:"basePrice";s:6:"$20.00";s:18:"calculationFormula";s:0:"";s:19:"calculationRounding";s:0:"";s:17:"enableCalculation";s:0:"";s:15:"disableQuantity";b:0;s:9:"inputMask";b:0;s:14:"inputMaskValue";s:0:"";s:6:"formId";i:1;s:20:"descriptionPlacement";s:5:"below";}i:1;a:59:{s:10:"adminLabel";s:0:"";s:9:"adminOnly";s:0:"";s:17:"allowsPrepopulate";b:0;s:12:"defaultValue";s:0:"";s:11:"description";s:0:"";s:7:"content";s:0:"";s:8:"cssClass";s:0:"";s:12:"errorMessage";s:0:"";s:2:"id";i:2;s:9:"inputName";s:0:"";s:10:"isRequired";b:1;s:5:"label";s:28:"Other (limited availability)";s:12:"noDuplicates";s:0:"";s:4:"size";s:6:"medium";s:4:"type";s:6:"option";s:19:"postCustomFieldName";s:0:"";s:20:"displayAllCategories";b:0;s:14:"displayCaption";s:0:"";s:18:"displayDescription";s:0:"";s:12:"displayTitle";s:0:"";s:9:"inputType";s:5:"radio";s:8:"rangeMin";s:0:"";s:8:"rangeMax";s:0:"";s:16:"calendarIconType";s:0:"";s:15:"calendarIconUrl";s:0:"";s:8:"dateType";s:0:"";s:10:"dateFormat";s:0:"";s:11:"phoneFormat";s:0:"";s:11:"addressType";s:0:"";s:14:"defaultCountry";s:0:"";s:15:"defaultProvince";s:0:"";s:12:"defaultState";s:0:"";s:12:"hideAddress2";s:0:"";s:11:"hideCountry";s:0:"";s:9:"hideState";s:0:"";s:6:"inputs";N;s:10:"nameFormat";s:0:"";s:17:"allowedExtensions";s:0:"";s:11:"captchaType";s:0:"";s:10:"pageNumber";i:1;s:12:"captchaTheme";s:0:"";s:17:"simpleCaptchaSize";s:0:"";s:22:"simpleCaptchaFontColor";s:0:"";s:28:"simpleCaptchaBackgroundColor";s:0:"";s:17:"failed_validation";s:0:"";s:12:"productField";i:5;s:19:"enablePasswordInput";s:0:"";s:9:"maxLength";s:0:"";s:11:"enablePrice";b:1;s:9:"basePrice";s:0:"";s:7:"choices";a:3:{i:0;a:4:{s:4:"text";s:5:"Black";s:5:"value";s:5:"Black";s:10:"isSelected";b:0;s:5:"price";s:5:"$0.00";}i:1;a:4:{s:4:"text";s:5:"White";s:5:"value";s:5:"White";s:10:"isSelected";b:0;s:5:"price";s:5:"$0.00";}i:2;a:4:{s:4:"text";s:5:"Other";s:5:"value";s:5:"Other";s:10:"isSelected";b:0;s:5:"price";s:5:"$0.00";}}s:18:"calculationFormula";s:0:"";s:19:"calculationRounding";s:0:"";s:17:"enableCalculation";s:0:"";s:15:"disableQuantity";b:0;s:9:"inputMask";b:0;s:14:"inputMaskValue";s:0:"";s:6:"formId";i:1;s:20:"descriptionPlacement";s:5:"below";}i:2;a:61:{s:10:"adminLabel";s:0:"";s:9:"adminOnly";s:0:"";s:17:"allowsPrepopulate";b:0;s:12:"defaultValue";s:0:"";s:11:"description";s:69:"Please specify how many shirts you place in the quantity field above.";s:7:"content";s:0:"";s:8:"cssClass";s:0:"";s:12:"errorMessage";s:0:"";s:2:"id";i:4;s:9:"inputName";s:0:"";s:10:"isRequired";b:1;s:5:"label";s:8:"Quantity";s:12:"noDuplicates";s:0:"";s:4:"size";s:6:"medium";s:4:"type";s:8:"shipping";s:19:"postCustomFieldName";s:0:"";s:20:"displayAllCategories";b:0;s:14:"displayCaption";s:0:"";s:18:"displayDescription";s:0:"";s:12:"displayTitle";s:0:"";s:9:"inputType";s:6:"select";s:8:"rangeMin";s:0:"";s:8:"rangeMax";s:0:"";s:16:"calendarIconType";s:0:"";s:15:"calendarIconUrl";s:0:"";s:8:"dateType";s:0:"";s:10:"dateFormat";s:0:"";s:11:"phoneFormat";s:0:"";s:11:"addressType";s:0:"";s:14:"defaultCountry";s:0:"";s:15:"defaultProvince";s:0:"";s:12:"defaultState";s:0:"";s:12:"hideAddress2";s:0:"";s:11:"hideCountry";s:0:"";s:9:"hideState";s:0:"";s:6:"inputs";N;s:10:"nameFormat";s:0:"";s:17:"allowedExtensions";s:0:"";s:11:"captchaType";s:0:"";s:10:"pageNumber";i:1;s:12:"captchaTheme";s:0:"";s:17:"simpleCaptchaSize";s:0:"";s:22:"simpleCaptchaFontColor";s:0:"";s:28:"simpleCaptchaBackgroundColor";s:0:"";s:17:"failed_validation";s:0:"";s:12:"productField";s:0:"";s:19:"enablePasswordInput";s:0:"";s:9:"maxLength";s:0:"";s:11:"enablePrice";b:1;s:9:"basePrice";s:6:"$10.00";s:18:"calculationFormula";s:0:"";s:19:"calculationRounding";s:0:"";s:17:"enableCalculation";s:0:"";s:15:"disableQuantity";b:0;s:9:"inputMask";b:0;s:14:"inputMaskValue";s:0:"";s:7:"choices";a:3:{i:0;a:4:{s:4:"text";s:7:"1 to 12";s:5:"value";s:7:"1 to 12";s:10:"isSelected";b:0;s:5:"price";s:6:"$10.00";}i:1;a:4:{s:4:"text";s:8:"12 to 24";s:5:"value";s:8:"12 to 24";s:10:"isSelected";b:0;s:5:"price";s:6:"$15.00";}i:2;a:4:{s:4:"text";s:7:"25 & Up";s:5:"value";s:7:"25 & Up";s:10:"isSelected";b:0;s:5:"price";s:5:"$0.00";}}s:17:"enableChoiceValue";b:0;s:6:"formId";i:1;s:20:"descriptionPlacement";s:5:"below";s:16:"conditionalLogic";s:0:"";}i:3;a:58:{s:10:"adminLabel";s:0:"";s:9:"adminOnly";s:0:"";s:17:"allowsPrepopulate";b:0;s:12:"defaultValue";s:0:"";s:11:"description";s:0:"";s:7:"content";s:0:"";s:8:"cssClass";s:0:"";s:12:"errorMessage";s:0:"";s:2:"id";i:3;s:9:"inputName";s:0:"";s:10:"isRequired";b:0;s:5:"label";s:5:"Total";s:12:"noDuplicates";s:0:"";s:4:"size";s:6:"medium";s:4:"type";s:5:"total";s:19:"postCustomFieldName";s:0:"";s:20:"displayAllCategories";b:0;s:14:"displayCaption";s:0:"";s:18:"displayDescription";s:0:"";s:12:"displayTitle";s:0:"";s:9:"inputType";s:0:"";s:8:"rangeMin";s:0:"";s:8:"rangeMax";s:0:"";s:16:"calendarIconType";s:0:"";s:15:"calendarIconUrl";s:0:"";s:8:"dateType";s:0:"";s:10:"dateFormat";s:0:"";s:11:"phoneFormat";s:0:"";s:11:"addressType";s:0:"";s:14:"defaultCountry";s:0:"";s:15:"defaultProvince";s:0:"";s:12:"defaultState";s:0:"";s:12:"hideAddress2";s:0:"";s:11:"hideCountry";s:0:"";s:9:"hideState";s:0:"";s:6:"inputs";N;s:10:"nameFormat";s:0:"";s:17:"allowedExtensions";s:0:"";s:11:"captchaType";s:0:"";s:10:"pageNumber";i:1;s:12:"captchaTheme";s:0:"";s:17:"simpleCaptchaSize";s:0:"";s:22:"simpleCaptchaFontColor";s:0:"";s:28:"simpleCaptchaBackgroundColor";s:0:"";s:17:"failed_validation";s:0:"";s:12:"productField";s:0:"";s:19:"enablePasswordInput";s:0:"";s:9:"maxLength";s:0:"";s:11:"enablePrice";s:0:"";s:9:"basePrice";s:0:"";s:6:"formId";i:1;s:20:"descriptionPlacement";s:5:"below";s:18:"calculationFormula";s:0:"";s:19:"calculationRounding";s:0:"";s:17:"enableCalculation";s:0:"";s:15:"disableQuantity";b:0;s:9:"inputMask";b:0;s:14:"inputMaskValue";s:0:"";}}s:22:"useCurrentUserAsAuthor";b:1;s:20:"descriptionPlacement";s:5:"below";s:8:"cssClass";s:0:"";s:14:"enableHoneypot";b:0;s:15:"enableAnimation";b:0;s:26:"postContentTemplateEnabled";b:0;s:24:"postTitleTemplateEnabled";b:0;s:17:"postTitleTemplate";s:0:"";s:19:"postContentTemplate";s:0:"";s:14:"lastPageButton";N;s:10:"pagination";N;s:17:"firstPageCssClass";N;s:12:"limitEntries";b:0;s:17:"limitEntriesCount";s:0:"";s:19:"limitEntriesMessage";s:0:"";s:18:"limitEntriesPeriod";s:0:"";s:12:"requireLogin";b:0;s:19:"requireLoginMessage";s:0:"";s:12:"scheduleForm";b:0;s:13:"scheduleStart";s:0:"";s:17:"scheduleStartHour";s:0:"";s:19:"scheduleStartMinute";s:0:"";s:17:"scheduleStartAmpm";s:0:"";s:11:"scheduleEnd";s:0:"";s:15:"scheduleEndHour";s:0:"";s:17:"scheduleEndMinute";s:0:"";s:15:"scheduleEndAmpm";s:0:"";s:15:"scheduleMessage";s:0:"";s:12:"notification";a:3:{s:2:"to";s:13:"{admin_email}";s:7:"subject";s:32:"New submission from {form_title}";s:7:"message";s:12:"{all_fields}";}}', '') ;
#
# End of data contents of table wp_rg_form_meta
# --------------------------------------------------------

# WordPress : http://basewp MySQL database backup
#
# Generated: Friday 24. May 2013 17:58 UTC
# Hostname: localhost
# Database: `basewp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_view`
# --------------------------------------------------------


#
# Delete any existing table `wp_rg_form_view`
#

DROP TABLE IF EXISTS `wp_rg_form_view`;


#
# Table structure of table `wp_rg_form_view`
#

CREATE TABLE `wp_rg_form_view` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` char(15) DEFAULT NULL,
  `count` mediumint(8) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_rg_form_view (0 records)
#

#
# End of data contents of table wp_rg_form_view
# --------------------------------------------------------

# WordPress : http://basewp MySQL database backup
#
# Generated: Friday 24. May 2013 17:58 UTC
# Hostname: localhost
# Database: `basewp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_view`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead`
# --------------------------------------------------------


#
# Delete any existing table `wp_rg_lead`
#

DROP TABLE IF EXISTS `wp_rg_lead`;


#
# Table structure of table `wp_rg_lead`
#

CREATE TABLE `wp_rg_lead` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `post_id` bigint(20) unsigned DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `is_starred` tinyint(1) NOT NULL DEFAULT '0',
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `ip` varchar(39) NOT NULL,
  `source_url` varchar(200) NOT NULL DEFAULT '',
  `user_agent` varchar(250) NOT NULL DEFAULT '',
  `currency` varchar(5) DEFAULT NULL,
  `payment_status` varchar(15) DEFAULT NULL,
  `payment_date` datetime DEFAULT NULL,
  `payment_amount` decimal(19,2) DEFAULT NULL,
  `transaction_id` varchar(50) DEFAULT NULL,
  `is_fulfilled` tinyint(1) DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `transaction_type` tinyint(1) DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'active',
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_rg_lead (1 records)
#
 
INSERT INTO `wp_rg_lead` VALUES (1, 1, NULL, '2013-05-23 15:44:55', 0, 0, '127.0.0.1', 'http://basewp/about/', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.64 Safari/537.31', 'USD', 'Processing', NULL, NULL, NULL, NULL, 1, NULL, 'active') ;
#
# End of data contents of table wp_rg_lead
# --------------------------------------------------------

# WordPress : http://basewp MySQL database backup
#
# Generated: Friday 24. May 2013 17:58 UTC
# Hostname: localhost
# Database: `basewp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_view`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_detail`
# --------------------------------------------------------


#
# Delete any existing table `wp_rg_lead_detail`
#

DROP TABLE IF EXISTS `wp_rg_lead_detail`;


#
# Table structure of table `wp_rg_lead_detail`
#

CREATE TABLE `wp_rg_lead_detail` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) unsigned NOT NULL,
  `form_id` mediumint(8) unsigned NOT NULL,
  `field_number` float NOT NULL,
  `value` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `lead_id` (`lead_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_rg_lead_detail (3 records)
#
 
INSERT INTO `wp_rg_lead_detail` VALUES (3, 1, 1, '2', 'White|0') ; 
INSERT INTO `wp_rg_lead_detail` VALUES (5, 1, 1, '4', '1 to 12|10') ; 
INSERT INTO `wp_rg_lead_detail` VALUES (6, 1, 1, '3', '30') ;
#
# End of data contents of table wp_rg_lead_detail
# --------------------------------------------------------

# WordPress : http://basewp MySQL database backup
#
# Generated: Friday 24. May 2013 17:58 UTC
# Hostname: localhost
# Database: `basewp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_view`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_detail`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_detail_long`
# --------------------------------------------------------


#
# Delete any existing table `wp_rg_lead_detail_long`
#

DROP TABLE IF EXISTS `wp_rg_lead_detail_long`;


#
# Table structure of table `wp_rg_lead_detail_long`
#

CREATE TABLE `wp_rg_lead_detail_long` (
  `lead_detail_id` bigint(20) unsigned NOT NULL,
  `value` longtext,
  PRIMARY KEY (`lead_detail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_rg_lead_detail_long (0 records)
#

#
# End of data contents of table wp_rg_lead_detail_long
# --------------------------------------------------------

# WordPress : http://basewp MySQL database backup
#
# Generated: Friday 24. May 2013 17:58 UTC
# Hostname: localhost
# Database: `basewp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_view`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_detail`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_detail_long`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_meta`
# --------------------------------------------------------


#
# Delete any existing table `wp_rg_lead_meta`
#

DROP TABLE IF EXISTS `wp_rg_lead_meta`;


#
# Table structure of table `wp_rg_lead_meta`
#

CREATE TABLE `wp_rg_lead_meta` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`id`),
  KEY `meta_key` (`meta_key`),
  KEY `lead_id` (`lead_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_rg_lead_meta (4 records)
#
 
INSERT INTO `wp_rg_lead_meta` VALUES (1, 1, 'gform_product_info__', 'a:2:{s:8:"products";a:1:{i:1;a:4:{s:4:"name";s:26:"We Love You Moore T-Shirts";s:5:"price";s:6:"$20.00";s:8:"quantity";s:1:"1";s:7:"options";a:1:{i:0;a:4:{s:11:"field_label";s:28:"Other (limited availability)";s:11:"option_name";s:5:"White";s:12:"option_label";s:35:"Other (limited availability): White";s:5:"price";s:1:"0";}}}}s:8:"shipping";a:2:{s:4:"name";s:18:"Shipping (1 to 12)";s:5:"price";d:10;}}') ; 
INSERT INTO `wp_rg_lead_meta` VALUES (2, 1, 'gform_product_info_1_', 'a:2:{s:8:"products";a:1:{i:1;a:4:{s:4:"name";s:26:"We Love You Moore T-Shirts";s:5:"price";s:6:"$20.00";s:8:"quantity";s:1:"1";s:7:"options";a:1:{i:0;a:4:{s:11:"field_label";s:28:"Other (limited availability)";s:11:"option_name";s:5:"White";s:12:"option_label";s:35:"Other (limited availability): White";s:5:"price";s:1:"0";}}}}s:8:"shipping";a:2:{s:4:"name";s:18:"Shipping (1 to 12)";s:5:"price";d:10;}}') ; 
INSERT INTO `wp_rg_lead_meta` VALUES (3, 1, 'paypal_feed_id', '1') ; 
INSERT INTO `wp_rg_lead_meta` VALUES (4, 1, 'payment_gateway', 'paypal') ;
#
# End of data contents of table wp_rg_lead_meta
# --------------------------------------------------------

# WordPress : http://basewp MySQL database backup
#
# Generated: Friday 24. May 2013 17:58 UTC
# Hostname: localhost
# Database: `basewp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_view`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_detail`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_detail_long`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_notes`
# --------------------------------------------------------


#
# Delete any existing table `wp_rg_lead_notes`
#

DROP TABLE IF EXISTS `wp_rg_lead_notes`;


#
# Table structure of table `wp_rg_lead_notes`
#

CREATE TABLE `wp_rg_lead_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) unsigned NOT NULL,
  `user_name` varchar(250) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `value` longtext,
  PRIMARY KEY (`id`),
  KEY `lead_id` (`lead_id`),
  KEY `lead_user_key` (`lead_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_rg_lead_notes (0 records)
#

#
# End of data contents of table wp_rg_lead_notes
# --------------------------------------------------------

# WordPress : http://basewp MySQL database backup
#
# Generated: Friday 24. May 2013 17:58 UTC
# Hostname: localhost
# Database: `basewp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_view`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_detail`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_detail_long`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_notes`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_paypal`
# --------------------------------------------------------


#
# Delete any existing table `wp_rg_paypal`
#

DROP TABLE IF EXISTS `wp_rg_paypal`;


#
# Table structure of table `wp_rg_paypal`
#

CREATE TABLE `wp_rg_paypal` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `meta` longtext,
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_rg_paypal (1 records)
#
 
INSERT INTO `wp_rg_paypal` VALUES (1, 1, 1, 'a:26:{s:5:"email";s:19:"ryan.doss@gmail.com";s:4:"mode";s:4:"test";s:4:"type";s:7:"product";s:5:"style";s:0:"";s:13:"continue_text";s:0:"";s:10:"cancel_url";s:0:"";s:12:"disable_note";s:0:"";s:16:"disable_shipping";s:0:"";s:10:"delay_post";s:0:"";s:18:"update_post_action";s:0:"";s:19:"delay_autoresponder";s:0:"";s:18:"delay_notification";s:0:"";s:26:"paypal_conditional_enabled";s:0:"";s:27:"paypal_conditional_field_id";s:1:"2";s:27:"paypal_conditional_operator";s:2:"is";s:24:"paypal_conditional_value";s:5:"Black";s:22:"recurring_amount_field";s:0:"";s:20:"billing_cycle_number";s:1:"1";s:18:"billing_cycle_type";s:1:"M";s:15:"recurring_times";s:0:"";s:20:"trial_period_enabled";s:0:"";s:12:"trial_amount";s:0:"";s:19:"trial_period_number";s:1:"1";s:17:"trial_period_type";s:1:"M";s:15:"recurring_retry";s:0:"";s:15:"customer_fields";a:9:{s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:5:"email";s:0:"";s:8:"address1";s:0:"";s:8:"address2";s:0:"";s:4:"city";s:0:"";s:5:"state";s:0:"";s:3:"zip";s:0:"";s:7:"country";s:0:"";}}') ;
#
# End of data contents of table wp_rg_paypal
# --------------------------------------------------------

# WordPress : http://basewp MySQL database backup
#
# Generated: Friday 24. May 2013 17:58 UTC
# Hostname: localhost
# Database: `basewp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_view`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_detail`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_detail_long`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_notes`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_paypal`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_paypal_transaction`
# --------------------------------------------------------


#
# Delete any existing table `wp_rg_paypal_transaction`
#

DROP TABLE IF EXISTS `wp_rg_paypal_transaction`;


#
# Table structure of table `wp_rg_paypal_transaction`
#

CREATE TABLE `wp_rg_paypal_transaction` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `entry_id` int(10) unsigned NOT NULL,
  `transaction_type` varchar(15) DEFAULT NULL,
  `subscription_id` varchar(50) DEFAULT NULL,
  `transaction_id` varchar(50) DEFAULT NULL,
  `parent_transaction_id` varchar(50) DEFAULT NULL,
  `is_renewal` tinyint(1) NOT NULL DEFAULT '0',
  `amount` decimal(19,2) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `txn_id` (`transaction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_rg_paypal_transaction (0 records)
#

#
# End of data contents of table wp_rg_paypal_transaction
# --------------------------------------------------------

# WordPress : http://basewp MySQL database backup
#
# Generated: Friday 24. May 2013 17:58 UTC
# Hostname: localhost
# Database: `basewp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_view`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_detail`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_detail_long`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_notes`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_paypal`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_paypal_transaction`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------


#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_term_relationships (92 records)
#
 
INSERT INTO `wp_term_relationships` VALUES (1, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (4, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (7, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (7, 6, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (7, 10, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (7, 11, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (7, 14, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (8, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (9, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (10, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (11, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (12, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (13, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (14, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (15, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (16, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (17, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (18, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (19, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (20, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (21, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (22, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (23, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (24, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (25, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (26, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (27, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (28, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (29, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (30, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (31, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (32, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (33, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (34, 3, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (34, 10, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (34, 12, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (34, 16, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (35, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (36, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (37, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (38, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (39, 4, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (39, 8, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (39, 10, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (39, 11, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (39, 12, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (39, 14, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (40, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (41, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (41, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (41, 9, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (42, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (43, 3, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (43, 4, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (43, 11, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (43, 13, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (43, 16, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (44, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (45, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (45, 11, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (45, 14, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (45, 16, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (46, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (47, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (47, 3, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (47, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (47, 9, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (47, 10, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (47, 11, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (47, 14, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (47, 16, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (48, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (49, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (50, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (51, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (52, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (53, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (55, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (56, 4, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (56, 8, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (56, 10, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (56, 12, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (56, 15, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (57, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (58, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (59, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (59, 3, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (59, 6, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (59, 11, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (59, 14, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (59, 15, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (60, 5, 0) ;
#
# End of data contents of table wp_term_relationships
# --------------------------------------------------------

# WordPress : http://basewp MySQL database backup
#
# Generated: Friday 24. May 2013 17:58 UTC
# Hostname: localhost
# Database: `basewp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_view`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_detail`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_detail_long`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_notes`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_paypal`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_paypal_transaction`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------


#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_term_taxonomy (16 records)
#
 
INSERT INTO `wp_term_taxonomy` VALUES (1, 1, 'category', '', 0, 2) ; 
INSERT INTO `wp_term_taxonomy` VALUES (2, 2, 'category', '', 0, 4) ; 
INSERT INTO `wp_term_taxonomy` VALUES (3, 3, 'category', '', 0, 4) ; 
INSERT INTO `wp_term_taxonomy` VALUES (4, 4, 'category', '', 0, 3) ; 
INSERT INTO `wp_term_taxonomy` VALUES (5, 5, 'category', '', 0, 4) ; 
INSERT INTO `wp_term_taxonomy` VALUES (6, 6, 'category', '', 2, 2) ; 
INSERT INTO `wp_term_taxonomy` VALUES (7, 7, 'category', '', 2, 2) ; 
INSERT INTO `wp_term_taxonomy` VALUES (8, 8, 'category', '', 4, 2) ; 
INSERT INTO `wp_term_taxonomy` VALUES (9, 9, 'category', '', 7, 2) ; 
INSERT INTO `wp_term_taxonomy` VALUES (10, 10, 'post_tag', '', 0, 5) ; 
INSERT INTO `wp_term_taxonomy` VALUES (11, 11, 'post_tag', '', 0, 6) ; 
INSERT INTO `wp_term_taxonomy` VALUES (12, 12, 'post_tag', '', 0, 3) ; 
INSERT INTO `wp_term_taxonomy` VALUES (13, 13, 'post_tag', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (14, 14, 'post_tag', '', 0, 5) ; 
INSERT INTO `wp_term_taxonomy` VALUES (15, 15, 'post_tag', '', 0, 2) ; 
INSERT INTO `wp_term_taxonomy` VALUES (16, 16, 'post_tag', '', 0, 4) ;
#
# End of data contents of table wp_term_taxonomy
# --------------------------------------------------------

# WordPress : http://basewp MySQL database backup
#
# Generated: Friday 24. May 2013 17:58 UTC
# Hostname: localhost
# Database: `basewp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_view`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_detail`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_detail_long`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_notes`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_paypal`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_paypal_transaction`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------


#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_terms (16 records)
#
 
INSERT INTO `wp_terms` VALUES (1, 'General', 'general', 0) ; 
INSERT INTO `wp_terms` VALUES (2, 'Parent Category I', 'parent-category-i', 0) ; 
INSERT INTO `wp_terms` VALUES (3, 'Parent Category II', 'parent-category-ii', 0) ; 
INSERT INTO `wp_terms` VALUES (4, 'Parent Category III', 'parent-category-iii', 0) ; 
INSERT INTO `wp_terms` VALUES (5, 'Uncategorized', 'uncategorized', 0) ; 
INSERT INTO `wp_terms` VALUES (6, 'Child Category I', 'child-category-i', 0) ; 
INSERT INTO `wp_terms` VALUES (7, 'Child Category II', 'child-category-ii', 0) ; 
INSERT INTO `wp_terms` VALUES (8, 'Child Category III', 'child-category-iii', 0) ; 
INSERT INTO `wp_terms` VALUES (9, 'Grandchild Category I', 'grandchild-category-i', 0) ; 
INSERT INTO `wp_terms` VALUES (10, 'tag1', 'tag1', 0) ; 
INSERT INTO `wp_terms` VALUES (11, 'tag2', 'tag2', 0) ; 
INSERT INTO `wp_terms` VALUES (12, 'tag3', 'tag3', 0) ; 
INSERT INTO `wp_terms` VALUES (13, 'tag4', 'tag4', 0) ; 
INSERT INTO `wp_terms` VALUES (14, 'tag5', 'tag5', 0) ; 
INSERT INTO `wp_terms` VALUES (15, 'tag6', 'tag6', 0) ; 
INSERT INTO `wp_terms` VALUES (16, 'tag7', 'tag7', 0) ;
#
# End of data contents of table wp_terms
# --------------------------------------------------------

# WordPress : http://basewp MySQL database backup
#
# Generated: Friday 24. May 2013 17:58 UTC
# Hostname: localhost
# Database: `basewp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_view`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_detail`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_detail_long`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_notes`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_paypal`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_paypal_transaction`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_usermeta (26 records)
#
 
INSERT INTO `wp_usermeta` VALUES (1, 1, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (2, 1, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (3, 1, 'nickname', 'admin') ; 
INSERT INTO `wp_usermeta` VALUES (4, 1, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (5, 1, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (6, 1, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (7, 1, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (8, 1, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (9, 1, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (10, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (11, 1, 'wp_user_level', '10') ; 
INSERT INTO `wp_usermeta` VALUES (12, 1, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link,wp350_media') ; 
INSERT INTO `wp_usermeta` VALUES (13, 1, 'show_welcome_panel', '0') ; 
INSERT INTO `wp_usermeta` VALUES (14, 1, 'wp_user-settings', 'hidetb=1') ; 
INSERT INTO `wp_usermeta` VALUES (15, 1, 'wp_user-settings-time', '1363279171') ; 
INSERT INTO `wp_usermeta` VALUES (16, 1, 'wp_dashboard_quick_press_last_post_id', '88') ; 
INSERT INTO `wp_usermeta` VALUES (17, 1, 'closedpostboxes_dashboard', 'a:0:{}') ; 
INSERT INTO `wp_usermeta` VALUES (18, 1, 'metaboxhidden_dashboard', 'a:7:{i:0;s:25:"dashboard_recent_comments";i:1;s:24:"dashboard_incoming_links";i:2;s:17:"dashboard_plugins";i:3;s:21:"dashboard_quick_press";i:4;s:23:"dashboard_recent_drafts";i:5;s:17:"dashboard_primary";i:6;s:19:"dashboard_secondary";}') ; 
INSERT INTO `wp_usermeta` VALUES (19, 1, 'closedpostboxes_post', 'a:0:{}') ; 
INSERT INTO `wp_usermeta` VALUES (20, 1, 'metaboxhidden_post', 'a:7:{i:0;s:11:"postexcerpt";i:1;s:13:"trackbacksdiv";i:2;s:16:"commentstatusdiv";i:3;s:11:"commentsdiv";i:4;s:7:"slugdiv";i:5;s:9:"authordiv";i:6;s:12:"revisionsdiv";}') ; 
INSERT INTO `wp_usermeta` VALUES (21, 1, 'meta-box-order_dashboard', 'a:4:{s:6:"normal";s:88:"dashboard_right_now,dashboard_recent_comments,dashboard_incoming_links,dashboard_plugins";s:4:"side";s:102:"dashboard_quick_press,rg_forms_dashboard,dashboard_recent_drafts,dashboard_primary,dashboard_secondary";s:7:"column3";s:0:"";s:7:"column4";s:0:"";}') ; 
INSERT INTO `wp_usermeta` VALUES (22, 1, 'screen_layout_dashboard', '2') ; 
INSERT INTO `wp_usermeta` VALUES (23, 1, 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}') ; 
INSERT INTO `wp_usermeta` VALUES (24, 1, 'metaboxhidden_nav-menus', 'a:2:{i:0;s:8:"add-post";i:1;s:12:"add-post_tag";}') ; 
INSERT INTO `wp_usermeta` VALUES (25, 1, 'closedpostboxes_wpbdp_listing', 'a:0:{}') ; 
INSERT INTO `wp_usermeta` VALUES (26, 1, 'metaboxhidden_wpbdp_listing', 'a:6:{i:0;s:11:"postexcerpt";i:1;s:13:"trackbacksdiv";i:2;s:10:"postcustom";i:3;s:16:"commentstatusdiv";i:4;s:7:"slugdiv";i:5;s:9:"authordiv";}') ;
#
# End of data contents of table wp_usermeta
# --------------------------------------------------------

# WordPress : http://basewp MySQL database backup
#
# Generated: Friday 24. May 2013 17:58 UTC
# Hostname: localhost
# Database: `basewp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_view`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_detail`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_detail_long`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_notes`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_paypal`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_paypal_transaction`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------


#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(64) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_users (1 records)
#
 
INSERT INTO `wp_users` VALUES (1, 'admin', '$P$Bd8LoYq67ZSTE.ITb1LoooiekvL5861', 'admin', 'rdoss@pilrtech.com', '', '2013-03-14 16:38:53', '', 0, 'admin') ;
#
# End of data contents of table wp_users
# --------------------------------------------------------

# WordPress : http://basewp MySQL database backup
#
# Generated: Friday 24. May 2013 17:58 UTC
# Hostname: localhost
# Database: `basewp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_view`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_detail`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_detail_long`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_notes`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_paypal`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_paypal_transaction`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpbdp_fees`
# --------------------------------------------------------


#
# Delete any existing table `wp_wpbdp_fees`
#

DROP TABLE IF EXISTS `wp_wpbdp_fees`;


#
# Table structure of table `wp_wpbdp_fees`
#

CREATE TABLE `wp_wpbdp_fees` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `label` varchar(255) NOT NULL,
  `amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `days` smallint(5) unsigned NOT NULL DEFAULT '0',
  `images` smallint(5) unsigned NOT NULL DEFAULT '0',
  `categories` blob NOT NULL,
  `extra_data` blob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_wpbdp_fees (0 records)
#

#
# End of data contents of table wp_wpbdp_fees
# --------------------------------------------------------

# WordPress : http://basewp MySQL database backup
#
# Generated: Friday 24. May 2013 17:58 UTC
# Hostname: localhost
# Database: `basewp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_view`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_detail`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_detail_long`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_notes`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_paypal`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_paypal_transaction`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpbdp_fees`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpbdp_form_fields`
# --------------------------------------------------------


#
# Delete any existing table `wp_wpbdp_form_fields`
#

DROP TABLE IF EXISTS `wp_wpbdp_form_fields`;


#
# Table structure of table `wp_wpbdp_form_fields`
#

CREATE TABLE `wp_wpbdp_form_fields` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `label` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `field_type` varchar(100) NOT NULL,
  `association` varchar(100) NOT NULL,
  `validators` text,
  `weight` int(5) NOT NULL DEFAULT '0',
  `display_flags` text,
  `field_data` blob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_wpbdp_form_fields (9 records)
#
 
INSERT INTO `wp_wpbdp_form_fields` VALUES (1, 'Business Name', '', 'textfield', 'title', 'required', 9, 'excerpt,listing,search', 'a:0:{}') ; 
INSERT INTO `wp_wpbdp_form_fields` VALUES (2, 'Business Genre', '', 'select', 'category', 'required', 8, 'excerpt,listing,search', 'a:1:{s:7:"options";a:0:{}}') ; 
INSERT INTO `wp_wpbdp_form_fields` VALUES (3, 'Short Business Description', '', 'textarea', 'excerpt', '', 7, 'excerpt,listing,search', 'a:0:{}') ; 
INSERT INTO `wp_wpbdp_form_fields` VALUES (4, 'Long Business Description', '', 'textarea', 'content', 'required', 6, 'excerpt,listing,search', 'a:0:{}') ; 
INSERT INTO `wp_wpbdp_form_fields` VALUES (5, 'Business Website Address', '', 'url', 'meta', 'url', 5, 'excerpt,listing,search', 'a:0:{}') ; 
INSERT INTO `wp_wpbdp_form_fields` VALUES (6, 'Business Phone Number', '', 'textfield', 'meta', '', 4, 'excerpt,listing,search', 'a:0:{}') ; 
INSERT INTO `wp_wpbdp_form_fields` VALUES (7, 'Business Fax', '', 'textfield', 'meta', '', 3, 'excerpt,listing,search', 'a:0:{}') ; 
INSERT INTO `wp_wpbdp_form_fields` VALUES (8, 'Business Contact Email', '', 'textfield', 'meta', 'email,required', 2, 'excerpt,listing', 'a:0:{}') ; 
INSERT INTO `wp_wpbdp_form_fields` VALUES (9, 'Business Tags', '', 'textfield', 'tags', '', 1, 'excerpt,listing,search', 'a:1:{s:7:"options";a:0:{}}') ;
#
# End of data contents of table wp_wpbdp_form_fields
# --------------------------------------------------------

# WordPress : http://basewp MySQL database backup
#
# Generated: Friday 24. May 2013 17:58 UTC
# Hostname: localhost
# Database: `basewp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_view`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_detail`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_detail_long`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_notes`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_paypal`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_paypal_transaction`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpbdp_fees`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpbdp_form_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpbdp_listing_fees`
# --------------------------------------------------------


#
# Delete any existing table `wp_wpbdp_listing_fees`
#

DROP TABLE IF EXISTS `wp_wpbdp_listing_fees`;


#
# Table structure of table `wp_wpbdp_listing_fees`
#

CREATE TABLE `wp_wpbdp_listing_fees` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `listing_id` mediumint(9) NOT NULL,
  `category_id` mediumint(9) NOT NULL,
  `fee` blob NOT NULL,
  `expires_on` timestamp NULL DEFAULT NULL,
  `updated_on` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `charged` tinyint(1) NOT NULL DEFAULT '0',
  `email_sent` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_wpbdp_listing_fees (0 records)
#

#
# End of data contents of table wp_wpbdp_listing_fees
# --------------------------------------------------------

# WordPress : http://basewp MySQL database backup
#
# Generated: Friday 24. May 2013 17:58 UTC
# Hostname: localhost
# Database: `basewp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_form_view`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_detail`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_detail_long`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_lead_notes`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_paypal`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_rg_paypal_transaction`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpbdp_fees`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpbdp_form_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpbdp_listing_fees`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpbdp_payments`
# --------------------------------------------------------


#
# Delete any existing table `wp_wpbdp_payments`
#

DROP TABLE IF EXISTS `wp_wpbdp_payments`;


#
# Table structure of table `wp_wpbdp_payments`
#

CREATE TABLE `wp_wpbdp_payments` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `listing_id` mediumint(9) NOT NULL,
  `gateway` varchar(255) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `payment_type` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `processed_on` timestamp NULL DEFAULT NULL,
  `processed_by` varchar(255) NOT NULL DEFAULT 'gateway',
  `payerinfo` blob,
  `extra_data` blob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_wpbdp_payments (1 records)
#
 
INSERT INTO `wp_wpbdp_payments` VALUES (1, 76, NULL, '0.00', 'initial', 'approved', 2013-04-25 15:52:23, 2013-04-25 15:52:23, 'admin', NULL, NULL) ;
#
# End of data contents of table wp_wpbdp_payments
# --------------------------------------------------------

